#!/bin/bash

# TTS Production Start Script
# Start all production services with proper initialization

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
ENV_FILE="${PROJECT_ROOT}/.env"
COMPOSE_FILE="${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml"
PROFILE="${PROFILE:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Docker and Docker Compose
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed"
        exit 1
    fi
    
    # Check if Docker daemon is running
    if ! docker info &> /dev/null; then
        log_error "Docker daemon is not running"
        exit 1
    fi
    
    # Check environment file
    if [ ! -f "$ENV_FILE" ]; then
        log_error "Environment file not found: $ENV_FILE"
        log_info "Please run: ./production/scripts/setup-env.sh"
        exit 1
    fi
    
    # Check Docker Compose file
    if [ ! -f "$COMPOSE_FILE" ]; then
        log_error "Docker Compose file not found: $COMPOSE_FILE"
        exit 1
    fi
    
    log_success "Prerequisites check passed"
}

# Create necessary directories
create_directories() {
    log_info "Creating necessary directories..."
    
    local directories=(
        "${PROJECT_ROOT}/logs"
        "${PROJECT_ROOT}/backups"
        "${PROJECT_ROOT}/outputs"
        "${PROJECT_ROOT}/cache"
        "${PROJECT_ROOT}/models_cache"
        "${PROJECT_ROOT}/ssl"
    )
    
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            log_info "Created directory: $dir"
        fi
    done
    
    # Set appropriate permissions
    chmod 755 "${PROJECT_ROOT}/logs" "${PROJECT_ROOT}/backups" "${PROJECT_ROOT}/outputs"
    chmod 700 "${PROJECT_ROOT}/ssl"
    
    log_success "Directories created"
}

# Validate environment configuration
validate_environment() {
    log_info "Validating environment configuration..."
    
    # Source environment file
    set -a
    source "$ENV_FILE"
    set +a
    
    # Check required environment variables
    local required_vars=(
        "SECRET_KEY"
        "DATABASE_URL"
        "REDIS_URL"
    )
    
    for var in "${required_vars[@]}"; do
        if [ -z "${!var:-}" ]; then
            log_error "Required environment variable not set: $var"
            exit 1
        fi
    done
    
    # Validate DATABASE_URL format
    if [[ ! "$DATABASE_URL" =~ postgresql:// ]]; then
        log_error "Invalid DATABASE_URL format"
        exit 1
    fi
    
    # Validate REDIS_URL format
    if [[ ! "$REDIS_URL" =~ redis:// ]]; then
        log_error "Invalid REDIS_URL format"
        exit 1
    fi
    
    log_success "Environment validation passed"
}

# Pull latest images
pull_images() {
    log_info "Pulling latest Docker images..."
    
    cd "$PROJECT_ROOT"
    
    # Build application image
    docker build \
        -f deployment_configs/docker/Dockerfile \
        -t tts-converter:latest \
        --build-arg BUILD_DATE="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        --build-arg VCS_REF="$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")" \
        --build-arg VERSION="latest" \
        .
    
    log_success "Images pulled and built"
}

# Start database and Redis first
start_infrastructure() {
    log_info "Starting infrastructure services (database and Redis)..."
    
    cd "$PROJECT_ROOT"
    
    # Start database and Redis
    docker-compose -f "$COMPOSE_FILE" up -d postgres redis
    
    # Wait for database to be ready
    log_info "Waiting for database to be ready..."
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if docker-compose -f "$COMPOSE_FILE" exec -T postgres pg_isready -U tts_user &> /dev/null; then
            log_success "Database is ready"
            break
        fi
        
        attempt=$((attempt + 1))
        log_info "Waiting for database... (attempt $attempt/$max_attempts)"
        sleep 5
    done
    
    if [ $attempt -eq $max_attempts ]; then
        log_error "Database failed to start within expected time"
        exit 1
    fi
    
    # Wait for Redis to be ready
    log_info "Waiting for Redis to be ready..."
    attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if docker-compose -f "$COMPOSE_FILE" exec -T redis redis-cli ping &> /dev/null; then
            log_success "Redis is ready"
            break
        fi
        
        attempt=$((attempt + 1))
        log_info "Waiting for Redis... (attempt $attempt/$max_attempts)"
        sleep 2
    done
    
    if [ $attempt -eq $max_attempts ]; then
        log_error "Redis failed to start within expected time"
        exit 1
    fi
    
    log_success "Infrastructure services started successfully"
}

# Run database migrations
run_migrations() {
    log_info "Running database migrations..."
    
    cd "$PROJECT_ROOT"
    
    # Create migrations table if it doesn't exist
    docker-compose -f "$COMPOSE_FILE" exec -T postgres psql -U tts_user -d tts_db \
        -c "CREATE TABLE IF NOT EXISTS alembic_version (version_num VARCHAR(32) NOT NULL, PRIMARY KEY (version_num));" 2>/dev/null || true
    
    # Run migrations (if using Alembic)
    if [ -d "${PROJECT_ROOT}/alembic" ]; then
        docker-compose -f "$COMPOSE_FILE" exec -T tts-app alembic upgrade head || \
        log_warning "Alembic migrations failed or not configured"
    fi
    
    log_success "Database migrations completed"
}

# Start monitoring services (optional)
start_monitoring() {
    if [ -n "${PROFILE:-}" ] && [[ "$PROFILE" == *"monitoring"* ]]; then
        log_info "Starting monitoring services..."
        
        cd "$PROJECT_ROOT"
        docker-compose -f "$COMPOSE_FILE" --profile monitoring up -d prometheus grafana
        
        log_success "Monitoring services started"
        log_info "Prometheus: http://localhost:9090"
        log_info "Grafana: http://localhost:3000"
    fi
}

# Start logging services (optional)
start_logging() {
    if [ -n "${PROFILE:-}" ] && [[ "$PROFILE" == *"logging"* ]]; then
        log_info "Starting logging services..."
        
        cd "$PROJECT_ROOT"
        docker-compose -f "$COMPOSE_FILE" --profile logging up -d elasticsearch logstash kibana
        
        log_success "Logging services started"
        log_info "Kibana: http://localhost:5601"
    fi
}

# Start the main application
start_application() {
    log_info "Starting TTS application..."
    
    cd "$PROJECT_ROOT"
    
    # Start the main application and Nginx
    docker-compose -f "$COMPOSE_FILE" up -d tts-app nginx
    
    log_success "TTS application started"
}

# Wait for application to be healthy
wait_for_application() {
    log_info "Waiting for application to be healthy..."
    
    local max_attempts=60
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -sf http://localhost:8080/health > /dev/null 2>&1; then
            log_success "Application is healthy and ready"
            return 0
        fi
        
        attempt=$((attempt + 1))
        log_info "Waiting for application... (attempt $attempt/$max_attempts)"
        sleep 5
    done
    
    log_error "Application failed to become healthy within expected time"
    return 1
}

# Show startup information
show_startup_info() {
    log_success "TTS Production deployment started successfully!"
    echo
    echo "=== Service Information ==="
    echo "Main Application: http://localhost:8080"
    echo "Direct Gradio UI: http://localhost:7860"
    echo "Nginx (if enabled): http://localhost:80"
    echo
    
    if [ -n "${PROFILE:-}" ] && [[ "$PROFILE" == *"monitoring"* ]]; then
        echo "=== Monitoring ==="
        echo "Prometheus: http://localhost:9090"
        echo "Grafana: http://localhost:3000"
        echo
    fi
    
    if [ -n "${PROFILE:-}" ] && [[ "$PROFILE" == *"logging"* ]]; then
        echo "=== Logging ==="
        echo "Kibana: http://localhost:5601"
        echo
    fi
    
    echo "=== Container Status ==="
    docker-compose -f "$COMPOSE_FILE" ps
    echo
    
    echo "=== Useful Commands ==="
    echo "View logs: docker-compose -f $COMPOSE_FILE logs -f"
    echo "Stop services: ./production/scripts/stop-production.sh"
    echo "Check health: ./production/scripts/health-check.sh"
}

# Handle startup errors
handle_startup_error() {
    log_error "Startup failed! Cleaning up..."
    
    cd "$PROJECT_ROOT"
    docker-compose -f "$COMPOSE_FILE" down --remove-orphans
    
    log_info "Showing recent logs for debugging:"
    docker-compose -f "$COMPOSE_FILE" logs --tail=50
    
    exit 1
}

# Main startup function
main() {
    log_info "Starting TTS production deployment..."
    
    # Trap errors
    trap handle_startup_error ERR
    
    # Run startup sequence
    check_prerequisites
    create_directories
    validate_environment
    pull_images
    start_infrastructure
    run_migrations
    start_monitoring
    start_logging
    start_application
    
    # Wait for application to be healthy
    if wait_for_application; then
        show_startup_info
    else
        handle_startup_error
    fi
}

# Show usage
usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --profile <profile>     Docker Compose profile (monitoring, logging, backup)"
    echo "  --no-build             Skip building images"
    echo "  --no-wait              Don't wait for application to be healthy"
    echo "  --help                 Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 --profile monitoring"
    echo "  $0 --profile monitoring,logging"
    echo "  $0 --no-build"
    echo ""
    echo "Profiles:"
    echo "  monitoring             Include Prometheus and Grafana"
    echo "  logging                Include Elasticsearch, Logstash, and Kibana"
    echo "  backup                 Include backup services"
    echo ""
    echo "Environment variables:"
    echo "  PROFILE                Default profile(s) to use"
}

# Parse command line arguments
NO_BUILD=false
NO_WAIT=false
PROFILES="${PROFILE:-}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --profile)
            PROFILES="$2"
            shift
            ;;
        --no-build)
            NO_BUILD=true
            ;;
        --no-wait)
            NO_WAIT=true
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
        *)
            log_error "Unknown argument: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Set profile environment variable
if [ -n "$PROFILES" ]; then
    export PROFILE="$PROFILES"
fi

# Run main startup
main

exit 0