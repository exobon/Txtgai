#!/bin/bash

# TTS Production Backup Script
# Comprehensive backup and recovery procedures

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-${PROJECT_ROOT}/backups}"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-7}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${PROJECT_ROOT}/logs/backup-${TIMESTAMP}.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE" >&2
}

# Create backup directory
setup_backup_dir() {
    log_info "Setting up backup directory: $BACKUP_DIR"
    
    mkdir -p "$BACKUP_DIR"
    chmod 750 "$BACKUP_DIR"
    
    # Create timestamp subdirectory
    local backup_subdir="${BACKUP_DIR}/${TIMESTAMP}"
    mkdir -p "$backup_subdir"
    
    echo "$backup_subdir"
}

# Database backup
backup_database() {
    local backup_subdir="$1"
    local db_backup_file="${backup_subdir}/database.sql"
    
    log_info "Starting database backup..."
    
    # Get database credentials from environment
    local db_url
    db_url=$(grep "^DATABASE_URL=" "${PROJECT_ROOT}/.env" | cut -d'=' -f2)
    
    if [[ $db_url =~ postgresql://([^:]+):([^@]+)@([^:]+):([0-9]+)/(.+) ]]; then
        local db_user="${BASH_REMATCH[1]}"
        local db_password="${BASH_REMATCH[2]}"
        local db_host="${BASH_REMATCH[3]}"
        local db_port="${BASH_REMATCH[4]}"
        local db_name="${BASH_REMATCH[5]}"
        
        # Export password for pg_dump
        export PGPASSWORD="$db_password"
        
        # Perform database backup
        if pg_dump -h "$db_host" -p "$db_port" -U "$db_user" -d "$db_name" \
            --verbose --clean --if-exists --create --format=custom \
            --file="${db_backup_file}.custom"; then
            
            # Also create plain SQL backup for portability
            pg_dump -h "$db_host" -p "$db_port" -U "$db_user" -d "$db_name" \
                --clean --if-exists --create > "${db_backup_file}"
            
            # Compress the backup
            gzip "${db_backup_file}"
            gzip "${db_backup_file}.custom"
            
            local backup_size
            backup_size=$(du -h "${db_backup_file}.gz" | cut -f1)
            
            log_success "Database backup completed: ${backup_size}"
            return 0
        else
            log_error "Database backup failed"
            return 1
        fi
    else
        log_error "Invalid DATABASE_URL format"
        return 1
    fi
}

# Application data backup
backup_application_data() {
    local backup_subdir="$1"
    local data_backup_dir="${backup_subdir}/application_data"
    
    log_info "Starting application data backup..."
    
    mkdir -p "$data_backup_dir"
    
    # Backup outputs directory
    if [ -d "${PROJECT_ROOT}/outputs" ]; then
        log_info "Backing up outputs directory..."
        tar -czf "${data_backup_dir}/outputs.tar.gz" -C "${PROJECT_ROOT}" outputs/ || true
    fi
    
    # Backup models cache
    if [ -d "${PROJECT_ROOT}/models_cache" ]; then
        log_info "Backing up models cache..."
        tar -czf "${data_backup_dir}/models_cache.tar.gz" -C "${PROJECT_ROOT}" models_cache/ || true
    fi
    
    # Backup configuration files
    if [ -f "${PROJECT_ROOT}/.env" ]; then
        log_info "Backing up environment configuration..."
        cp "${PROJECT_ROOT}/.env" "${data_backup_dir}/env.backup"
        chmod 600 "${data_backup_dir}/env.backup"
    fi
    
    # Backup logs directory (last 24 hours only)
    if [ -d "${PROJECT_ROOT}/logs" ]; then
        log_info "Backing up recent logs..."
        find "${PROJECT_ROOT}/logs" -name "*.log" -mtime -1 -exec tar -czf "${data_backup_dir}/recent_logs.tar.gz" {} + || true
    fi
    
    # Backup SSL certificates
    if [ -d "${PROJECT_ROOT}/ssl" ]; then
        log_info "Backing up SSL certificates..."
        tar -czf "${data_backup_dir}/ssl.tar.gz" -C "${PROJECT_ROOT}" ssl/ || true
    fi
    
    # Backup Docker volumes (metadata only)
    log_info "Backing up Docker volume information..."
    docker volume ls --format "{{.Driver}} {{.Name}}" > "${data_backup_dir}/volumes.txt" || true
    
    log_success "Application data backup completed"
}

# Configuration backup
backup_configuration() {
    local backup_subdir="$1"
    local config_backup_dir="${backup_subdir}/configuration"
    
    log_info "Starting configuration backup..."
    
    mkdir -p "$config_backup_dir"
    
    # Backup Docker Compose files
    if [ -f "${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml" ]; then
        cp "${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml" \
           "${config_backup_dir}/docker-compose.prod.yml"
    fi
    
    # Backup Nginx configuration
    if [ -f "${PROJECT_ROOT}/deployment_configs/docker/nginx.conf" ]; then
        cp "${PROJECT_ROOT}/deployment_configs/docker/nginx.conf" \
           "${config_backup_dir}/nginx.conf"
    fi
    
    # Backup production configuration
    if [ -d "${PROJECT_ROOT}/production/config" ]; then
        cp -r "${PROJECT_ROOT}/production/config" "${config_backup_dir}/"
    fi
    
    # Backup monitoring configuration
    if [ -d "${PROJECT_ROOT}/production/monitoring" ]; then
        cp -r "${PROJECT_ROOT}/production/monitoring" "${config_backup_dir}/"
    fi
    
    log_success "Configuration backup completed"
}

# System information backup
backup_system_info() {
    local backup_subdir="$1"
    local system_backup_dir="${backup_subdir}/system_info"
    
    log_info "Starting system information backup..."
    
    mkdir -p "$system_backup_dir"
    
    # System information
    {
        echo "=== System Information ==="
        uname -a
        echo
        echo "=== Disk Usage ==="
        df -h
        echo
        echo "=== Memory Usage ==="
        free -h
        echo
        echo "=== CPU Information ==="
        cat /proc/cpuinfo | grep "model name" | head -1
        echo
        echo "=== Docker Information ==="
        docker --version
        docker-compose --version
        echo
        echo "=== Running Containers ==="
        docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
        echo
        echo "=== Docker Volumes ==="
        docker volume ls
        echo
        echo "=== Environment Variables (TTS related) ==="
        env | grep -E "(TTS|DB|REDIS|PORT)" | sort
    } > "${system_backup_dir}/system_info.txt"
    
    # Docker container configurations
    docker inspect tts-app-prod > "${system_backup_dir}/tts-app-config.json" 2>/dev/null || true
    docker inspect tts-postgres > "${system_backup_dir}/postgres-config.json" 2>/dev/null || true
    docker inspect tts-redis > "${system_backup_dir}/redis-config.json" 2>/dev/null || true
    
    log_success "System information backup completed"
}

# Create backup manifest
create_manifest() {
    local backup_subdir="$1"
    local manifest_file="${backup_subdir}/backup_manifest.json"
    
    log_info "Creating backup manifest..."
    
    local backup_size
    backup_size=$(du -sh "$backup_subdir" | cut -f1)
    
    cat > "$manifest_file" << EOF
{
    "backup_info": {
        "timestamp": "$(date -Iseconds)",
        "hostname": "$(hostname)",
        "version": "$(git describe --tags --always 2>/dev/null || echo "unknown")",
        "backup_type": "full",
        "total_size": "$backup_size"
    },
    "components": {
        "database": {
            "included": true,
            "type": "PostgreSQL",
            "format": ["custom", "plain"],
            "compressed": true
        },
        "application_data": {
            "included": true,
            "includes": [
                "outputs",
                "models_cache",
                "logs",
                "ssl"
            ]
        },
        "configuration": {
            "included": true,
            "includes": [
                "docker-compose",
                "nginx",
                "production_config",
                "monitoring"
            ]
        },
        "system_info": {
            "included": true,
            "includes": [
                "system_info.txt",
                "container_configs"
            ]
        }
    },
    "retention": {
        "retention_days": $RETENTION_DAYS,
        "created_at": "$(date -Iseconds)"
    }
}
EOF

    log_success "Backup manifest created"
}

# Compress entire backup
compress_backup() {
    local backup_subdir="$1"
    local compressed_file="${BACKUP_DIR}/tts-backup-${TIMESTAMP}.tar.gz"
    
    log_info "Compressing backup..."
    
    cd "$BACKUP_DIR"
    tar -czf "$compressed_file" "$(basename "$backup_subdir")"
    
    # Remove uncompressed directory
    rm -rf "$backup_subdir"
    
    local final_size
    final_size=$(du -h "$compressed_file" | cut -f1)
    
    log_success "Backup compressed: $compressed_file (${final_size})"
    
    echo "$compressed_file"
}

# Cleanup old backups
cleanup_old_backups() {
    log_info "Cleaning up old backups (older than $RETENTION_DAYS days)..."
    
    local deleted_count=0
    local freed_space=0
    
    while IFS= read -r -d '' old_backup; do
        local size
        size=$(du -sb "$old_backup" | cut -f1)
        freed_space=$((freed_space + size))
        
        log_info "Deleting old backup: $(basename "$old_backup")"
        rm -f "$old_backup"
        ((deleted_count++))
    done < <(find "$BACKUP_DIR" -name "tts-backup-*.tar.gz" -type f -mtime +$RETENTION_DAYS -print0)
    
    if [ $deleted_count -gt 0 ]; then
        local freed_mb
        freed_mb=$((freed_space / 1024 / 1024))
        log_success "Cleaned up $deleted_count old backups, freed ${freed_mb}MB"
    else
        log_info "No old backups to clean up"
    fi
}

# Restore from backup
restore_backup() {
    local backup_file="$1"
    
    if [ ! -f "$backup_file" ]; then
        log_error "Backup file not found: $backup_file"
        return 1
    fi
    
    log_info "Starting restoration from: $backup_file"
    
    # Stop application
    log_info "Stopping application services..."
    cd "$PROJECT_ROOT"
    docker-compose -f deployment_configs/docker/docker-compose.prod.yml stop || true
    
    # Extract backup
    local temp_dir
    temp_dir=$(mktemp -d)
    
    log_info "Extracting backup to temporary directory..."
    tar -xzf "$backup_file" -C "$temp_dir"
    
    local backup_subdir
    backup_subdir=$(find "$temp_dir" -name "tts-backup-*" -type d | head -1)
    
    if [ -z "$backup_subdir" ]; then
        log_error "Invalid backup structure"
        rm -rf "$temp_dir"
        return 1
    fi
    
    # Restore database
    if [ -f "${backup_subdir}/database.sql.gz" ]; then
        log_info "Restoring database..."
        
        # Drop and recreate database
        docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T postgres psql -U tts_user -c "DROP DATABASE IF EXISTS tts_db;" || true
        docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T postgres psql -U tts_user -c "CREATE DATABASE tts_db;" || true
        
        # Restore database
        zcat "${backup_subdir}/database.sql.gz" | \
        docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T postgres psql -U tts_user -d tts_db
    fi
    
    # Restore application data
    if [ -d "${backup_subdir}/application_data" ]; then
        log_info "Restoring application data..."
        
        # Restore outputs
        if [ -f "${backup_subdir}/application_data/outputs.tar.gz" ]; then
            tar -xzf "${backup_subdir}/application_data/outputs.tar.gz" -C "${PROJECT_ROOT}"
        fi
        
        # Restore models cache
        if [ -f "${backup_subdir}/application_data/models_cache.tar.gz" ]; then
            tar -xzf "${backup_subdir}/application_data/models_cache.tar.gz" -C "${PROJECT_ROOT}"
        fi
        
        # Restore SSL certificates
        if [ -f "${backup_subdir}/application_data/ssl.tar.gz" ]; then
            tar -xzf "${backup_subdir}/application_data/ssl.tar.gz" -C "${PROJECT_ROOT}"
        fi
    fi
    
    # Restore configuration (optional)
    if [ -d "${backup_subdir}/configuration" ]; then
        log_info "Restoring configuration..."
        
        if [ -f "${backup_subdir}/configuration/docker-compose.prod.yml" ]; then
            cp "${backup_subdir}/configuration/docker-compose.prod.yml" \
               "${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml"
        fi
    fi
    
    # Start application
    log_info "Starting application services..."
    docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d
    
    # Cleanup
    rm -rf "$temp_dir"
    
    log_success "Restoration completed successfully"
    log_info "Please verify the application is working correctly"
}

# Verify backup integrity
verify_backup() {
    local backup_file="$1"
    
    if [ ! -f "$backup_file" ]; then
        log_error "Backup file not found: $backup_file"
        return 1
    fi
    
    log_info "Verifying backup integrity: $backup_file"
    
    # Test archive integrity
    if tar -tzf "$backup_file" > /dev/null 2>&1; then
        log_success "Backup archive integrity verified"
    else
        log_error "Backup archive is corrupted"
        return 1
    fi
    
    # Extract to temporary location and verify contents
    local temp_dir
    temp_dir=$(mktemp -d)
    
    if tar -xzf "$backup_file" -C "$temp_dir"; then
        local backup_subdir
        backup_subdir=$(find "$temp_dir" -name "tts-backup-*" -type d | head -1)
        
        if [ -n "$backup_subdir" ]; then
            # Check for required files
            local required_files=("backup_manifest.json")
            local missing_files=0
            
            for file in "${required_files[@]}"; do
                if [ ! -f "${backup_subdir}/${file}" ]; then
                    log_warning "Missing required file: $file"
                    ((missing_files++))
                fi
            done
            
            if [ $missing_files -eq 0 ]; then
                log_success "Backup verification completed - all checks passed"
                rm -rf "$temp_dir"
                return 0
            else
                log_error "Backup verification failed - missing files"
                rm -rf "$temp_dir"
                return 1
            fi
        else
            log_error "Invalid backup structure"
            rm -rf "$temp_dir"
            return 1
        fi
    else
        log_error "Failed to extract backup for verification"
        rm -rf "$temp_dir"
        return 1
    fi
}

# List available backups
list_backups() {
    log_info "Available backups:"
    
    if ls "${BACKUP_DIR}"/tts-backup-*.tar.gz 1> /dev/null 2>&1; then
        printf "%-30s %-15s %-20s\n" "FILENAME" "SIZE" "DATE"
        echo "----------------------------------------------------------"
        
        for backup in "${BACKUP_DIR}"/tts-backup-*.tar.gz; do
            if [ -f "$backup" ]; then
                local filename
                filename=$(basename "$backup")
                
                local size
                size=$(du -h "$backup" | cut -f1)
                
                local date
                date=$(stat -c %y "$backup" | cut -d' ' -f1)
                
                printf "%-30s %-15s %-20s\n" "$filename" "$size" "$date"
            fi
        done
    else
        log_info "No backups found in $BACKUP_DIR"
    fi
}

# Main backup function
main() {
    log_info "Starting TTS application backup process..."
    
    # Ensure log directory exists
    mkdir -p "$(dirname "$LOG_FILE")"
    
    # Setup backup directory
    local backup_subdir
    backup_subdir=$(setup_backup_dir)
    
    # Run backup components
    local backup_status=0
    
    backup_database "$backup_subdir" || backup_status=1
    backup_application_data "$backup_subdir" || backup_status=1
    backup_configuration "$backup_subdir" || backup_status=1
    backup_system_info "$backup_subdir" || backup_status=1
    
    # Create manifest
    create_manifest "$backup_subdir"
    
    # Compress backup
    local final_backup
    final_backup=$(compress_backup "$backup_subdir")
    
    # Cleanup old backups
    cleanup_old_backups
    
    if [ $backup_status -eq 0 ]; then
        log_success "Backup completed successfully: $final_backup"
        echo "$final_backup"
        return 0
    else
        log_error "Backup completed with errors"
        return 1
    fi
}

# Show usage
usage() {
    echo "Usage: $0 [command] [options]"
    echo ""
    echo "Commands:"
    echo "  backup        Create a new backup (default)"
    echo "  restore       Restore from backup"
    echo "  list          List available backups"
    echo "  verify        Verify backup integrity"
    echo "  cleanup       Clean up old backups"
    echo ""
    echo "Options:"
    echo "  --file <file>    Backup file for restore/verify operations"
    echo "  --retention <days>  Backup retention period (default: 7)"
    echo "  --output-dir <dir>  Backup output directory"
    echo "  -h, --help       Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 backup --retention 14"
    echo "  $0 restore --file /path/to/backup.tar.gz"
    echo "  $0 verify --file /path/to/backup.tar.gz"
    echo ""
    echo "Environment variables:"
    echo "  BACKUP_RETENTION_DAYS    Default retention period"
    echo "  BACKUP_DIR              Backup directory location"
}

# Handle script arguments
command="backup"
backup_file=""
retention_days="$RETENTION_DAYS"
backup_output_dir="$BACKUP_DIR"

while [[ $# -gt 0 ]]; do
    case $1 in
        backup)
            command="backup"
            ;;
        restore)
            command="restore"
            ;;
        list)
            command="list"
            ;;
        verify)
            command="verify"
            ;;
        cleanup)
            command="cleanup"
            ;;
        --file)
            backup_file="$2"
            shift
            ;;
        --retention)
            retention_days="$2"
            shift
            ;;
        --output-dir)
            backup_output_dir="$2"
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
        *)
            log_error "Unknown command: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Set environment variables
export BACKUP_RETENTION_DAYS="$retention_days"
export BACKUP_DIR="$backup_output_dir"

# Execute command
case $command in
    backup)
        main
        exit $?
        ;;
    restore)
        if [ -z "$backup_file" ]; then
            log_error "Backup file required for restore operation"
            usage
            exit 1
        fi
        restore_backup "$backup_file"
        exit $?
        ;;
    list)
        list_backups
        exit 0
        ;;
    verify)
        if [ -z "$backup_file" ]; then
            log_error "Backup file required for verify operation"
            usage
            exit 1
        fi
        verify_backup "$backup_file"
        exit $?
        ;;
    cleanup)
        cleanup_old_backups
        exit 0
        ;;
esac