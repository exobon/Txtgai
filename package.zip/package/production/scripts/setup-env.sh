#!/bin/bash

# TTS Production Environment Setup Script
# Configure environment variables and prepare system for production

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
ENV_FILE="${PROJECT_ROOT}/.env"
ENV_FILE_EXAMPLE="${PROJECT_ROOT}/.env.example"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

# Generate secure random string
generate_secret() {
    openssl rand -base64 32 2>/dev/null || \
    head -c 32 /dev/urandom | base64
}

# Generate password
generate_password() {
    openssl rand -base64 16 2>/dev/null || \
    head -c 16 /dev/urandom | base64 | tr -d "=+/" | cut -c1-16
}

# Check if .env file exists
check_env_file() {
    if [ ! -f "$ENV_FILE" ]; then
        log_warning "Environment file not found: $ENV_FILE"
        create_env_file
    else
        log_info "Environment file already exists: $ENV_FILE"
        read -p "Do you want to overwrite it? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            create_env_file
        else
            log_info "Keeping existing environment file"
        fi
    fi
}

# Create .env file with production defaults
create_env_file() {
    log_info "Creating production environment configuration..."
    
    # Generate secure values
    local secret_key
    secret_key=$(generate_secret)
    
    local db_password
    db_password=$(generate_password)
    
    local redis_password
    redis_password=$(generate_password)
    
    local grafana_password
    grafana_password=$(generate_password)
    
    # Create .env file
    cat > "$ENV_FILE" << EOF
# TTS Application Production Environment Configuration
# Generated on $(date)

# ===========================================
# Application Configuration
# ===========================================
APP_NAME=TTS Converter
ENVIRONMENT=production
LOG_LEVEL=INFO
DEBUG=false
SECRET_KEY=$secret_key

# Application Settings
MAX_TEXT_LENGTH=2000
BATCH_SIZE=10
ENABLE_METRICS=true
WORKERS=4
TIMEOUT=300

# ===========================================
# TTS Model Configuration
# ===========================================
DEFAULT_MODEL=speecht5
TRANSFORMERS_CACHE=/app/models_cache
HF_HOME=/tmp/huggingface
TORCH_HOME=/tmp/torch
MODEL_DOWNLOAD_TIMEOUT=3600

# ===========================================
# Database Configuration
# ===========================================
DATABASE_URL=postgresql://tts_user:$db_password@postgres:5432/tts_db
DB_HOST=postgres
DB_PORT=5432
DB_NAME=tts_db
DB_USER=tts_user
DB_PASSWORD=$db_password
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20

# ===========================================
# Redis Configuration
# ===========================================
REDIS_URL=redis://:$redis_password@redis:6379/0
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=$redis_password
REDIS_DB=0
REDIS_MAX_CONNECTIONS=100

# ===========================================
# Security Configuration
# ===========================================
ALLOWED_HOSTS=*
CORS_ALLOWED_ORIGINS=http://localhost:3000,http://localhost:8080
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60
SESSION_TIMEOUT=3600

# ===========================================
# Logging Configuration
# ===========================================
LOG_FORMAT=json
LOG_LEVEL=INFO
LOG_FILE=/app/logs/application.log
LOG_MAX_SIZE=100M
LOG_MAX_FILES=10

# ===========================================
# Monitoring Configuration
# ===========================================
PROMETHEUS_PORT=9090
GRAFANA_PORT=3000
METRICS_RETENTION=7d
HEALTH_CHECK_INTERVAL=30
ENABLE_TRACING=true

# ===========================================
# Storage Configuration
# ===========================================
OUTPUT_DIR=/app/outputs
CACHE_DIR=/app/cache
TEMP_DIR=/tmp
MAX_FILE_SIZE=50M
CLEANUP_INTERVAL=3600

# ===========================================
# Email Configuration (Optional)
# ===========================================
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
EMAIL_FROM=noreply@tts-converter.local

# ===========================================
# External Services (Optional)
# ===========================================
SENTRY_DSN=
ANALYTICS_ID=
CDN_URL=

# ===========================================
# Docker Compose Override
# ===========================================
COMPOSE_PROJECT_NAME=tts-converter
COMPOSE_FILE=deployment_configs/docker/docker-compose.prod.yml

# ===========================================
# Security Hardening
# ===========================================
DISABLE_DEBUG=true
ENABLE_HTTPS=false
SSL_CERT_PATH=/etc/ssl/certs
SSL_KEY_PATH=/etc/ssl/private
FORCE_HTTPS=false

# ===========================================
# Performance Tuning
# ===========================================
WORKER_CONNECTIONS=1000
MAX_REQUESTS=1000
MAX_REQUESTS_JITTER=100
KEEPALIVE_TIMEOUT=65
CONNECTION_TIMEOUT=10

# ===========================================
# Backup Configuration
# ===========================================
BACKUP_RETENTION_DAYS=7
BACKUP_SCHEDULE="0 2 * * *"
BACKUP_LOCATION=/backups
BACKUP_COMPRESSION=true

# ===========================================
# Grafana Configuration
# ===========================================
GRAFANA_PASSWORD=$grafana_password
GRAFANA_ADMIN_USER=admin
GRAFANA_DOMAIN=localhost
GRAFANA_ROOT_URL=http://localhost:3000

# ===========================================
# Nginx Configuration
# ===========================================
NGINX_PORT=80
NGINX_SSL_PORT=443
NGINX_WORKER_PROCESSES=auto
NGINX_WORKER_CONNECTIONS=1024
NGINX_KEEPALIVE_TIMEOUT=65

# ===========================================
# Development/Debug Settings
# ===========================================
ENABLE_SWAGGER=false
ENABLE_API_DOCS=false
API_RATE_LIMIT_DISABLED=false
LOG_SQL_QUERIES=false

EOF

    chmod 600 "$ENV_FILE"
    log_success "Created production environment file: $ENV_FILE"
    log_warning "Please review and update the configuration as needed"
}

# Create production directories
setup_directories() {
    log_info "Setting up production directories..."
    
    local directories=(
        "${PROJECT_ROOT}/logs"
        "${PROJECT_ROOT}/backups"
        "${PROJECT_ROOT}/outputs"
        "${PROJECT_ROOT}/cache"
        "${PROJECT_ROOT}/models_cache"
        "${PROJECT_ROOT}/ssl"
    )
    
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            log_info "Created directory: $dir"
        fi
    done
    
    # Set appropriate permissions
    chmod 755 "${PROJECT_ROOT}/logs" "${PROJECT_ROOT}/backups" "${PROJECT_ROOT}/outputs"
    chmod 700 "${PROJECT_ROOT}/ssl"
    
    log_success "Production directories created"
}

# Create SSL certificates (self-signed for development/testing)
create_ssl_certificates() {
    if [ ! -f "${PROJECT_ROOT}/ssl/server.crt" ]; then
        log_info "Creating self-signed SSL certificate for testing..."
        
        cd "${PROJECT_ROOT}/ssl"
        
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout server.key \
            -out server.crt \
            -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"
        
        chmod 600 server.key
        chmod 644 server.crt
        
        log_success "SSL certificates created"
        log_warning "These are self-signed certificates for testing only"
        log_warning "Use proper certificates for production deployment"
    else
        log_info "SSL certificates already exist"
    fi
}

# Create systemd service file
create_systemd_service() {
    local service_file="/etc/systemd/system/tts-converter.service"
    
    if [ "$EUID" -eq 0 ]; then
        log_info "Creating systemd service..."
        
        cat > "$service_file" << EOF
[Unit]
Description=TTS Converter Production Service
After=network.target docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$PROJECT_ROOT
ExecStart=/usr/local/bin/docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d
ExecStop=/usr/local/bin/docker-compose -f deployment_configs/docker/docker-compose.prod.yml down
ExecReload=/usr/local/bin/docker-compose -f deployment_configs/docker/docker-compose.prod.yml restart
TimeoutStartSec=0
User=root
Group=root

[Install]
WantedBy=multi-user.target
EOF

        systemctl daemon-reload
        systemctl enable tts-converter.service
        
        log_success "Systemd service created: $service_file"
        log_info "Use 'systemctl start tts-converter' to start the service"
    else
        log_warning "Not running as root. Skipping systemd service creation"
        log_info "To create systemd service, run with sudo"
    fi
}

# Validate environment configuration
validate_config() {
    log_info "Validating environment configuration..."
    
    # Check required environment variables
    local required_vars=(
        "SECRET_KEY"
        "DATABASE_URL"
        "REDIS_URL"
    )
    
    for var in "${required_vars[@]}"; do
        if ! grep -q "^${var}=" "$ENV_FILE"; then
            log_error "Required environment variable missing: $var"
            return 1
        fi
        
        if [ -z "$(grep "^${var}=" "$ENV_FILE" | cut -d'=' -f2)" ]; then
            log_error "Environment variable $var is empty"
            return 1
        fi
    done
    
    # Validate database URL format
    if ! grep -q "^DATABASE_URL=postgresql://" "$ENV_FILE"; then
        log_error "DATABASE_URL format is incorrect"
        return 1
    fi
    
    # Validate Redis URL format
    if ! grep -q "^REDIS_URL=redis://" "$ENV_FILE"; then
        log_error "REDIS_URL format is incorrect"
        return 1
    fi
    
    log_success "Environment configuration validated"
}

# Test configuration
test_config() {
    log_info "Testing configuration..."
    
    # Test database connectivity
    if command -v psql &> /dev/null; then
        local db_url
        db_url=$(grep "^DATABASE_URL=" "$ENV_FILE" | cut -d'=' -f2)
        
        # Extract connection details for testing
        if [[ $db_url =~ postgresql://([^:]+):([^@]+)@([^:]+):([0-9]+)/(.+) ]]; then
            local user="${BASH_REMATCH[1]}"
            local password="${BASH_REMATCH[2]}"
            local host="${BASH_REMATCH[3]}"
            local port="${BASH_REMATCH[4]}"
            local db="${BASH_REMATCH[5]}"
            
            if PGPASSWORD="$password" psql -h "$host" -p "$port" -U "$user" -d "$db" -c "SELECT 1;" &> /dev/null; then
                log_success "Database connectivity test passed"
            else
                log_warning "Database connectivity test failed (may not be running yet)"
            fi
        fi
    fi
    
    # Test Redis connectivity
    if command -v redis-cli &> /dev/null; then
        local redis_url
        redis_url=$(grep "^REDIS_URL=" "$ENV_FILE" | cut -d'=' -f2)
        
        if [[ $redis_url =~ redis://:?([^@]*)@([^:]+):([0-9]+)/([0-9]+) ]]; then
            local password="${BASH_REMATCH[1]}"
            local host="${BASH_REMATCH[2]}"
            local port="${BASH_REMATCH[3]}"
            
            if redis-cli -h "$host" -p "$port" -a "$password" ping &> /dev/null; then
                log_success "Redis connectivity test passed"
            else
                log_warning "Redis connectivity test failed (may not be running yet)"
            fi
        fi
    fi
}

# Main setup flow
main() {
    log_info "Setting up TTS converter production environment..."
    
    # Create .env file
    check_env_file
    
    # Setup directories
    setup_directories
    
    # Create SSL certificates
    create_ssl_certificates
    
    # Create systemd service (if running as root)
    create_systemd_service
    
    # Validate configuration
    validate_config
    
    # Test configuration
    test_config
    
    log_success "Production environment setup completed!"
    log_info "Next steps:"
    log_info "1. Review and update $ENV_FILE as needed"
    log_info "2. Run: ./production/scripts/deploy.sh production"
    log_info "3. Access application at http://localhost:8080"
}

# Show usage
usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --force    Overwrite existing .env file"
    echo "  --test     Only test configuration"
    echo "  --validate Only validate existing configuration"
    echo "  -h, --help Show this help"
    echo ""
    echo "Environment variables:"
    echo "  ENV_FILE   Path to environment file (default: .env)"
}

# Handle script arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --force)
            create_env_file
            exit 0
            ;;
        --test)
            test_config
            exit 0
            ;;
        --validate)
            validate_config
            exit 0
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Run main setup
main