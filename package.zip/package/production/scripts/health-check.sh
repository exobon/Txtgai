#!/bin/bash

# TTS Production Health Check Script
# Comprehensive health monitoring and alerting

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
CONFIG_FILE="${PROJECT_ROOT}/production/config/health-config.yml"
LOG_FILE="${PROJECT_ROOT}/logs/health-check.log"
ALERT_WEBHOOK="${ALERT_WEBHOOK:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Health check results
HEALTH_PASSED=0
HEALTH_FAILED=1
HEALTH_WARNING=2

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Send alert notification
send_alert() {
    local level="$1"
    local message="$2"
    local service="$3"
    
    log_error "ALERT [$level] - $service: $message"
    
    # Send to webhook if configured
    if [ -n "$ALERT_WEBHOOK" ]; then
        local payload
        payload=$(cat <<EOF
{
    "level": "$level",
    "service": "$service",
    "message": "$message",
    "timestamp": "$(date -Iseconds)",
    "hostname": "$(hostname)"
}
EOF
)
        
        curl -X POST -H "Content-Type: application/json" \
            -d "$payload" \
            "$ALERT_WEBHOOK" &> /dev/null || true
    fi
}

# Check HTTP endpoint
check_http_endpoint() {
    local url="$1"
    local timeout="${2:-10}"
    local service="${3:-unknown}"
    
    log_info "Checking HTTP endpoint: $url"
    
    local response
    local http_code
    
    response=$(curl -s -w "%{http_code}" --max-time "$timeout" "$url" 2>/dev/null || echo "000")
    http_code="${response: -3}"
    
    if [ "$http_code" = "200" ]; then
        log_success "HTTP check passed for $service ($http_code)"
        return $HEALTH_PASSED
    else
        log_error "HTTP check failed for $service ($http_code)"
        send_alert "CRITICAL" "HTTP endpoint returned $http_code" "$service"
        return $HEALTH_FAILED
    fi
}

# Check application health endpoint
check_app_health() {
    local endpoint="http://localhost:8080/health"
    
    log_info "Checking application health endpoint..."
    
    local response
    response=$(curl -s --max-time 10 "$endpoint" 2>/dev/null)
    
    if [ $? -eq 0 ] && [ -n "$response" ]; then
        # Parse health status
        local status
        status=$(echo "$response" | jq -r '.status // "unknown"' 2>/dev/null || echo "unknown")
        
        case "$status" in
            "healthy")
                log_success "Application health check passed"
                return $HEALTH_PASSED
                ;;
            "degraded")
                log_warning "Application health check degraded"
                return $HEALTH_WARNING
                ;;
            "unhealthy")
                log_error "Application health check failed"
                return $HEALTH_FAILED
                ;;
            *)
                log_error "Invalid health status: $status"
                return $HEALTH_FAILED
                ;;
        esac
    else
        log_error "Failed to connect to application health endpoint"
        send_alert "CRITICAL" "Application health endpoint unreachable" "tts-app"
        return $HEALTH_FAILED
    fi
}

# Check database connectivity
check_database() {
    log_info "Checking database connectivity..."
    
    local db_check
    db_check=$(docker-compose -f "${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml" exec -T postgres pg_isready -U tts_user 2>/dev/null)
    
    if [ $? -eq 0 ] && echo "$db_check" | grep -q "accepting connections"; then
        log_success "Database health check passed"
        return $HEALTH_PASSED
    else
        log_error "Database health check failed"
        send_alert "CRITICAL" "Database is not accepting connections" "postgres"
        return $HEALTH_FAILED
    fi
}

# Check Redis connectivity
check_redis() {
    log_info "Checking Redis connectivity..."
    
    local redis_check
    redis_check=$(docker-compose -f "${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml" exec -T redis redis-cli ping 2>/dev/null)
    
    if [ $? -eq 0 ] && echo "$redis_check" | grep -q "PONG"; then
        log_success "Redis health check passed"
        return $HEALTH_PASSED
    else
        log_error "Redis health check failed"
        send_alert "CRITICAL" "Redis is not responding to ping" "redis"
        return $HEALTH_FAILED
    fi
}

# Check system resources
check_system_resources() {
    log_info "Checking system resources..."
    
    local failed_checks=0
    
    # Check CPU usage
    local cpu_usage
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 | cut -d',' -f1)
    
    if (( $(echo "$cpu_usage > 90" | bc -l 2>/dev/null || echo 0) )); then
        log_warning "High CPU usage: ${cpu_usage}%"
        ((failed_checks++))
    else
        log_success "CPU usage OK: ${cpu_usage}%"
    fi
    
    # Check memory usage
    local mem_usage
    mem_usage=$(free | grep Mem | awk '{printf("%.1f"), $3/$2 * 100.0}')
    
    if (( $(echo "$mem_usage > 90" | bc -l 2>/dev/null || echo 0) )); then
        log_warning "High memory usage: ${mem_usage}%"
        ((failed_checks++))
    else
        log_success "Memory usage OK: ${mem_usage}%"
    fi
    
    # Check disk usage
    local disk_usage
    disk_usage=$(df -h / | awk 'NR==2 {print $5}' | cut -d'%' -f1)
    
    if [ "$disk_usage" -gt 90 ]; then
        log_warning "High disk usage: ${disk_usage}%"
        ((failed_checks++))
    else
        log_success "Disk usage OK: ${disk_usage}%"
    fi
    
    # Check Docker containers
    local running_containers
    running_containers=$(docker ps --format "table {{.Names}}\t{{.Status}}" | grep -c "Up" || echo 0)
    
    if [ "$running_containers" -lt 3 ]; then
        log_warning "Low number of running containers: $running_containers"
        ((failed_checks++))
    else
        log_success "Container count OK: $running_containers"
    fi
    
    if [ $failed_checks -eq 0 ]; then
        return $HEALTH_PASSED
    elif [ $failed_checks -lt 3 ]; then
        return $HEALTH_WARNING
    else
        log_error "Multiple system resource checks failed"
        send_alert "WARNING" "System resources degraded" "system"
        return $HEALTH_FAILED
    fi
}

# Check application logs for errors
check_application_logs() {
    log_info "Checking application logs for errors..."
    
    local log_pattern="${PROJECT_ROOT}/logs/*.log"
    local error_count
    error_count=$(find $log_pattern -type f -exec grep -l "ERROR\|FATAL\|CRITICAL" {} \; 2>/dev/null | wc -l)
    
    if [ "$error_count" -eq 0 ]; then
        log_success "No errors found in application logs"
        return $HEALTH_PASSED
    else
        log_warning "Found $error_count log files with errors"
        
        # Check for recent errors (last 5 minutes)
        local recent_errors
        recent_errors=$(find $log_pattern -type f -newermt "5 minutes ago" -exec grep -l "ERROR\|FATAL\|CRITICAL" {} \; 2>/dev/null | wc -l)
        
        if [ "$recent_errors" -gt 0 ]; then
            log_error "Found $recent_errors files with recent errors"
            send_alert "WARNING" "Recent errors in application logs" "tts-app"
            return $HEALTH_WARNING
        fi
        
        return $HEALTH_WARNING
    fi
}

# Check TTS model availability
check_tts_models() {
    log_info "Checking TTS model availability..."
    
    local model_dir="${PROJECT_ROOT}/models_cache"
    
    if [ ! -d "$model_dir" ]; then
        log_error "Model cache directory not found"
        send_alert "CRITICAL" "Model cache directory missing" "tts-models"
        return $HEALTH_FAILED
    fi
    
    local model_count
    model_count=$(find "$model_dir" -name "*.bin" -o -name "*.safetensors" 2>/dev/null | wc -l)
    
    if [ "$model_count" -gt 0 ]; then
        log_success "TTS models available: $model_count model files"
        return $HEALTH_PASSED
    else
        log_warning "No TTS models found in cache"
        send_alert "WARNING" "No TTS models cached" "tts-models"
        return $HEALTH_WARNING
    fi
}

# Check Prometheus metrics
check_prometheus_metrics() {
    log_info "Checking Prometheus metrics availability..."
    
    local prometheus_url="http://localhost:9090/api/v1/targets"
    
    local response
    local status
    
    response=$(curl -s --max-time 10 "$prometheus_url" 2>/dev/null)
    status=$(echo "$response" | jq -r '.status' 2>/dev/null || echo "error")
    
    if [ "$status" = "success" ]; then
        log_success "Prometheus metrics check passed"
        return $HEALTH_PASSED
    else
        log_warning "Prometheus metrics not available"
        return $HEALTH_WARNING
    fi
}

# Generate health report
generate_health_report() {
    local report_file="${PROJECT_ROOT}/logs/health-report-$(date +%Y%m%d_%H%M%S).json"
    
    log_info "Generating health report: $report_file"
    
    cat > "$report_file" << EOF
{
    "timestamp": "$(date -Iseconds)",
    "hostname": "$(hostname)",
    "uptime": "$(uptime -p 2>/dev/null || uptime | cut -d',' -f1)",
    "checks": {
        "application": {
            "status": "$([ $app_status -eq $HEALTH_PASSED ] && echo "healthy" || echo "unhealthy")",
            "endpoint": "http://localhost:8080/health"
        },
        "database": {
            "status": "$([ $db_status -eq $HEALTH_PASSED ] && echo "healthy" || echo "unhealthy")",
            "type": "PostgreSQL"
        },
        "redis": {
            "status": "$([ $redis_status -eq $HEALTH_PASSED ] && echo "healthy" || echo "unhealthy")",
            "type": "Redis"
        },
        "system": {
            "status": "$([ $sys_status -eq $HEALTH_PASSED ] && echo "healthy" || ([ $sys_status -eq $HEALTH_WARNING ] && echo "degraded" || echo "unhealthy"))",
            "cpu_usage": "$cpu_usage%",
            "memory_usage": "$mem_usage%",
            "disk_usage": "${disk_usage}%"
        },
        "models": {
            "status": "$([ $model_status -eq $HEALTH_PASSED ] && echo "healthy" || echo "unhealthy")",
            "available_models": $model_count
        }
    },
    "overall_status": "$([ $overall_status -eq $HEALTH_PASSED ] && echo "healthy" || ([ $overall_status -eq $HEALTH_WARNING ] && echo "degraded" || echo "unhealthy"))"
}
EOF

    log_success "Health report generated: $report_file"
}

# Main health check function
main() {
    log_info "Starting comprehensive health check..."
    
    # Initialize status variables
    app_status=$HEALTH_PASSED
    db_status=$HEALTH_PASSED
    redis_status=$HEALTH_PASSED
    sys_status=$HEALTH_PASSED
    log_status=$HEALTH_PASSED
    model_status=$HEALTH_PASSED
    prom_status=$HEALTH_PASSED
    
    # Run all health checks
    check_app_health
    app_status=$?
    
    check_database
    db_status=$?
    
    check_redis
    redis_status=$?
    
    check_system_resources
    sys_status=$?
    
    check_application_logs
    log_status=$?
    
    check_tts_models
    model_status=$?
    
    check_prometheus_metrics
    prom_status=$?
    
    # Calculate overall status
    overall_status=$HEALTH_PASSED
    
    if [ $app_status -eq $HEALTH_FAILED ] || [ $db_status -eq $HEALTH_FAILED ] || [ $redis_status -eq $HEALTH_FAILED ]; then
        overall_status=$HEALTH_FAILED
    elif [ $app_status -eq $HEALTH_WARNING ] || [ $db_status -eq $HEALTH_WARNING ] || [ $redis_status -eq $HEALTH_WARNING ] || \
         [ $sys_status -eq $HEALTH_WARNING ] || [ $log_status -eq $HEALTH_WARNING ] || [ $model_status -eq $HEALTH_WARNING ]; then
        overall_status=$HEALTH_WARNING
    fi
    
    # Generate health report
    generate_health_report
    
    # Summary
    case $overall_status in
        $HEALTH_PASSED)
            log_success "Overall health check: PASSED - All systems operational"
            ;;
        $HEALTH_WARNING)
            log_warning "Overall health check: WARNING - Some systems degraded"
            ;;
        $HEALTH_FAILED)
            log_error "Overall health check: FAILED - Critical issues detected"
            ;;
    esac
    
    return $overall_status
}

# Continuous monitoring mode
continuous_monitoring() {
    local interval="${1:-300}"  # 5 minutes default
    
    log_info "Starting continuous health monitoring (interval: ${interval}s)"
    
    while true; do
        main
        local status=$?
        
        if [ $status -ne $HEALTH_PASSED ]; then
            log_warning "Health check failed, waiting ${interval}s before next check"
        fi
        
        sleep "$interval"
    done
}

# Show usage
usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --continuous [interval]    Run continuous monitoring (default: 300s)"
    echo "  --report                   Generate health report only"
    echo "  --check <service>          Run specific health check"
    echo "                             Services: app, db, redis, system, logs, models, prometheus"
    echo "  -h, --help                 Show this help"
    echo ""
    echo "Environment variables:"
    echo "  ALERT_WEBHOOK              Webhook URL for alerts"
    echo "  HEALTH_CONFIG              Path to health config file"
}

# Handle script arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --continuous)
            continuous_monitoring "${2:-300}"
            exit $?
            ;;
        --report)
            generate_health_report
            exit 0
            ;;
        --check)
            case "${2:-}" in
                app)
                    check_app_health
                    exit $?
                    ;;
                db)
                    check_database
                    exit $?
                    ;;
                redis)
                    check_redis
                    exit $?
                    ;;
                system)
                    check_system_resources
                    exit $?
                    ;;
                logs)
                    check_application_logs
                    exit $?
                    ;;
                models)
                    check_tts_models
                    exit $?
                    ;;
                prometheus)
                    check_prometheus_metrics
                    exit $?
                    ;;
                *)
                    log_error "Unknown service: $2"
                    usage
                    exit 1
                    ;;
            esac
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Run main health check
main
exit $?