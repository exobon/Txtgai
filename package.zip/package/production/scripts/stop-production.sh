#!/bin/bash

# TTS Production Stop Script
# Gracefully stop all production services

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
COMPOSE_FILE="${PROJECT_ROOT}/deployment_configs/docker/docker-compose.prod.yml"
PROFILE="${PROFILE:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

# Check if services are running
check_services_status() {
    log_info "Checking services status..."
    
    if ! docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q .; then
        log_warning "No services are currently running"
        return 1
    fi
    
    log_info "Running services:"
    docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running"
    
    return 0
}

# Get container stopping order
get_stop_order() {
    local services=()
    
    # Stop order: application → nginx → monitoring → logging → redis → postgres
    if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^tts-app$"; then
        services+=("tts-app")
    fi
    
    if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^nginx$"; then
        services+=("nginx")
    fi
    
    # Stop monitoring services
    if [ -n "${PROFILE:-}" ] && [[ "$PROFILE" == *"monitoring"* ]]; then
        if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^grafana$"; then
            services+=("grafana")
        fi
        if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^prometheus$"; then
            services+=("prometheus")
        fi
    fi
    
    # Stop logging services
    if [ -n "${PROFILE:-}" ] && [[ "$PROFILE" == *"logging"* ]]; then
        if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^kibana$"; then
            services+=("kibana")
        fi
        if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^logstash$"; then
            services+=("logstash")
        fi
        if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^elasticsearch$"; then
            services+=("elasticsearch")
        fi
    fi
    
    # Stop Redis and Postgres last
    if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^redis$"; then
        services+=("redis")
    fi
    
    if docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^postgres$"; then
        services+=("postgres")
    fi
    
    printf '%s\n' "${services[@]}"
}

# Gracefully stop services
graceful_shutdown() {
    local timeout="${1:-30}"
    local service="$2"
    
    log_info "Gracefully stopping $service..."
    
    # Send SIGTERM first for graceful shutdown
    if docker-compose -f "$COMPOSE_FILE" stop "$service" --timeout="$timeout"; then
        # Wait for container to stop
        local max_attempts=30
        local attempt=0
        
        while [ $attempt -lt $max_attempts ]; do
            if ! docker-compose -f "$COMPOSE_FILE" ps --services --filter "status=running" | grep -q "^$service$"; then
                log_success "$service stopped gracefully"
                return 0
            fi
            
            attempt=$((attempt + 1))
            sleep 1
        done
        
        # Force stop if not stopped gracefully
        log_warning "$service did not stop gracefully, forcing..."
        docker-compose -f "$COMPOSE_FILE" kill "$service" || true
    fi
}

# Force stop all services
force_shutdown() {
    log_info "Force stopping all services..."
    
    cd "$PROJECT_ROOT"
    docker-compose -f "$COMPOSE_FILE" kill || true
    
    log_success "All services force stopped"
}

# Remove stopped containers
remove_containers() {
    log_info "Removing stopped containers..."
    
    cd "$PROJECT_ROOT"
    docker-compose -f "$COMPOSE_FILE" rm -f || true
    
    log_success "Stopped containers removed"
}

# Clean up networks
cleanup_networks() {
    log_info "Cleaning up Docker networks..."
    
    cd "$PROJECT_ROOT"
    docker-compose -f "$COMPOSE_FILE" down --remove-orphans || true
    
    # Remove unused networks
    docker network prune -f || true
    
    log_success "Networks cleaned up"
}

# Show container logs before stopping
show_logs() {
    local service="$1"
    local lines="${2:-50}"
    
    log_info "Showing recent logs for $service:"
    echo "================================"
    
    docker-compose -f "$COMPOSE_FILE" logs --tail="$lines" "$service" || true
    
    echo "================================"
}

# Run final cleanup
final_cleanup() {
    log_info "Running final cleanup..."
    
    # Remove dangling volumes (be careful!)
    if [ "${REMOVE_VOLUMES:-false}" = "true" ]; then
        log_warning "Removing volumes (this will delete all data!)"
        read -p "Are you sure? Type 'yes' to confirm: " -r
        if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
            cd "$PROJECT_ROOT"
            docker-compose -f "$COMPOSE_FILE" down -v --remove-orphans
            log_warning "All volumes removed"
        else
            log_info "Volume removal cancelled"
        fi
    else
        # Remove unused volumes
        docker volume prune -f || true
    fi
    
    # Remove dangling images
    docker image prune -f || true
    
    # Remove unused containers
    docker container prune -f || true
    
    log_success "Final cleanup completed"
}

# Backup data before stopping (optional)
backup_before_stop() {
    if [ "${BACKUP_ON_STOP:-false}" = "true" ]; then
        log_info "Creating backup before stopping..."
        
        if [ -f "${PROJECT_ROOT}/production/scripts/backup.sh" ]; then
            "${PROJECT_ROOT}/production/scripts/backup.sh" backup || log_warning "Backup failed, continuing with shutdown"
        else
            log_warning "Backup script not found, skipping backup"
        fi
    fi
}

# Perform health check before stopping
health_check() {
    if curl -sf http://localhost:8080/health > /dev/null 2>&1; then
        log_info "Application is healthy before shutdown"
        return 0
    else
        log_warning "Application may not be healthy before shutdown"
        return 1
    fi
}

# Show system resources before stopping
show_resource_usage() {
    log_info "System resource usage before shutdown:"
    
    echo "=== Docker Containers ==="
    docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}\t{{.NetIO}}\t{{.BlockIO}}"
    echo
    
    echo "=== System Resources ==="
    echo "Memory:"
    free -h
    echo
    echo "Disk:"
    df -h / | tail -1
    echo
    echo "CPU:"
    top -bn1 | grep "Cpu(s)" || echo "CPU info not available"
}

# Main shutdown function
main() {
    log_info "Starting TTS production shutdown..."
    
    # Check if services are running
    if ! check_services_status; then
        log_info "No services are running, nothing to stop"
        exit 0
    fi
    
    # Optional pre-shutdown tasks
    if [ "${HEALTH_CHECK:-true}" = "true" ]; then
        health_check || log_warning "Health check failed, continuing with shutdown"
    fi
    
    if [ "${SHOW_RESOURCES:-false}" = "true" ]; then
        show_resource_usage
    fi
    
    if [ "${SHOW_LOGS:-false}" = "true" ]; then
        show_logs "tts-app" 100
    fi
    
    # Backup if requested
    backup_before_stop
    
    # Get stop order
    local stop_order
    mapfile -t stop_order < <(get_stop_order)
    
    if [ ${#stop_order[@]} -eq 0 ]; then
        log_warning "No services to stop"
        exit 0
    fi
    
    # Gracefully stop services
    for service in "${stop_order[@]}"; do
        if [ -n "${GRACEFUL_TIMEOUT:-}" ]; then
            graceful_shutdown "$GRACEFUL_TIMEOUT" "$service"
        else
            log_info "Stopping $service..."
            docker-compose -f "$COMPOSE_FILE" stop "$service"
            log_success "$service stopped"
        fi
    done
    
    # Remove containers
    remove_containers
    
    # Clean up networks
    cleanup_networks
    
    # Final cleanup
    final_cleanup
    
    log_success "TTS production shutdown completed successfully"
}

# Emergency stop function
emergency_stop() {
    log_error "Emergency stop requested!"
    
    cd "$PROJECT_ROOT"
    force_shutdown
    cleanup_networks
    
    log_success "Emergency shutdown completed"
    
    exit 0
}

# Show usage
usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --force                 Force stop all services immediately"
    echo "  --emergency             Emergency stop (kill all processes)"
    echo "  --timeout <seconds>     Graceful shutdown timeout (default: 30)"
    echo "  --no-health-check       Skip pre-shutdown health check"
    echo "  --show-logs             Show application logs before stopping"
    echo "  --show-resources        Show resource usage before stopping"
    echo "  --backup-on-stop        Create backup before stopping"
    echo "  --remove-volumes        Remove all volumes (DANGEROUS!)"
    echo "  --profile <profile>     Docker Compose profile (monitoring, logging)"
    echo "  --help                  Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 --timeout 60"
    echo "  $0 --show-logs --backup-on-stop"
    echo "  $0 --force"
    echo "  $0 --emergency"
    echo ""
    echo "Environment variables:"
    echo "  GRACEFUL_TIMEOUT        Default graceful shutdown timeout"
    echo "  HEALTH_CHECK           Run health check before stopping (default: true)"
    echo "  SHOW_RESOURCES         Show resource usage (default: false)"
    echo "  SHOW_LOGS              Show logs before stopping (default: false)"
    echo "  BACKUP_ON_STOP         Create backup before stopping (default: false)"
    echo "  REMOVE_VOLUMES         Remove all volumes (default: false)"
}

# Parse command line arguments
FORCE=false
EMERGENCY=false
TIMEOUT="${GRACEFUL_TIMEOUT:-30}"
HEALTH_CHECK="${HEALTH_CHECK:-true}"
SHOW_LOGS="${SHOW_LOGS:-false}"
SHOW_RESOURCES="${SHOW_RESOURCES:-false}"
BACKUP_ON_STOP="${BACKUP_ON_STOP:-false}"
REMOVE_VOLUMES="${REMOVE_VOLUMES:-false}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --force)
            FORCE=true
            ;;
        --emergency)
            EMERGENCY=true
            ;;
        --timeout)
            TIMEOUT="$2"
            shift
            ;;
        --no-health-check)
            HEALTH_CHECK=false
            ;;
        --show-logs)
            SHOW_LOGS=true
            ;;
        --show-resources)
            SHOW_RESOURCES=true
            ;;
        --backup-on-stop)
            BACKUP_ON_STOP=true
            ;;
        --remove-volumes)
            REMOVE_VOLUMES=true
            ;;
        --profile)
            PROFILE="$2"
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
        *)
            log_error "Unknown argument: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Handle emergency stop
if [ "$EMERGENCY" = true ]; then
    emergency_stop
fi

# Set profile environment variable
if [ -n "$PROFILE" ]; then
    export PROFILE="$PROFILE"
fi

# Set environment variables for export
export GRACEFUL_TIMEOUT="$TIMEOUT"
export HEALTH_CHECK
export SHOW_LOGS
export SHOW_RESOURCES
export BACKUP_ON_STOP
export REMOVE_VOLUMES

# Run main shutdown
if [ "$FORCE" = true ]; then
    log_warning "Force stop requested"
    force_shutdown
    cleanup_networks
    final_cleanup
else
    main
fi

exit 0