#!/bin/bash

# TTS Production Deployment Script
# Automated deployment with rollback and health checks

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
DEPLOY_ENV="${1:-production}"
APP_NAME="tts-converter"
VERSION="${2:-latest}"
BACKUP_RETENTION_DAYS=7

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check required commands
    local required_commands=("docker" "docker-compose" "curl" "jq")
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            log_error "Required command '$cmd' not found"
            exit 1
        fi
    done
    
    # Check Docker daemon
    if ! docker info &> /dev/null; then
        log_error "Docker daemon not running"
        exit 1
    fi
    
    # Check Docker Compose version
    local compose_version
    compose_version=$(docker-compose --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
    log_info "Docker Compose version: $compose_version"
    
    log_success "Prerequisites check passed"
}

# Backup current deployment
backup_current() {
    log_info "Creating backup of current deployment..."
    
    local backup_dir="${PROJECT_ROOT}/backups"
    mkdir -p "$backup_dir"
    
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="backup_${DEPLOY_ENV}_${timestamp}.tar.gz"
    
    # Create backup of volumes and database
    cd "$PROJECT_ROOT"
    docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T postgres pg_dump -U tts_user tts_db > "${backup_dir}/db_backup_${timestamp}.sql"
    tar -czf "${backup_dir}/${backup_file}" \
        -C "$backup_dir" \
        --exclude="*.tar.gz" \
        ./db_backup_${timestamp}.sql
    
    # Clean old backups
    find "$backup_dir" -name "backup_${DEPLOY_ENV}_*.tar.gz" -mtime +${BACKUP_RETENTION_DAYS} -delete
    
    log_success "Backup created: ${backup_file}"
}

# Pull latest images
pull_images() {
    log_info "Pulling latest Docker images..."
    
    cd "$PROJECT_ROOT"
    
    # Build application image
    docker build \
        -f deployment_configs/docker/Dockerfile \
        -t "${APP_NAME}:${VERSION}" \
        --build-arg BUILD_DATE="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        --build-arg VCS_REF="$(git rev-parse --short HEAD)" \
        --build-arg VERSION="$VERSION" \
        .
    
    log_success "Images pulled and built successfully"
}

# Deploy application
deploy_application() {
    log_info "Deploying application to $DEPLOY_ENV..."
    
    cd "$PROJECT_ROOT"
    
    # Stop existing containers gracefully
    if docker-compose -f deployment_configs/docker/docker-compose.prod.yml ps -q tts-app &> /dev/null; then
        log_info "Stopping existing containers..."
        docker-compose -f deployment_configs/docker/docker-compose.prod.yml stop tts-app
        docker-compose -f deployment_configs/docker/docker-compose.prod.yml rm -f tts-app
    fi
    
    # Start new containers
    docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d --remove-orphans
    
    log_success "Application deployed successfully"
}

# Health checks
wait_for_startup() {
    log_info "Waiting for application to start..."
    
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -sf http://localhost:8080/health > /dev/null 2>&1; then
            log_success "Application is healthy"
            return 0
        fi
        
        attempt=$((attempt + 1))
        log_info "Waiting for application... (attempt $attempt/$max_attempts)"
        sleep 10
    done
    
    log_error "Application failed to start within expected time"
    return 1
}

# Run health checks
run_health_checks() {
    log_info "Running health checks..."
    
    # Application health check
    if curl -sf http://localhost:8080/health > /dev/null; then
        log_success "Application health check passed"
    else
        log_error "Application health check failed"
        return 1
    fi
    
    # Database connectivity
    if docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T postgres pg_isready -U tts_user > /dev/null; then
        log_success "Database health check passed"
    else
        log_error "Database health check failed"
        return 1
    fi
    
    # Redis connectivity
    if docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T redis redis-cli ping > /dev/null; then
        log_success "Redis health check passed"
    else
        log_error "Redis health check failed"
        return 1
    fi
    
    log_success "All health checks passed"
}

# Rollback function
rollback() {
    log_error "Deployment failed! Initiating rollback..."
    
    cd "$PROJECT_ROOT"
    
    # Stop current containers
    docker-compose -f deployment_configs/docker/docker-compose.prod.yml stop tts-app
    docker-compose -f deployment_configs/docker/docker-compose.prod.yml rm -f tts-app
    
    # Find latest backup
    local latest_backup
    latest_backup=$(find backups -name "backup_${DEPLOY_ENV}_*.tar.gz" -type f | sort | tail -1)
    
    if [ -n "$latest_backup" ]; then
        log_info "Rolling back to backup: $latest_backup"
        tar -xzf "$latest_backup" -C backups/
        local db_backup
        db_backup=$(find backups -name "db_backup_*.sql" | sort | tail -1)
        
        if [ -n "$db_backup" ]; then
            docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec -T postgres psql -U tts_user -d tts_db < "$db_backup"
        fi
        
        # Restart containers with previous image
        docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d tts-app
        log_success "Rollback completed"
    else
        log_error "No backup found for rollback"
        return 1
    fi
}

# Cleanup old Docker resources
cleanup() {
    log_info "Cleaning up old Docker resources..."
    
    cd "$PROJECT_ROOT"
    
    # Remove dangling images
    docker image prune -f
    
    # Remove stopped containers
    docker container prune -f
    
    # Remove unused volumes
    docker volume prune -f
    
    log_success "Cleanup completed"
}

# Main deployment flow
main() {
    log_info "Starting deployment of $APP_NAME version $VERSION to $DEPLOY_ENV"
    
    # Trap errors for rollback
    trap rollback ERR
    
    check_prerequisites
    
    # Backup current deployment
    backup_current
    
    # Pull latest images
    pull_images
    
    # Deploy application
    deploy_application
    
    # Wait for startup and run health checks
    if wait_for_startup && run_health_checks; then
        log_success "Deployment completed successfully!"
        log_info "Application is available at http://localhost:8080"
        log_info "Grafana dashboard: http://localhost:3000"
        log_info "Prometheus: http://localhost:9090"
    else
        log_error "Health checks failed after deployment"
        rollback
        exit 1
    fi
    
    # Cleanup
    cleanup
    
    log_success "Deployment process completed"
}

# Show usage
usage() {
    echo "Usage: $0 [environment] [version]"
    echo ""
    echo "Arguments:"
    echo "  environment  Target environment (default: production)"
    echo "  version      Application version (default: latest)"
    echo ""
    echo "Examples:"
    echo "  $0 production 1.0.0"
    echo "  $0 staging latest"
    echo ""
    echo "Environment variables:"
    echo "  DEPLOY_ENV   Target environment"
    echo "  VERSION      Application version"
}

# Handle script arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
        *)
            if [ -z "${DEPLOY_ENV_SET:-}" ]; then
                DEPLOY_ENV="$1"
                DEPLOY_ENV_SET=1
            else
                VERSION="$1"
            fi
            ;;
    esac
    shift
done

# Run main deployment
main