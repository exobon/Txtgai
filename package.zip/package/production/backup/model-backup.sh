#!/bin/bash

# TTS Model Cache Backup Script
# Backup and sync TTS model cache with verification and compression

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-${PROJECT_ROOT}/backups/models}"
RETENTION_DAYS="${MODEL_BACKUP_RETENTION_DAYS:-14}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${PROJECT_ROOT}/logs/model-backup-${TIMESTAMP}.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE" >&2
}

# Get model directories from environment
get_model_directories() {
    local env_file="${PROJECT_ROOT}/.env"
    
    if [ ! -f "$env_file" ]; then
        log_error "Environment file not found: $env_file"
        return 1
    fi
    
    source "$env_file"
    
    # Define model directories to backup
    MODEL_DIRS=(
        "${TRANSFORMERS_CACHE:-/app/models_cache}"
        "${HF_HOME:-/tmp/huggingface}"
        "${TORCH_HOME:-/tmp/torch}"
        "${PROJECT_ROOT}/models_cache"
        "${PROJECT_ROOT}/cache"
    )
    
    log_info "Model directories to backup: ${#MODEL_DIRS[@]}"
    return 0
}

# Create backup directory
setup_backup_directory() {
    mkdir -p "$BACKUP_DIR"
    chmod 750 "$BACKUP_DIR"
    log_info "Backup directory: $BACKUP_DIR"
}

# Pre-backup checks
pre_backup_checks() {
    log_info "Running pre-backup checks..."
    
    # Check if any model directories exist
    local found_dirs=0
    for dir in "${MODEL_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            ((found_dirs++))
        fi
    done
    
    if [ $found_dirs -eq 0 ]; then
        log_warning "No model directories found to backup"
        return 1
    fi
    
    log_info "Found $found_dirs model directories"
    
    # Check available disk space
    local available_space
    available_space=$(df "$BACKUP_DIR" | awk 'NR==2 {print $4}')
    local total_size=0
    
    # Calculate approximate backup size
    for dir in "${MODEL_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            local dir_size
            dir_size=$(du -sb "$dir" 2>/dev/null | cut -f1)
            total_size=$((total_size + dir_size))
        fi
    done
    
    local required_space=$((total_size * 2 / 1024))  # 2x for compression
    
    if [ "$available_space" -lt "$required_space" ]; then
        log_error "Insufficient disk space. Available: ${available_space}KB, Required: ${required_space}KB"
        return 1
    fi
    
    log_info "Available space: ${available_space}KB, Required: ${required_space}KB"
    
    # Check for required tools
    local required_tools=("rsync" "tar" "gzip")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            log_error "Required tool not found: $tool"
            return 1
        fi
    done
    
    log_success "Pre-backup checks completed"
}

# Get model information
collect_model_info() {
    log_info "Collecting model information..."
    
    local model_info_file="${BACKUP_DIR}/model_info_${TIMESTAMP}.json"
    
    cat > "$model_info_file" << EOF
{
    "backup_info": {
        "timestamp": "$(date -Iseconds)",
        "hostname": "$(hostname)",
        "model_directories": [
EOF

    local first=true
    for dir in "${MODEL_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            if [ "$first" = false ]; then
                echo "," >> "$model_info_file"
            fi
            first=false
            
            local dir_size
            dir_size=$(du -sb "$dir" | cut -f1)
            local file_count
            file_count=$(find "$dir" -type f | wc -l)
            
            echo "            {" >> "$model_info_file"
            echo "                \"path\": \"$dir\"," >> "$model_info_file"
            echo "                \"size_bytes\": $dir_size," >> "$model_info_file"
            echo "                \"file_count\": $file_count" >> "$model_info_file"
            echo -n "            }" >> "$model_info_file"
        fi
    done
    
    cat >> "$model_info_file" << EOF

        ],
        "system": {
            "available_space_kb": $(df "$BACKUP_DIR" | awk 'NR==2 {print $4}'),
            "disk_usage": "$(df -h "$BACKUP_DIR" | tail -1)"
        }
    }
}
EOF

    log_success "Model information collected"
}

# Backup individual model directory
backup_model_directory() {
    local source_dir="$1"
    local backup_name="$2"
    
    if [ ! -d "$source_dir" ]; then
        log_warning "Directory not found: $source_dir"
        return 0
    fi
    
    log_info "Backing up directory: $(basename "$source_dir")"
    
    local backup_file="${BACKUP_DIR}/${backup_name}_${TIMESTAMP}.tar.gz"
    
    # Use rsync for efficient syncing, then tar for compression
    local temp_dir="${BACKUP_DIR}/temp_${backup_name}_${TIMESTAMP}"
    
    # Create temp directory
    mkdir -p "$temp_dir"
    
    # Sync files with rsync (preserving permissions and timestamps)
    if rsync -av \
        --delete \
        --progress \
        --exclude='*.tmp' \
        --exclude='*.temp' \
        --exclude='__pycache__' \
        --exclude='*.pyc' \
        --exclude='.git' \
        "$source_dir/" "$temp_dir/"; then
        
        log_success "Rsync completed for $source_dir"
    else
        log_error "Rsync failed for $source_dir"
        rm -rf "$temp_dir"
        return 1
    fi
    
    # Create compressed archive
    log_info "Creating compressed archive: $(basename "$backup_file")"
    
    cd "$temp_dir"
    if tar -czf "$backup_file" .; then
        local backup_size
        backup_size=$(du -h "$backup_file" | cut -f1)
        log_success "Archive created: ${backup_size}"
    else
        log_error "Archive creation failed"
        cd "$BACKUP_DIR"
        rm -rf "$temp_dir"
        return 1
    fi
    
    # Cleanup temp directory
    cd "$BACKUP_DIR"
    rm -rf "$temp_dir"
    
    # Verify backup
    log_info "Verifying backup integrity..."
    if tar -tzf "$backup_file" > /dev/null 2>&1; then
        log_success "Backup integrity verification passed"
        return 0
    else
        log_error "Backup integrity verification failed"
        return 1
    fi
}

# Create model manifest
create_model_manifest() {
    log_info "Creating model backup manifest..."
    
    local manifest_file="${BACKUP_DIR}/model_manifest_${TIMESTAMP}.json"
    
    cat > "$manifest_file" << EOF
{
    "backup_info": {
        "timestamp": "$(date -Iseconds)",
        "hostname": "$(hostname)",
        "backup_type": "model_cache",
        "version": "1.0.0",
        "model_directories": [
EOF

    local first=true
    local total_backups=0
    
    for dir in "${MODEL_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            local dir_name
            dir_name=$(basename "$dir")
            local backup_file="${BACKUP_DIR}/${dir_name}_${TIMESTAMP}.tar.gz"
            
            if [ -f "$backup_file" ]; then
                if [ "$first" = false ]; then
                    echo "," >> "$manifest_file"
                fi
                first=false
                
                local backup_size
                backup_size=$(du -b "$backup_file" | cut -f1)
                
                echo "            {" >> "$manifest_file"
                echo "                \"source_directory\": \"$dir\"," >> "$manifest_file"
                echo "                \"backup_file\": \"$(basename "$backup_file")\"," >> "$manifest_file"
                echo "                \"backup_size_bytes\": $backup_size," >> "$manifest_file"
                echo "                \"compressed\": true" >> "$manifest_file"
                echo -n "            }" >> "$manifest_file"
                
                ((total_backups++))
            fi
        fi
    done
    
    cat >> "$manifest_file" << EOF

        ],
        "statistics": {
            "total_backups": $total_backups,
            "retention_days": $RETENTION_DAYS
        }
    }
}
EOF

    log_success "Model manifest created"
}

# Verify model backup
verify_model_backup() {
    local backup_file="$1"
    
    log_info "Verifying model backup: $(basename "$backup_file")"
    
    if [ ! -f "$backup_file" ]; then
        log_error "Backup file not found: $backup_file"
        return 1
    fi
    
    # Test archive integrity
    if ! tar -tzf "$backup_file" > /dev/null 2>&1; then
        log_error "Archive integrity check failed"
        return 1
    fi
    
    # Extract to temp directory and verify content
    local temp_dir
    temp_dir=$(mktemp -d)
    
    if tar -xzf "$backup_file" -C "$temp_dir"; then
        # Check for expected model files
        local model_files
        model_files=$(find "$temp_dir" -name "*.bin" -o -name "*.safetensors" -o -name "*.onnx" | wc -l)
        
        log_info "Found $model_files model files in backup"
        
        # Cleanup
        rm -rf "$temp_dir"
        
        if [ "$model_files" -gt 0 ]; then
            log_success "Model backup verification passed"
            return 0
        else
            log_warning "No model files found in backup"
            return 1
        fi
    else
        log_error "Failed to extract backup for verification"
        rm -rf "$temp_dir"
        return 1
    fi
}

# Cleanup old backups
cleanup_old_backups() {
    log_info "Cleaning up old backups (older than $RETENTION_DAYS days)..."
    
    local deleted_count=0
    local freed_space=0
    
    # Clean up old model backups
    while IFS= read -r -d '' old_backup; do
        local size
        size=$(du -sb "$old_backup" | cut -f1)
        freed_space=$((freed_space + size))
        
        log_info "Deleting old backup: $(basename "$old_backup")"
        rm -f "$old_backup"
        ((deleted_count++))
    done < <(find "$BACKUP_DIR" -name "*_model_*.tar.gz" -o -name "*_huggingface_*.tar.gz" -o -name "*_torch_*.tar.gz" -type f -mtime +$RETENTION_DAYS -print0)
    
    # Also cleanup old manifest files
    find "$BACKUP_DIR" -name "model_info_*.json" -mtime +$RETENTION_DAYS -delete 2>/dev/null || true
    find "$BACKUP_DIR" -name "model_manifest_*.json" -mtime +$RETENTION_DAYS -delete 2>/dev/null || true
    
    if [ $deleted_count -gt 0 ]; then
        local freed_mb
        freed_mb=$((freed_space / 1024 / 1024))
        log_success "Cleaned up $deleted_count old backups, freed ${freed_mb}MB"
    else
        log_info "No old backups to clean up"
    fi
}

# Restore model backup
restore_model_backup() {
    local backup_file="$1"
    local target_dir="$2"
    
    log_info "Restoring model backup: $backup_file to $target_dir"
    
    if [ ! -f "$backup_file" ]; then
        log_error "Backup file not found: $backup_file"
        return 1
    fi
    
    # Create target directory
    mkdir -p "$target_dir"
    
    # Extract backup
    if tar -xzf "$backup_file" -C "$target_dir"; then
        log_success "Model backup restored to $target_dir"
        return 0
    else
        log_error "Failed to restore model backup"
        return 1
    fi
}

# Sync model directories to remote storage (optional)
sync_to_remote() {
    local remote_dest="${REMOTE_BACKUP_DEST:-}"
    
    if [ -z "$remote_dest" ]; then
        log_info "Remote backup destination not configured, skipping sync"
        return 0
    fi
    
    log_info "Syncing backups to remote destination: $remote_dest"
    
    if rsync -av --delete "$BACKUP_DIR/" "$remote_dest/"; then
        log_success "Remote sync completed"
        return 0
    else
        log_warning "Remote sync failed"
        return 1
    fi
}

# Send notification
send_notification() {
    local status="$1"
    local message="$2"
    
    # Email notification (if configured)
    if [ -n "${MODEL_BACKUP_EMAIL:-}" ]; then
        echo "$message" | mail -s "TTS Model Backup - $status" "$MODEL_BACKUP_EMAIL" 2>/dev/null || true
    fi
    
    # Slack notification (if configured)
    if [ -n "${MODEL_BACKUP_SLACK_WEBHOOK:-}" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"TTS Model Backup - $status\\n$message\"}" \
            "$MODEL_BACKUP_SLACK_WEBHOOK" 2>/dev/null || true
    fi
}

# Main backup function
main() {
    log_info "Starting TTS model cache backup process..."
    
    # Ensure log directory exists
    mkdir -p "$(dirname "$LOG_FILE")"
    
    # Get model directories
    if ! get_model_directories; then
        exit 1
    fi
    
    # Setup backup directory
    setup_backup_directory
    
    # Run pre-backup checks
    if ! pre_backup_checks; then
        send_notification "FAILED" "Pre-backup checks failed"
        exit 1
    fi
    
    # Collect model information
    collect_model_info
    
    # Backup each model directory
    local backup_status=0
    local backed_up_count=0
    
    for dir in "${MODEL_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            local dir_name
            dir_name=$(basename "$dir")
            
            if backup_model_directory "$dir" "$dir_name"; then
                ((backed_up_count++))
            else
                backup_status=1
            fi
        fi
    done
    
    if [ $backed_up_count -gt 0 ]; then
        # Create manifest
        create_model_manifest
        
        # Verify all backups
        log_info "Verifying all backups..."
        for dir in "${MODEL_DIRS[@]}"; do
            if [ -d "$dir" ]; then
                local dir_name
                dir_name=$(basename "$dir")
                local backup_file="${BACKUP_DIR}/${dir_name}_${TIMESTAMP}.tar.gz"
                
                verify_model_backup "$backup_file" || backup_status=1
            fi
        done
    fi
    
    # Cleanup old backups
    cleanup_old_backups
    
    # Sync to remote storage
    sync_to_remote
    
    # Final status
    if [ $backup_status -eq 0 ] && [ $backed_up_count -gt 0 ]; then
        log_success "Model backup completed successfully ($backed_up_count directories backed up)"
        send_notification "SUCCESS" "Model backup completed: $backed_up_count directories backed up"
        return 0
    else
        log_error "Model backup completed with errors"
        send_notification "FAILED" "Model backup completed with errors"
        return 1
    fi
}

# Show usage
usage() {
    echo "Usage: $0 [command] [options]"
    echo ""
    echo "Commands:"
    echo "  backup       Create model backup (default)"
    echo "  restore      Restore from backup"
    echo "  verify       Verify backup integrity"
    echo "  list         List available backups"
    echo "  cleanup      Cleanup old backups"
    echo ""
    echo "Options:"
    echo "  --file <file>    Backup file for restore/verify operations"
    echo "  --target <dir>   Target directory for restore"
    echo "  --retention <days>  Backup retention period (default: 14)"
    echo "  --output-dir <dir>  Backup output directory"
    echo "  -h, --help       Show this help"
    echo ""
    echo "Environment variables:"
    echo "  MODEL_BACKUP_RETENTION_DAYS    Backup retention period"
    echo "  BACKUP_DIR                    Backup directory location"
    echo "  REMOTE_BACKUP_DEST            Remote backup destination"
    echo "  MODEL_BACKUP_EMAIL            Email for notifications"
    echo "  MODEL_BACKUP_SLACK_WEBHOOK    Slack webhook for notifications"
}

# Parse command line arguments
command="backup"
backup_file=""
target_dir=""
retention_days="$RETENTION_DAYS"
backup_output_dir="$BACKUP_DIR"

while [[ $# -gt 0 ]]; do
    case $1 in
        backup)
            command="backup"
            ;;
        restore)
            command="restore"
            ;;
        verify)
            command="verify"
            ;;
        list)
            command="list"
            ;;
        cleanup)
            command="cleanup"
            ;;
        --file)
            backup_file="$2"
            shift
            ;;
        --target)
            target_dir="$2"
            shift
            ;;
        --retention)
            retention_days="$2"
            shift
            ;;
        --output-dir)
            backup_output_dir="$2"
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
        *)
            log_error "Unknown argument: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Set environment variables
export MODEL_BACKUP_RETENTION_DAYS="$retention_days"
export BACKUP_DIR="$backup_output_dir"

# Execute command
case $command in
    backup)
        main
        exit $?
        ;;
    restore)
        if [ -z "$backup_file" ] || [ -z "$target_dir" ]; then
            log_error "Backup file and target directory required for restore"
            usage
            exit 1
        fi
        restore_model_backup "$backup_file" "$target_dir"
        exit $?
        ;;
    verify)
        if [ -z "$backup_file" ]; then
            log_error "Backup file required for verification"
            usage
            exit 1
        fi
        verify_model_backup "$backup_file"
        exit $?
        ;;
    list)
        log_info "Available model backups:"
        ls -la "$BACKUP_DIR"/*_${TIMESTAMP}*.tar.gz 2>/dev/null || log_info "No backups found"
        exit 0
        ;;
    cleanup)
        cleanup_old_backups
        exit 0
        ;;
esac