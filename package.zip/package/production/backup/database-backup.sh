#!/bin/bash

# TTS Database Backup Script
# Comprehensive database backup with rotation and verification

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-${PROJECT_ROOT}/backups/database}"
RETENTION_DAYS="${DB_BACKUP_RETENTION_DAYS:-30}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${PROJECT_ROOT}/logs/db-backup-${TIMESTAMP}.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE" >&2
}

# Get database credentials from environment
get_db_credentials() {
    local env_file="${PROJECT_ROOT}/.env"
    
    if [ ! -f "$env_file" ]; then
        log_error "Environment file not found: $env_file"
        return 1
    fi
    
    source "$env_file"
    
    # Parse DATABASE_URL
    if [[ $DATABASE_URL =~ postgresql://([^:]+):([^@]+)@([^:]+):([0-9]+)/(.+) ]]; then
        DB_USER="${BASH_REMATCH[1]}"
        DB_PASSWORD="${BASH_REMATCH[2]}"
        DB_HOST="${BASH_REMATCH[3]}"
        DB_PORT="${BASH_REMATCH[4]}"
        DB_NAME="${BASH_REMATCH[5]}"
        return 0
    else
        log_error "Invalid DATABASE_URL format"
        return 1
    fi
}

# Create backup directory
setup_backup_directory() {
    mkdir -p "$BACKUP_DIR"
    chmod 750 "$BACKUP_DIR"
    log_info "Backup directory: $BACKUP_DIR"
}

# Pre-backup checks
pre_backup_checks() {
    log_info "Running pre-backup checks..."
    
    # Check if database is accessible
    if ! PGPASSWORD="$DB_PASSWORD" pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME"; then
        log_error "Database is not accessible"
        return 1
    fi
    
    # Check available disk space
    local available_space
    available_space=$(df "$BACKUP_DIR" | awk 'NR==2 {print $4}')
    local required_space=1048576  # 1GB in KB
    
    if [ "$available_space" -lt "$required_space" ]; then
        log_error "Insufficient disk space. Available: ${available_space}KB, Required: ${required_space}KB"
        return 1
    fi
    
    # Check database connections
    local connection_count
    connection_count=$(PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c "SELECT count(*) FROM pg_stat_activity WHERE state = 'active';" 2>/dev/null || echo "0")
    
    log_info "Active database connections: $connection_count"
    
    # Create backup metadata file
    local metadata_file="${BACKUP_DIR}/backup_metadata_${TIMESTAMP}.json"
    cat > "$metadata_file" << EOF
{
    "backup_info": {
        "timestamp": "$(date -Iseconds)",
        "hostname": "$(hostname)",
        "database": {
            "host": "$DB_HOST",
            "port": "$DB_PORT",
            "name": "$DB_NAME",
            "user": "$DB_USER",
            "active_connections": $connection_count
        },
        "system": {
            "available_space_kb": $available_space,
            "disk_usage": "$(df -h "$BACKUP_DIR" | tail -1)"
        }
    }
}
EOF

    log_success "Pre-backup checks completed"
}

# Database backup function
perform_database_backup() {
    log_info "Starting database backup..."
    
    local backup_base="${BACKUP_DIR}/tts_db_backup_${TIMESTAMP}"
    
    # Custom format backup (binary, most efficient)
    local custom_backup="${backup_base}.custom"
    log_info "Creating custom format backup: $(basename "$custom_backup")"
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --verbose \
        --clean \
        --if-exists \
        --create \
        --format=custom \
        --no-owner \
        --no-privileges \
        --file="$custom_backup"; then
        
        local custom_size
        custom_size=$(du -h "$custom_backup" | cut -f1)
        log_success "Custom format backup created: ${custom_size}"
    else
        log_error "Custom format backup failed"
        return 1
    fi
    
    # Plain SQL backup (for portability)
    local sql_backup="${backup_base}.sql"
    log_info "Creating plain SQL backup: $(basename "$sql_backup")"
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --clean \
        --if-exists \
        --create \
        --no-owner \
        --no-privileges \
        --file="$sql_backup"; then
        
        local sql_size
        sql_size=$(du -h "$sql_backup" | cut -f1)
        log_success "Plain SQL backup created: ${sql_size}"
        
        # Compress SQL backup
        log_info "Compressing SQL backup..."
        gzip "$sql_backup"
        log_success "SQL backup compressed"
    else
        log_error "Plain SQL backup failed"
        return 1
    fi
    
    # Compress custom backup
    log_info "Compressing custom backup..."
    gzip "$custom_backup"
    log_success "Custom backup compressed"
    
    echo "$backup_base"
}

# Schema-only backup
perform_schema_backup() {
    log_info "Creating schema-only backup..."
    
    local schema_backup="${BACKUP_DIR}/tts_db_schema_${TIMESTAMP}.sql"
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --schema-only \
        --no-owner \
        --no-privileges \
        --file="$schema_backup"; then
        
        local schema_size
        schema_size=$(du -h "$schema_backup" | cut -f1)
        log_success "Schema backup created: ${schema_size}"
        
        # Compress schema backup
        gzip "$schema_backup"
        
        return 0
    else
        log_error "Schema backup failed"
        return 1
    fi
}

# Data-only backup
perform_data_backup() {
    log_info "Creating data-only backup..."
    
    local data_backup="${BACKUP_DIR}/tts_db_data_${TIMESTAMP}.sql"
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --data-only \
        --no-owner \
        --no-privileges \
        --file="$data_backup"; then
        
        local data_size
        data_size=$(du -h "$data_backup" | cut -f1)
        log_success "Data-only backup created: ${data_size}"
        
        # Compress data backup
        gzip "$data_backup"
        
        return 0
    else
        log_error "Data-only backup failed"
        return 1
    fi
}

# Database statistics backup
backup_database_statistics() {
    log_info "Creating database statistics backup..."
    
    local stats_backup="${BACKUP_DIR}/tts_db_stats_${TIMESTAMP}.sql"
    
    # Get database statistics
    cat > "$stats_backup" << EOF
-- Database Statistics Backup
-- Generated: $(date)

-- Database size
SELECT 'Database Size' as metric, pg_size_pretty(pg_database_size('$DB_NAME')) as value;

-- Table sizes
SELECT 'Table' as table_name, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname NOT IN ('information_schema', 'pg_catalog')
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Index sizes
SELECT 'Index' as index_name, pg_size_pretty(pg_relation_size(indexrelname)) as size
FROM pg_stat_user_indexes
ORDER BY pg_relation_size(indexrelname) DESC;

-- Most active tables
SELECT 'Table' as table_name, n_tup_ins + n_tup_upd + n_tup_del as total_activity
FROM pg_stat_user_tables
ORDER BY total_activity DESC;
EOF

    # Compress statistics backup
    gzip "$stats_backup"
    
    log_success "Database statistics backup created"
}

# Verify backup integrity
verify_backup_integrity() {
    local backup_base="$1"
    
    log_info "Verifying backup integrity..."
    
    # Check if backup files exist
    local custom_backup="${backup_base}.custom.gz"
    local sql_backup="${backup_base}.sql.gz"
    
    if [ ! -f "$custom_backup" ] || [ ! -f "$sql_backup" ]; then
        log_error "Backup files not found"
        return 1
    fi
    
    # Test decompression
    if ! gzip -t "$custom_backup" 2>/dev/null; then
        log_error "Custom backup is corrupted"
        return 1
    fi
    
    if ! gzip -t "$sql_backup" 2>/dev/null; then
        log_error "SQL backup is corrupted"
        return 1
    fi
    
    # Test pg_restore with custom backup (dry run)
    log_info "Testing custom backup restoration..."
    
    local test_db="tts_backup_test_$(date +%s)"
    
    if PGPASSWORD="$DB_PASSWORD" createdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$test_db" 2>/dev/null; then
        if PGPASSWORD="$DB_PASSWORD" pg_restore \
            -h "$DB_HOST" \
            -p "$DB_PORT" \
            -U "$DB_USER" \
            -d "$test_db" \
            --verbose \
            --clean \
            --no-owner \
            --no-privileges \
            "$custom_backup" 2>/dev/null; then
            
            # Drop test database
            PGPASSWORD="$DB_PASSWORD" dropdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$test_db" 2>/dev/null || true
            
            log_success "Backup integrity verification passed"
            return 0
        else
            PGPASSWORD="$DB_PASSWORD" dropdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$test_db" 2>/dev/null || true
            log_error "Backup integrity verification failed"
            return 1
        fi
    else
        log_warning "Could not create test database, skipping restoration test"
        return 0
    fi
}

# Create backup manifest
create_backup_manifest() {
    local backup_base="$1"
    
    log_info "Creating backup manifest..."
    
    local manifest_file="${backup_base}_manifest.json"
    local custom_backup="${backup_base}.custom.gz"
    local sql_backup="${backup_base}.sql.gz"
    
    local custom_size
    custom_size=$(du -b "$custom_backup" | cut -f1)
    
    local sql_size
    sql_size=$(du -b "$sql_backup" | cut -f1)
    
    cat > "$manifest_file" << EOF
{
    "backup_info": {
        "timestamp": "$(date -Iseconds)",
        "hostname": "$(hostname)",
        "database": {
            "host": "$DB_HOST",
            "port": "$DB_PORT",
            "name": "$DB_NAME",
            "user": "$DB_USER"
        },
        "files": {
            "custom_backup": {
                "path": "$(basename "$custom_backup")",
                "size_bytes": $custom_size,
                "format": "custom",
                "compressed": true
            },
            "sql_backup": {
                "path": "$(basename "$sql_backup")",
                "size_bytes": $sql_size,
                "format": "plain",
                "compressed": true
            }
        },
        "verification": {
            "integrity_check": "passed",
            "restoration_test": "completed"
        },
        "retention": {
            "retention_days": $RETENTION_DAYS,
            "created_at": "$(date -Iseconds)"
        }
    }
}
EOF

    log_success "Backup manifest created"
}

# Cleanup old backups
cleanup_old_backups() {
    log_info "Cleaning up old backups (older than $RETENTION_DAYS days)..."
    
    local deleted_count=0
    local freed_space=0
    
    while IFS= read -r -d '' old_backup; do
        local size
        size=$(du -sb "$old_backup" | cut -f1)
        freed_space=$((freed_space + size))
        
        log_info "Deleting old backup: $(basename "$old_backup")"
        rm -f "$old_backup"
        ((deleted_count++))
    done < <(find "$BACKUP_DIR" -name "tts_db_backup_*.gz" -type f -mtime +$RETENTION_DAYS -print0)
    
    # Also cleanup metadata files
    find "$BACKUP_DIR" -name "backup_metadata_*.json" -mtime +$RETENTION_DAYS -delete 2>/dev/null || true
    
    if [ $deleted_count -gt 0 ]; then
        local freed_mb
        freed_mb=$((freed_space / 1024 / 1024))
        log_success "Cleaned up $deleted_count old backups, freed ${freed_mb}MB"
    else
        log_info "No old backups to clean up"
    fi
}

# Send notification (optional)
send_notification() {
    local status="$1"
    local message="$2"
    
    # Email notification (if configured)
    if [ -n "${BACKUP_NOTIFICATION_EMAIL:-}" ]; then
        echo "$message" | mail -s "TTS Database Backup - $status" "$BACKUP_NOTIFICATION_EMAIL" 2>/dev/null || true
    fi
    
    # Slack notification (if configured)
    if [ -n "${BACKUP_SLACK_WEBHOOK:-}" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"TTS Database Backup - $status\\n$message\"}" \
            "$BACKUP_SLACK_WEBHOOK" 2>/dev/null || true
    fi
}

# Main backup function
main() {
    log_info "Starting TTS database backup process..."
    
    # Ensure log directory exists
    mkdir -p "$(dirname "$LOG_FILE")"
    
    # Get database credentials
    if ! get_db_credentials; then
        exit 1
    fi
    
    # Setup backup directory
    setup_backup_directory
    
    # Run pre-backup checks
    if ! pre_backup_checks; then
        send_notification "FAILED" "Pre-backup checks failed"
        exit 1
    fi
    
    # Perform backups
    local backup_status=0
    
    local backup_base
    if backup_base=$(perform_database_backup); then
        verify_backup_integrity "$backup_base" || backup_status=1
        create_backup_manifest "$backup_base" || backup_status=1
    else
        backup_status=1
    fi
    
    # Additional backups
    perform_schema_backup || backup_status=1
    perform_data_backup || backup_status=1
    backup_database_statistics || backup_status=1
    
    # Cleanup old backups
    cleanup_old_backups
    
    # Final status
    local backup_file="${backup_base}.custom.gz"
    
    if [ $backup_status -eq 0 ]; then
        local backup_size
        backup_size=$(du -h "$backup_file" | cut -f1)
        log_success "Database backup completed successfully: $backup_size"
        send_notification "SUCCESS" "Database backup completed: $backup_size"
        echo "$backup_file"
        return 0
    else
        log_error "Database backup completed with errors"
        send_notification "FAILED" "Database backup completed with errors"
        return 1
    fi
}

# Show usage
usage() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --schema-only       Backup schema only"
    echo "  --data-only         Backup data only"
    echo "  --verify            Verify existing backup"
    echo "  --cleanup           Cleanup old backups only"
    echo "  --retention <days>  Backup retention period (default: 30)"
    echo "  --output-dir <dir>  Backup output directory"
    echo "  -h, --help          Show this help"
    echo ""
    echo "Environment variables:"
    echo "  DB_BACKUP_RETENTION_DAYS    Backup retention period"
    echo "  BACKUP_DIR                  Backup directory location"
    echo "  BACKUP_NOTIFICATION_EMAIL   Email for notifications"
    echo "  BACKUP_SLACK_WEBHOOK        Slack webhook for notifications"
}

# Parse command line arguments
SCHEMA_ONLY=false
DATA_ONLY=false
VERIFY_MODE=false
CLEANUP_ONLY=false
RETENTION_DAYS="${DB_BACKUP_RETENTION_DAYS:-30}"
BACKUP_DIR="${BACKUP_DIR:-${PROJECT_ROOT}/backups/database}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --schema-only)
            SCHEMA_ONLY=true
            ;;
        --data-only)
            DATA_ONLY=true
            ;;
        --verify)
            VERIFY_MODE=true
            ;;
        --cleanup)
            CLEANUP_ONLY=true
            ;;
        --retention)
            RETENTION_DAYS="$2"
            shift
            ;;
        --output-dir)
            BACKUP_DIR="$2"
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
        *)
            log_error "Unknown argument: $1"
            usage
            exit 1
            ;;
    esac
    shift
done

# Set environment variables
export DB_BACKUP_RETENTION_DAYS="$RETENTION_DAYS"
export BACKUP_DIR="$BACKUP_DIR"

# Execute based on mode
if [ "$CLEANUP_ONLY" = true ]; then
    cleanup_old_backups
    exit 0
elif [ "$SCHEMA_ONLY" = true ]; then
    get_db_credentials && setup_backup_directory && perform_schema_backup
    exit $?
elif [ "$DATA_ONLY" = true ]; then
    get_db_credentials && setup_backup_directory && perform_data_backup
    exit $?
elif [ "$VERIFY_MODE" = true ]; then
    if [ -n "${1:-}" ]; then
        verify_backup_integrity "$1"
    else
        log_error "Backup file path required for verification"
        usage
        exit 1
    fi
    exit $?
else
    # Full backup
    main
    exit $?
fi