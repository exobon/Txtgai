# TTS Production Deployment Guide
# Comprehensive guide for production deployment and operations

## Table of Contents
1. [Overview](#overview)
2. [Directory Structure](#directory-structure)
3. [Quick Start](#quick-start)
4. [Deployment Scripts](#deployment-scripts)
5. [Configuration Files](#configuration-files)
6. [Monitoring & Alerting](#monitoring--alerting)
7. [Backup & Recovery](#backup--recovery)
8. [Maintenance](#maintenance)
9. [Troubleshooting](#troubleshooting)

---

## Overview

This production deployment package provides a complete infrastructure for deploying, monitoring, and maintaining the TTS (Text-to-Speech) Converter application in production environments. It includes automated deployment scripts, comprehensive monitoring, backup procedures, and disaster recovery documentation.

### Key Features
- **Automated Deployment** - One-command deployment with rollback capability
- **Health Monitoring** - Comprehensive health checks and alerting
- **Backup & Recovery** - Automated backups with point-in-time recovery
- **Security Hardening** - Production-grade security configurations
- **Observability** - Full monitoring stack with Grafana and Prometheus
- **Disaster Recovery** - Complete DR plan and procedures

---

## Directory Structure

```
production/
├── config/                          # Production configuration files
│   ├── production.yml              # Application settings
│   ├── logging.yml                 # Logging configuration
│   └── security.yml                # Security settings
├── scripts/                         # Deployment and management scripts
│   ├── deploy.sh                   # Automated deployment
│   ├── setup-env.sh                # Environment setup
│   ├── health-check.sh             # Health monitoring
│   ├── start-production.sh         # Production startup
│   └── stop-production.sh          # Graceful shutdown
├── monitoring/                      # Monitoring configuration
│   ├── prometheus.yml              # Prometheus config
│   ├── alertmanager.yml            # Alert routing
│   ├── alert_rules.yml             # Alert definitions
│   ├── grafana-dashboard.json      # Dashboard config
│   └── logstash-pipeline.conf      # Log processing
├── backup/                          # Backup scripts and procedures
│   ├── database-backup.sh          # Database backup
│   └── model-backup.sh             # Model cache backup
└── docs/                            # Documentation
    ├── disaster-recovery.md        # DR plan
    └── recovery-procedures.md      # Recovery procedures
```

---

## Quick Start

### 1. Environment Setup
```bash
# Initialize production environment
./production/scripts/setup-env.sh

# Review and customize configuration
vim production/config/production.yml
vim .env
```

### 2. Deploy Application
```bash
# Deploy to production
./production/scripts/deploy.sh production latest

# Verify deployment
./production/scripts/health-check.sh
```

### 3. Access Services
- **Main Application:** http://localhost:8080
- **Grafana Dashboard:** http://localhost:3000
- **Prometheus:** http://localhost:9090
- **Kibana:** http://localhost:5601 (if logging enabled)

---

## Deployment Scripts

### deploy.sh
Automated deployment with rollback capability.

**Usage:**
```bash
./production/scripts/deploy.sh [environment] [version]

# Examples
./production/scripts/deploy.sh production 1.0.0
./production/scripts/deploy.sh staging latest
```

**Features:**
- Prerequisites validation
- Automatic backup before deployment
- Health checks and verification
- Rollback on failure
- Cleanup of old resources

### setup-env.sh
Environment configuration and system preparation.

**Usage:**
```bash
./production/scripts/setup-env.sh [options]

# Options
--force     # Overwrite existing .env file
--test      # Only test configuration
--validate  # Validate existing configuration
```

**Features:**
- Generates secure environment variables
- Creates production directories
- SSL certificate generation (for testing)
- Systemd service creation
- Configuration validation

### health-check.sh
Comprehensive health monitoring and alerting.

**Usage:**
```bash
./production/scripts/health-check.sh [options]

# Options
--continuous [interval]  # Run continuous monitoring
--report                # Generate health report
--check <service>       # Run specific check

# Examples
./production/scripts/health-check.sh --check app
./production/scripts/health-check.sh --continuous 300
```

**Checks Performed:**
- Application health endpoint
- Database connectivity
- Redis connectivity
- System resources (CPU, memory, disk)
- TTS model availability
- Log error monitoring

### start-production.sh
Start all production services with proper initialization.

**Usage:**
```bash
./production/scripts/start-production.sh [options]

# Options
--profile <profile>  # Docker Compose profile (monitoring, logging)
--no-build          # Skip building images
--no-wait           # Don't wait for application health

# Examples
./production/scripts/start-production.sh --profile monitoring
./production/scripts/start-production.sh --profile monitoring,logging
```

### stop-production.sh
Graceful shutdown of all production services.

**Usage:**
```bash
./production/scripts/stop-production.sh [options]

# Options
--force              # Force stop all services
--emergency          # Emergency stop (kill all)
--timeout <seconds>  # Graceful shutdown timeout
--backup-on-stop     # Create backup before stopping

# Examples
./production/scripts/stop-production.sh --timeout 60
./production/scripts/stop-production.sh --force
```

---

## Configuration Files

### production.yml
Main application configuration covering:
- Server settings and performance tuning
- TTS model configuration
- Database and Redis settings
- Security and authentication
- Feature flags and API settings

### logging.yml
Structured logging configuration:
- Multiple output formats (JSON, simple)
- Log rotation and retention
- Integration with Elasticsearch
- Performance logging
- Security filtering

### security.yml
Production security settings:
- Authentication and authorization
- Rate limiting configuration
- Input validation and sanitization
- HTTPS and TLS settings
- Security headers and CORS

---

## Monitoring & Alerting

### Prometheus Configuration
- **Metrics Collection:** Application, database, Redis, system metrics
- **Service Discovery:** Static configurations for all services
- **Retention:** 30 days storage with 10GB limit
- **Alerts:** Comprehensive alert rules for all components

### Grafana Dashboards
- **System Overview:** Real-time service status
- **Application Performance:** Request rates, response times, error rates
- **TTS Model Performance:** Inference times, memory usage, cache hit rates
- **Database Performance:** Connection pools, query performance
- **System Resources:** CPU, memory, disk, network usage

### Alerting
- **Notification Channels:** Email, Slack, PagerDuty
- **Alert Severity:** Critical, High, Warning
- **Routing:** Service-specific alert routing
- **Escalation:** Automatic escalation for critical alerts

### Log Aggregation
- **Elasticsearch:** Centralized log storage and indexing
- **Logstash:** Log processing and enrichment
- **Kibana:** Log visualization and searching
- **Retention:** 90-day log retention

---

## Backup & Recovery

### Database Backups
```bash
# Create database backup
./production/backup/database-backup.sh backup

# Restore database
./production/backup/database-backup.sh restore --file /backups/latest.sql.gz

# Verify backup
./production/backup/database-backup.sh verify --file /backups/latest.sql.gz
```

**Features:**
- Custom and plain SQL formats
- Automated compression
- Integrity verification
- Point-in-time recovery
- Retention management (30 days)

### Model Cache Backups
```bash
# Create model cache backup
./production/backup/model-backup.sh backup

# Restore model cache
./production/backup/model-backup.sh restore \
  --file /backups/latest/transformers_cache.tar.gz \
  --target /app/models_cache
```

**Features:**
- Efficient rsync-based backups
- Compression and deduplication
- Model integrity verification
- Selective restoration
- Retention management (14 days)

### Disaster Recovery
**RTO (Recovery Time Objective):** 4 hours
**RPO (Recovery Point Objective):** 1 hour

**Recovery Procedures:**
1. **Infrastructure Recovery** - Provision new systems
2. **Data Recovery** - Restore database and cache
3. **Application Recovery** - Deploy and configure
4. **Verification** - Health checks and testing

---

## Maintenance

### Regular Tasks

#### Daily
- Review health check reports
- Monitor system metrics
- Check backup completion
- Review error logs

#### Weekly
- Update security patches
- Review performance trends
- Test disaster recovery procedures
- Clean up old logs

#### Monthly
- Security audit
- Performance optimization review
- Backup verification
- Documentation updates

#### Quarterly
- Full disaster recovery drill
- Security penetration testing
- Compliance audit
- Business continuity test

### Health Check Automation
```bash
# Add to crontab for automated monitoring
# Run health checks every 5 minutes
*/5 * * * * /path/to/production/scripts/health-check.sh --continuous 300

# Create daily backup
0 2 * * * /path/to/production/backup/database-backup.sh backup

# Create weekly model backup
0 3 * * 0 /path/to/production/backup/model-backup.sh backup
```

---

## Troubleshooting

### Common Issues

#### Application Won't Start
1. Check logs: `docker-compose logs tts-app`
2. Verify environment variables: `./production/scripts/setup-env.sh --validate`
3. Check resource availability: `free -h && df -h`
4. Restart services: `./production/scripts/stop-production.sh --force && ./production/scripts/start-production.sh`

#### Database Connection Issues
1. Check PostgreSQL status: `docker-compose ps postgres`
2. Verify connection: `docker-compose exec postgres pg_isready`
3. Check logs: `docker-compose logs postgres`
4. Restart database: `docker-compose restart postgres`

#### High Memory Usage
1. Check container stats: `docker stats`
2. Identify memory leaks in logs
3. Restart problematic containers
4. Scale resources if needed

#### Poor Performance
1. Check system resources: `./production/scripts/health-check.sh --check system`
2. Review application metrics in Grafana
3. Check database performance
4. Verify network connectivity

### Log Locations
- **Application Logs:** `/project_root/logs/`
- **Docker Logs:** `docker-compose logs [service]`
- **System Logs:** `/var/log/`
- **Backup Logs:** `/project_root/logs/backup-*.log`

### Diagnostic Commands
```bash
# Check all services status
docker-compose -f deployment_configs/docker/docker-compose.prod.yml ps

# View resource usage
docker stats --no-stream

# Check disk usage
df -h && du -sh /project_root/*

# Check network connectivity
netstat -tlnp | grep -E ":(80|443|8080|5432|6379)"

# Check Docker network
docker network ls && docker network inspect tts-converter_tts-network
```

---

## Support

### Documentation
- **Deployment Guide:** This document
- **Disaster Recovery Plan:** `production/docs/disaster-recovery.md`
- **Recovery Procedures:** `production/docs/recovery-procedures.md`
- **API Documentation:** http://localhost:8080/docs (when running)

### Emergency Contacts
- **On-Call Engineer:** [Contact information]
- **Engineering Manager:** [Contact information]
- **DevOps Team:** [Contact information]

### Additional Resources
- **Monitoring Dashboards:**
  - Grafana: http://localhost:3000
  - Prometheus: http://localhost:9090
  - Kibana: http://localhost:5601
- **Status Page:** [Status page URL]
- **Issue Tracker:** [Issue tracker URL]

---

## Security Considerations

### Production Hardening
- **SSL/TLS:** Configure proper certificates for HTTPS
- **Firewall:** Restrict access to necessary ports only
- **Authentication:** Enable API authentication if required
- **Monitoring:** Enable security monitoring and alerting
- **Updates:** Regular security updates and patches

### Access Control
- **SSH Keys:** Use key-based authentication
- **Password Policy:** Strong password requirements
- **Network Segmentation:** Isolate production from other environments
- **Audit Logging:** Track all administrative actions

### Data Protection
- **Encryption:** Encrypt data at rest and in transit
- **Backup Security:** Secure backup storage and access
- **Access Logging:** Log all data access attempts
- **Retention Policies:** Implement data retention and deletion

---

## Performance Tuning

### Application Performance
- **Worker Processes:** Adjust based on CPU cores
- **Connection Pools:** Optimize database and Redis pools
- **Caching:** Enable appropriate caching levels
- **Model Loading:** Preload frequently used models

### Infrastructure Performance
- **Resource Allocation:** Monitor and adjust container limits
- **Storage:** Use SSD storage for better I/O performance
- **Network:** Optimize network configurations
- **Load Balancing:** Implement load balancing for high availability

### Monitoring Performance
- **Metrics Collection:** Balance detail vs. overhead
- **Alert Thresholds:** Set appropriate alert thresholds
- **Retention Policies:** Manage storage for metrics and logs

---

## Compliance

### Data Protection
- **GDPR:** Implement data protection and privacy measures
- **CCPA:** California Consumer Privacy Act compliance
- **SOX:** Sarbanes-Oxley compliance (if applicable)
- **HIPAA:** Health Insurance Portability and Accountability Act (if applicable)

### Security Standards
- **SOC 2:** Service Organization Control 2 compliance
- **ISO 27001:** Information security management
- **NIST:** National Institute of Standards and Technology guidelines
- **PCI DSS:** Payment Card Industry Data Security Standard (if applicable)

---

*This documentation should be updated regularly and reviewed for accuracy. Last updated: November 2, 2024*