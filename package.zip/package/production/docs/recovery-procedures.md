# TTS Recovery Documentation
# Step-by-step recovery procedures for various failure scenarios

## Quick Reference

### Emergency Contacts
- **On-Call Engineer:** [Contact information]
- **Engineering Manager:** [Contact information]
- **Cloud Provider Support:** [Contact information]

### Quick Commands
```bash
# Check system status
docker-compose -f deployment_configs/docker/docker-compose.prod.yml ps

# Emergency shutdown
./production/scripts/stop-production.sh --emergency

# System recovery
./production/scripts/deploy.sh production

# Health check
./production/scripts/health-check.sh
```

---

## Recovery Procedures by Scenario

### 1. Complete System Failure

#### Symptom
- All services down
- No response from any endpoints
- Infrastructure completely unavailable

#### Recovery Steps

**Step 1: Initial Assessment (5-10 minutes)**
```bash
# Check if any services are still running
docker ps -a

# Check system resources
free -h
df -h
top -bn1

# Check logs for errors
tail -50 /var/log/syslog
```

**Step 2: Provision New Infrastructure**
```bash
# If using cloud provider, provision new instances
# Example for AWS:
aws ec2 run-instances --image-id ami-xxxxx --instance-type t3.large --key-name my-key

# If on-premise, use backup hardware
# Follow standard hardware provisioning procedures
```

**Step 3: Install Required Software**
```bash
# Install Docker and Docker Compose
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install additional tools
apt-get update && apt-get install -y curl wget git
```

**Step 4: Deploy Application**
```bash
# Clone repository
git clone https://github.com/company/tts-converter.git
cd tts-converter

# Run setup
./production/scripts/setup-env.sh --force

# Deploy application
./production/scripts/deploy.sh production

# Verify deployment
./production/scripts/health-check.sh
```

**Step 5: Restore Data**
```bash
# Restore database
./production/backup/database-backup.sh restore --file /backups/latest/tts_db_backup_YYYYMMDD_HHMMSS.tar.gz

# Restore model cache
./production/backup/model-backup.sh restore --file /backups/latest/transformers_cache_latest.tar.gz --target /app/models_cache
```

**Step 6: Verification**
```bash
# Test application endpoints
curl http://localhost:8080/health
curl http://localhost:8080/api/status

# Generate test TTS output
curl -X POST http://localhost:8080/api/generate \
  -H "Content-Type: application/json" \
  -d '{"text": "test", "voice": "default"}' \
  --output test_output.wav

# Check logs for errors
docker-compose logs -f tts-app
```

---

### 2. Database Failure

#### Symptom
- Application returns database errors
- Connection timeouts to database
- PostgreSQL not responding

#### Recovery Steps

**Step 1: Assess Database Status**
```bash
# Check if PostgreSQL container is running
docker-compose -f deployment_configs/docker/docker-compose.prod.yml ps postgres

# Check PostgreSQL logs
docker-compose -f deployment_configs/docker/docker-compose.prod.yml logs postgres

# Test database connectivity
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres pg_isready -U tts_user
```

**Step 2: Restart Database Service**
```bash
# Restart PostgreSQL container
docker-compose -f deployment_configs/docker/docker-compose.prod.yml restart postgres

# Wait for startup
sleep 30

# Check if service is ready
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres pg_isready -U tts_user
```

**Step 3: Verify Database Integrity**
```bash
# Check database consistency
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres psql -U tts_user -d tts_db -c "VACUUM ANALYZE;"

# Check table integrity
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres psql -U tts_user -d tts_db -c "SELECT schemaname, tablename FROM pg_tables WHERE schemaname NOT IN ('information_schema', 'pg_catalog');"

# Check for corruption
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres psql -U tts_user -d tts_db -c "SELECT * FROM pg_stat_database WHERE datname = 'tts_db';"
```

**Step 4: Restore from Backup (if needed)**
```bash
# Stop application to prevent write operations
./production/scripts/stop-production.sh

# Restore database from backup
./production/backup/database-backup.sh restore --file /backups/latest/tts_db_backup_YYYYMMDD_HHMMSS.tar.gz

# Verify restored data
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres psql -U tts_user -d tts_db -c "SELECT COUNT(*) FROM users;"

# Restart application
./production/scripts/start-production.sh
```

**Step 5: Performance Verification**
```bash
# Check database performance
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec postgres psql -U tts_user -d tts_db -c "SELECT * FROM pg_stat_activity WHERE state = 'active';"

# Test application functionality
curl http://localhost:8080/health
```

---

### 3. Application Service Failure

#### Symptom
- TTS application container down or restarting
- Health checks failing
- 500 errors from application

#### Recovery Steps

**Step 1: Check Application Status**
```bash
# Check container status
docker-compose -f deployment_configs/docker/docker-compose.prod.yml ps tts-app

# Check application logs
docker-compose -f deployment_configs/docker/docker-compose.prod.yml logs tts-app --tail=100

# Check resource usage
docker stats tts-app-prod
```

**Step 2: Restart Application Service**
```bash
# Restart application container
docker-compose -f deployment_configs/docker/docker-compose.prod.yml restart tts-app

# Monitor startup
docker-compose -f deployment_configs/docker/docker-compose.prod.yml logs tts-app -f

# Wait for health check to pass
sleep 60

# Verify health
curl http://localhost:8080/health
```

**Step 3: Check Configuration**
```bash
# Verify environment variables
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec tts-app env | grep -E "(DB_|REDIS_|SECRET_)"

# Check configuration files
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec tts-app ls -la /app/config/

# Verify dependencies
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec tts-app python -c "import psycopg2; import redis; print('Dependencies OK')"
```

**Step 4: Redeploy Application (if needed)**
```bash
# Stop and remove current container
docker-compose -f deployment_configs/docker/docker-compose.prod.yml down tts-app

# Build fresh image
docker build -f deployment_configs/docker/Dockerfile -t tts-converter:latest .

# Start application
docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d tts-app

# Monitor startup
docker-compose -f deployment_configs/docker/docker-compose.prod.yml logs tts-app -f
```

---

### 4. Redis Cache Failure

#### Symptom
- Application errors related to session/cache
- Redis connection refused errors
- Slow application performance

#### Recovery Steps

**Step 1: Check Redis Status**
```bash
# Check Redis container status
docker-compose -f deployment_configs/docker/docker-compose.prod.yml ps redis

# Test Redis connectivity
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec redis redis-cli ping

# Check Redis logs
docker-compose -f deployment_configs/docker/docker-compose.prod.yml logs redis --tail=50
```

**Step 2: Restart Redis**
```bash
# Restart Redis container
docker-compose -f deployment_configs/docker/docker-compose.prod.yml restart redis

# Wait for startup
sleep 10

# Verify Redis is working
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec redis redis-cli ping
```

**Step 3: Check Data Persistence**
```bash
# Check if data is persisted
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec redis redis-cli info persistence

# Verify key spaces
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec redis redis-cli info keyspace

# Test application connectivity
curl http://localhost:8080/health
```

---

### 5. Model Cache Corruption

#### Symptom
- TTS generation failing
- Model loading errors
- Slow model inference

#### Recovery Steps

**Step 1: Verify Model Cache**
```bash
# Check model cache directory
ls -la /app/models_cache/

# Check for corrupted files
find /app/models_cache/ -name "*.bin" -exec file {} \;

# Test model loading
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec tts-app python -c "from transformers import AutoModel; print('Models OK')"
```

**Step 2: Clear Corrupted Cache**
```bash
# Stop application
./production/scripts/stop-production.sh

# Backup current cache (for analysis)
mv /app/models_cache /app/models_cache_backup

# Create fresh cache directory
mkdir -p /app/models_cache

# Start application
./production/scripts/start-production.sh
```

**Step 3: Restore from Backup**
```bash
# Restore model cache from backup
./production/backup/model-backup.sh restore \
  --file /backups/latest/transformers_cache_latest.tar.gz \
  --target /app/models_cache

# Verify restored cache
ls -la /app/models_cache/

# Restart application
./production/scripts/stop-production.sh
./production/scripts/start-production.sh
```

**Step 4: Recreate Cache (if backup unavailable)**
```bash
# Download commonly used models
./scripts/download_models.py --models speecht5 bark xtts_v2

# Verify models are working
docker-compose -f deployment_configs/docker/docker-compose.prod.yml exec tts-app python -c "
from transformers import SpeechT5Processor, SpeechT5ForTextToSpeech
processor = SpeechT5Processor.from_pretrained('microsoft/speecht5_tts')
model = SpeechT5ForTextToSpeech.from_pretrained('microsoft/speecht5_tts')
print('Models loaded successfully')
"
```

---

### 6. Disk Space Issues

#### Symptom
- Application crashes due to disk full
- Cannot write to logs or output files
- Docker containers failing to start

#### Recovery Steps

**Step 1: Check Disk Usage**
```bash
# Check overall disk usage
df -h

# Check largest directories
du -sh /* | sort -hr

# Check Docker disk usage
docker system df

# Check log files size
find /var/log -type f -size +100M -exec ls -lh {} \;
```

**Step 2: Clean Up Temporary Files**
```bash
# Clean Docker system
docker system prune -a --volumes

# Clean old logs
find /var/log -name "*.log.*" -mtime +30 -delete

# Clean temporary files
find /tmp -type f -mtime +7 -delete

# Clean old backups
find /project_root/backups -name "*.tar.gz" -mtime +90 -delete
```

**Step 3: Rotate Logs**
```bash
# Force log rotation
logrotate -f /etc/logrotate.conf

# Check log rotation status
logrotate -d /etc/logrotate.conf
```

**Step 4: Monitor Disk Usage**
```bash
# Set up disk monitoring
./production/scripts/health-check.sh --check system

# Monitor in real-time
watch -n 5 'df -h | grep -E "(Filesystem|/dev/)"'
```

---

### 7. Network Connectivity Issues

#### Symptom
- External API calls failing
- Database connection timeouts
- Slow application performance

#### Recovery Steps

**Step 1: Check Network Status**
```bash
# Check network connectivity
ping -c 4 8.8.8.8

# Check DNS resolution
nslookup google.com

# Check network interfaces
ip addr show

# Check Docker network
docker network ls
docker network inspect tts-converter_tts-network
```

**Step 2: Restart Network Services**
```bash
# Restart Docker network
docker-compose -f deployment_configs/docker/docker-compose.prod.yml down
docker network prune -f
docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d

# Restart network services (if on Linux)
sudo systemctl restart networking
sudo systemctl restart docker
```

**Step 3: Check Firewall Rules**
```bash
# Check iptables rules
sudo iptables -L -n

# Check if required ports are open
sudo netstat -tlnp | grep -E ":(80|443|8080|5432|6379)"

# Test specific port connectivity
telnet localhost 5432
```

---

## Recovery Verification Checklist

After any recovery procedure, verify:

### Application Health
- [ ] Health endpoint returns 200: `curl http://localhost:8080/health`
- [ ] API status endpoint works: `curl http://localhost:8080/api/status`
- [ ] Database connectivity: Check in application logs
- [ ] Redis connectivity: Check in application logs

### Functionality Testing
- [ ] Generate test TTS output successfully
- [ ] User authentication works (if applicable)
- [ ] File upload/download works (if applicable)
- [ ] API rate limiting works (if applicable)

### Performance Verification
- [ ] Response time < 2 seconds for health check
- [ ] Database query performance is normal
- [ ] Memory usage is within limits (< 80%)
- [ ] CPU usage is normal (< 80%)

### Monitoring and Alerts
- [ ] Grafana dashboards show green status
- [ ] Prometheus metrics are collecting
- [ ] No critical alerts are firing
- [ ] Log aggregation is working

---

## Post-Recovery Actions

### Immediate Actions
1. **Document the incident**
   - Timeline of events
   - Actions taken
   - Root cause (if identified)
   - Recovery time achieved

2. **Update stakeholders**
   - Send recovery notification
   - Update status page
   - Notify customers (if affected)

3. **Verify everything is working**
   - Run comprehensive health checks
   - Test all critical functionality
   - Monitor for 24 hours

### Follow-up Actions
1. **Conduct post-mortem**
   - Schedule within 48 hours
   - Invite all involved personnel
   - Document lessons learned

2. **Update documentation**
   - Update recovery procedures
   - Improve automation scripts
   - Add new monitoring/alerting

3. **Prevent recurrence**
   - Implement fixes
   - Add monitoring
   - Update runbooks

---

## Emergency Contacts

### Internal
- **On-Call Engineer:** [Phone] [Email]
- **Engineering Manager:** [Phone] [Email]
- **DevOps Team:** [Email]

### External
- **Cloud Provider Support:** [Phone] [Portal]
- **Database Support:** [Phone] [Email]
- **Network Provider:** [Phone] [Email]

### Escalation
- **Level 1:** On-Call Engineer (0-30 minutes)
- **Level 2:** Engineering Manager (30-60 minutes)
- **Level 3:** CTO/VP Engineering (> 60 minutes)

---

*This document should be updated after each recovery incident and reviewed quarterly.*