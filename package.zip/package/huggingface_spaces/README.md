# 🎤 Text-to-Speech Converter

**Convert text to natural speech using state-of-the-art AI models**

A Hugging Face Space that provides high-quality text-to-speech conversion using multiple AI models including SpeechT5, MMS-TTS, and Bark. Features emotion control, multilingual support, and optimized performance for cloud deployment.

[![Hugging Face Spaces](https://img.shields.io/badge/%F0%9F%A4%97-Hugging%20Face%20Spaces-blue)](https://huggingface.co/spaces)
[![Python](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🚀 Features

### Core Functionality
- **Multiple TTS Models**: Choose from SpeechT5, MMS-TTS, or Bark
- **Emotion Control**: Add emotional expression (neutral, happy, sad, excited, whisper)
- **Multilingual Support**: English, Spanish, French, German, Italian, Portuguese, Russian, Chinese, Japanese, Korean
- **Real-time Generation**: Instant speech synthesis
- **Download Support**: Save generated audio files
- **Memory Optimized**: Efficient resource usage for cloud deployment

### Supported Models
- **SpeechT5** (Microsoft): High-quality English TTS with natural prosody
- **MMS-TTS** (Meta): Fast, multilingual TTS with good quality/speed balance  
- **Bark** (Suno): Creative TTS with emotions and sound effects

### Technical Features
- **GPU Acceleration**: Automatic CUDA detection and optimization
- **Memory Management**: Efficient model loading and cleanup
- **Error Handling**: Robust error recovery and fallback strategies
- **Progress Tracking**: Real-time generation status
- **Batch Support**: Multiple text processing (coming soon)

## 📖 Usage Instructions

### Getting Started
1. **Wait for Loading**: The application automatically loads TTS models on first use
2. **Enter Text**: Type or paste your text in the input field (max 1000 characters)
3. **Select Model**: Choose from SpeechT5, MMS-TTS, or Bark
4. **Choose Settings**: Select emotion and language preferences
5. **Generate**: Click "Generate Speech" to create audio
6. **Listen/Download**: Play the generated audio or download the file

### Model Selection Guide

| Model | Best For | Speed | Quality | Memory Usage |
|-------|----------|-------|---------|--------------|
| **SpeechT5** | Professional English TTS | Medium | High | Medium |
| **MMS-TTS** | Multilingual applications | Fast | Medium | Low |
| **Bark** | Creative content with emotions | Slow | Very High | High |

### Emotion Examples
- **Neutral**: Standard voice without emotional coloring
- **Happy**: Cheerful, upbeat tone
- **Sad**: Melancholic, slower pace
- **Excited**: Energetic, faster delivery
- **Whisper**: Soft, intimate tone

### Language Support
- English (en) - All models
- Spanish (es) - MMS-TTS, Bark
- French (fr) - MMS-TTS, Bark  
- German (de) - MMS-TTS, Bark
- Italian (it) - MMS-TTS, Bark
- Portuguese (pt) - MMS-TTS, Bark
- Russian (ru) - MMS-TTS, Bark
- Chinese (zh) - MMS-TTS, Bark
- Japanese (ja) - MMS-TTS, Bark
- Korean (ko) - MMS-TTS, Bark

## 💡 Example Usage

### Basic Text-to-Speech
```
Input: "Hello world! Welcome to the text-to-speech converter."
Model: SpeechT5
Emotion: Happy
Language: English
Output: Natural, cheerful English speech
```

### Multilingual Example
```
Input: "Hola mundo, ¿cómo estás hoy?"
Model: MMS-TTS
Emotion: Neutral
Language: Spanish
Output: Natural Spanish speech
```

### Emotional Expression
```
Input: "[Happy] This is absolutely fantastic news!"
Model: Bark
Emotion: Happy
Language: English
Output: Enthusiastic, excited delivery with emotional emphasis
```

### Creative Content
```
Input: "[Whisper] In a world far away, where dreams come true..."
Model: Bark
Emotion: Whisper
Language: English
Output: Soft, intimate narration style
```

## 🔧 Technical Specifications

### Performance
- **First Load**: 30-90 seconds (model download and initialization)
- **Generation Speed**: 2-15x real-time (model dependent)
- **Memory Usage**: 2-6GB (model dependent)
- **Supported Text Length**: Up to 1000 characters
- **Audio Format**: WAV, 16kHz sample rate

### Hardware Requirements
- **Minimum**: CPU with 2+ cores, 4GB RAM
- **Recommended**: CPU-plus hardware tier
- **GPU**: Automatically detected (CUDA if available)

### Supported File Formats
- **Input**: Text (plain, UTF-8)
- **Output**: WAV audio files
- **Download**: Direct file download supported

## 🛠️ Advanced Features

### Memory Management
- Automatic model caching for faster subsequent loads
- Intelligent memory cleanup to prevent resource exhaustion
- Graceful fallback to smaller models on memory constraints

### Error Recovery
- Automatic retry on generation failures
- Fallback to alternative models if primary fails
- Detailed error messages for troubleshooting

### Performance Optimization
- CPU/GPU auto-detection and optimization
- Efficient batch processing pipeline
- Model-specific optimizations for speed and quality

## 🔒 Privacy & Security

- **No Data Storage**: Your text never leaves the Hugging Face infrastructure
- **Local Processing**: All AI models run on Hugging Face servers
- **No Tracking**: No personal data collection or usage tracking
- **Open Source**: All code is transparent and auditable

## 🐛 Troubleshooting

### Common Issues

**Model Loading Takes Too Long**
- First-time use requires model download (30-90 seconds)
- Try refreshing the page if stuck
- Use MMS-TTS for faster loading

**Generation Fails**
- Check text length (max 1000 characters)
- Try a different model if one fails
- Ensure stable internet connection

**Audio Quality Issues**
- Try different models for better quality
- Adjust text for clearer pronunciation
- Use shorter sentences for better results

**Memory Errors**
- Use MMS-TTS (lowest memory usage)
- Clear memory with "Clean Memory" button
- Refresh page to reset state

**Slow Performance**
- Use MMS-TTS for fastest generation
- Reduce text length for faster processing
- CPU-plus tier provides better performance

### Error Messages
- **"Input text cannot be empty"**: Enter some text to convert
- **"Failed to load model"**: Try refreshing or using a different model
- **"Generation failed"**: Text may be too long or contain unsupported characters
- **"Memory limit exceeded"**: Use MMS-TTS or clear memory

### Performance Tips
1. **Choose the Right Model**: 
   - Speed: MMS-TTS > SpeechT5 > Bark
   - Quality: Bark > SpeechT5 > MMS-TTS
   - Memory: MMS-TTS < SpeechT5 < Bark

2. **Optimize Text**:
   - Use clear, simple language
   - Avoid special characters
   - Keep sentences reasonable length

3. **Best Practices**:
   - Start with MMS-TTS for quick tests
   - Use SpeechT5 for professional content
   - Try Bark for creative/emotional content

## 🤝 Contributing

This project is open source and welcomes contributions!

### Ways to Contribute
- **Bug Reports**: Report issues with detailed reproduction steps
- **Feature Requests**: Suggest new features or improvements  
- **Code Contributions**: Submit pull requests with improvements
- **Documentation**: Help improve usage guides and examples
- **Model Integration**: Add support for new TTS models

### Development Setup
```bash
# Clone the repository
git clone https://github.com/your-username/tts-spaces.git
cd tts-spaces

# Install dependencies
pip install -r requirements.txt

# Run locally
python app.py

# Run tests
python -m pytest tests/
```

## 📚 Model Credits

- **SpeechT5**: Microsoft Research - [Model Card](https://huggingface.co/microsoft/speecht5_tts)
- **MMS-TTS**: Meta AI - [Model Card](https://huggingface.co/facebook/mms-tts-eng)  
- **Bark**: Suno AI - [Model Card](https://huggingface.co/suno/bark)
- **Infrastructure**: [Hugging Face](https://huggingface.co/)

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Hugging Face Team**: For the amazing Transformers library and Spaces platform
- **Microsoft Research**: For SpeechT5 model
- **Meta AI**: For MMS-TTS multilingual model
- **Suno AI**: For Bark creative TTS model
- **Open Source Community**: For audio processing libraries and tools

## 📈 Roadmap

### Upcoming Features
- [ ] Batch text processing
- [ ] Voice cloning capabilities
- [ ] Additional language support
- [ ] Audio format conversion
- [ ] Custom voice training
- [ ] Real-time streaming synthesis

### Version History
- **v1.0**: Initial release with SpeechT5, MMS-TTS, and Bark models
- **v1.1**: Performance optimizations and memory management
- **v1.2**: Enhanced error handling and user experience

## 🔗 Links

- **Hugging Face Space**: [https://huggingface.co/spaces](your-space-url)
- **Documentation**: [Full API docs](link-to-docs)
- **Examples**: [Usage examples](link-to-examples)
- **Issues**: [GitHub Issues](link-to-issues)
- **Discussions**: [Community discussions](link-to-discussions)

---

**Built with ❤️ using Hugging Face Spaces and Gradio**

*Experience the future of text-to-speech technology in your browser!*