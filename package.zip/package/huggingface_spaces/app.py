#!/usr/bin/env python3
"""
Hugging Face Spaces Optimized Text-to-Speech Application

This is a streamlined version of the TTS tool specifically optimized for
Hugging Face Spaces deployment with:
- Memory management for large models
- Error handling and logging
- Performance optimization for cloud deployment
- Support for all three TTS models (SpeechT5, MMS-TTS, Bark)
"""

import os
import sys
import gc
import logging
import warnings
import traceback
from pathlib import Path
from typing import Optional, Dict, Any, List
import tempfile

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Suppress warnings for cleaner output
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# Set environment variables for Spaces optimization
os.environ["TRANSFORMERS_CACHE"] = "/tmp/transformers"
os.environ["HF_HOME"] = "/tmp/huggingface"
os.environ["TORCH_HOME"] = "/tmp/torch"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

try:
    import gradio as gr
    import torch
    import torchaudio
    import soundfile as sf
    import numpy as np
    from transformers import pipeline, AutoTokenizer, AutoModelForTextToSpeech
    from datasets import load_dataset
    import librosa
    from pydub import AudioSegment
    from pydub.utils import mediainfo
except ImportError as e:
    logger.error(f"Failed to import required dependencies: {e}")
    sys.exit(1)


class SpacesOptimizedTTS:
    """
    Memory-optimized TTS processor for Hugging Face Spaces.
    Handles model loading, caching, and cleanup for cloud deployment.
    """
    
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.cache_dir = "/tmp/models"
        self.current_model = None
        self.current_model_name = None
        self.processor = None
        self.model_info = {}
        
        # Create cache directory
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs("/tmp/outputs", exist_ok=True)
        
        logger.info(f"🚀 Initializing TTS system on device: {self.device}")
        logger.info(f"📁 Cache directory: {self.cache_dir}")
        
    def load_model(self, model_name: str) -> bool:
        """
        Load TTS model with memory optimization for Spaces.
        
        Args:
            model_name: Name of the model to load
            
        Returns:
            Success status
        """
        try:
            # Clear previous model from memory
            if self.processor is not None:
                logger.info(f"🗑️ Clearing previous model: {self.current_model_name}")
                del self.processor
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            
            # Model configurations
            model_configs = {
                "speecht5": {
                    "model_path": "microsoft/speecht5_tts",
                    "description": "Microsoft SpeechT5 - High quality English TTS",
                    "languages": ["English"],
                    "quality": "High",
                    "speed": "Medium",
                    "memory": "Medium"
                },
                "mms_tts": {
                    "model_path": "facebook/mms-tts-eng", 
                    "description": "Meta MMS-TTS - Fast multilingual TTS",
                    "languages": ["English", "Multi-language"],
                    "quality": "Medium",
                    "speed": "Fast", 
                    "memory": "Low"
                },
                "bark": {
                    "model_path": "suno/bark",
                    "description": "Suno Bark - Creative TTS with emotions",
                    "languages": ["English", "Multi-language"],
                    "quality": "Very High",
                    "speed": "Slow",
                    "memory": "High"
                }
            }
            
            if model_name not in model_configs:
                raise ValueError(f"Model {model_name} not supported")
            
            config = model_configs[model_name]
            logger.info(f"📥 Loading model: {config['model_path']}")
            
            # Load processor with optimized settings
            self.processor = pipeline(
                "text-to-speech",
                model=config["model_path"],
                device=0 if self.device == "cuda" else -1,
                cache_dir=self.cache_dir,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
            )
            
            self.current_model_name = model_name
            self.model_info = {
                "name": model_name,
                "description": config["description"],
                "languages": config["languages"],
                "quality": config["quality"],
                "speed": config["speed"],
                "memory": config["memory"],
                "device": self.device,
                "loaded": True
            }
            
            logger.info(f"✅ Model {model_name} loaded successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to load model {model_name}: {str(e)}")
            self.model_info = {"error": str(e), "loaded": False}
            return False
    
    def generate_speech(self, text: str, model_name: str, 
                       emotion: str = "neutral", language: str = "en") -> Dict[str, Any]:
        """
        Generate speech from text with error handling and optimization.
        
        Args:
            text: Input text to convert
            model_name: TTS model to use
            emotion: Voice emotion
            language: Target language
            
        Returns:
            Dictionary with audio file path and status
        """
        try:
            # Validate input
            if not text or not text.strip():
                return {
                    "success": False,
                    "error": "Input text cannot be empty",
                    "audio_path": None
                }
            
            # Limit text length for memory efficiency
            max_length = 1000
            if len(text) > max_length:
                text = text[:max_length]
                logger.warning(f"⚠️ Text truncated to {max_length} characters")
            
            # Load model if not already loaded or if model changed
            if self.current_model_name != model_name or not self.model_info.get("loaded"):
                logger.info(f"🔄 Switching to model: {model_name}")
                if not self.load_model(model_name):
                    return {
                        "success": False,
                        "error": f"Failed to load model: {model_name}",
                        "audio_path": None
                    }
            
            if not self.processor:
                return {
                    "success": False,
                    "error": "TTS processor not available",
                    "audio_path": None
                }
            
            logger.info(f"🎤 Generating speech: '{text[:50]}...' with {model_name}")
            
            # Generate speech based on model
            if model_name == "speecht5":
                # SpeechT5 with speaker embeddings
                audio_data = self.processor(text, return_tensors=True)
            elif model_name == "bark":
                # Bark with emotion tags
                emotion_text = f"[{emotion}] {text}" if emotion != "neutral" else text
                audio_data = self.processor(emotion_text, return_tensors=True)
            else:
                # Standard generation for MMS-TTS and others
                audio_data = self.processor(text, return_tensors=True)
            
            # Process audio data
            audio = self._process_audio_output(audio_data, text, model_name)
            
            # Save audio file
            output_path = self._save_audio_file(audio, text, model_name)
            
            logger.info(f"✅ Speech generated successfully: {output_path}")
            
            return {
                "success": True,
                "audio_path": output_path,
                "model_used": model_name,
                "emotion": emotion,
                "language": language,
                "duration": self._get_audio_duration(output_path)
            }
            
        except Exception as e:
            error_msg = f"Error generating speech: {str(e)}"
            logger.error(f"❌ {error_msg}")
            logger.error(traceback.format_exc())
            
            return {
                "success": False,
                "error": error_msg,
                "audio_path": None
            }
    
    def _process_audio_output(self, audio_data: Any, text: str, model_name: str) -> np.ndarray:
        """Process audio output from model into numpy array."""
        try:
            # Extract audio tensor
            if isinstance(audio_data, dict):
                if "audio" in audio_data:
                    audio = audio_data["audio"]
                elif "waveform" in audio_data:
                    audio = audio_data["waveform"]
                else:
                    audio = audio_data
            else:
                audio = audio_data
            
            # Remove batch dimension
            if hasattr(audio, 'dim') and audio.dim() > 2:
                audio = audio.squeeze(0)
            
            # Convert to numpy
            if torch.is_tensor(audio):
                audio_np = audio.cpu().numpy()
            else:
                audio_np = np.array(audio)
            
            # Ensure audio is in correct format
            if audio_np.dtype != np.float32:
                audio_np = audio_np.astype(np.float32)
            
            # Normalize audio
            audio_max = np.abs(audio_np).max()
            if audio_max > 0:
                audio_np = audio_np / audio_max
            
            return audio_np
            
        except Exception as e:
            logger.error(f"Error processing audio output: {e}")
            # Return silent audio as fallback
            return np.zeros(16000, dtype=np.float32)  # 1 second of silence
    
    def _save_audio_file(self, audio: np.ndarray, text: str, model_name: str) -> str:
        """Save audio to file with error handling."""
        try:
            # Generate filename
            text_preview = "".join(c for c in text[:20] if c.isalnum() or c in " _-").strip()
            if not text_preview:
                text_preview = "output"
            
            output_filename = f"{model_name}_{text_preview}.wav"
            output_path = f"/tmp/outputs/{output_filename}"
            
            # Save with soundfile
            sf.write(output_path, audio, 16000, subtype='PCM_16')
            
            return output_path
            
        except Exception as e:
            logger.error(f"Error saving audio file: {e}")
            # Return a temporary silent audio file
            temp_path = "/tmp/outputs/silent_fallback.wav"
            sf.write(temp_path, np.zeros(16000, dtype=np.float32), 16000)
            return temp_path
    
    def _get_audio_duration(self, audio_path: str) -> float:
        """Get duration of audio file."""
        try:
            info = sf.info(audio_path)
            return float(info.duration)
        except:
            return 0.0
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get system information for display."""
        info = {
            "device": self.device,
            "cuda_available": torch.cuda.is_available(),
            "cuda_version": torch.version.cuda if torch.cuda.is_available() else None,
            "memory_info": {},
            "current_model": self.current_model_name,
            "model_loaded": self.model_info.get("loaded", False)
        }
        
        # Get memory information
        try:
            if torch.cuda.is_available():
                info["memory_info"] = {
                    "allocated": f"{torch.cuda.memory_allocated() / 1024**3:.1f} GB",
                    "cached": f"{torch.cuda.memory_reserved() / 1024**3:.1f} GB"
                }
        except:
            pass
        
        return info
    
    def cleanup_memory(self):
        """Clean up memory and cached files."""
        try:
            logger.info("🧹 Cleaning up memory and cache...")
            
            # Clear model from memory
            if self.processor is not None:
                del self.processor
                self.processor = None
            
            # Garbage collection
            gc.collect()
            
            # Clear CUDA cache
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            # Clean temporary files
            temp_dir = Path("/tmp/outputs")
            if temp_dir.exists():
                for file in temp_dir.glob("*.wav"):
                    try:
                        file.unlink()
                    except:
                        pass
            
            logger.info("✅ Memory cleanup completed")
            return True
            
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
            return False


# Global TTS instance
tts_system = SpacesOptimizedTTS()

# Available models for dropdown
AVAILABLE_MODELS = [
    ("SpeechT5 (High Quality)", "speecht5"),
    ("MMS-TTS (Fast)", "mms_tts"), 
    ("Bark (Creative)", "bark")
]

# Available emotions
EMOTIONS = ["neutral", "happy", "sad", "excited", "whisper"]

# Available languages
LANGUAGES = ["en", "es", "fr", "de", "it", "pt", "ru", "zh", "ja", "ko"]


def create_gradio_interface():
    """Create the Gradio interface optimized for Spaces."""
    
    # Custom CSS for better appearance
    css = """
    .gradio-container {max-width: 1200px !important; margin: auto !important;}
    .gr-button {font-weight: bold !important; border-radius: 8px !important;}
    .gr-input, .gr-textbox {font-size: 16px !important;}
    .gr-audio {border: 2px solid #e0e0e0 !important; border-radius: 8px !important;}
    .tab-nav button {font-size: 14px !important; font-weight: 600 !important;}
    """
    
    with gr.Blocks(css=css, title="Text-to-Speech Converter", theme=gr.themes.Soft()) as interface:
        
        # Header
        gr.HTML("""
        <div style="text-align: center; padding: 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 15px; margin-bottom: 30px;">
            <h1 style="margin: 0; font-size: 2.8em; font-weight: 700;">🎤 Text-to-Speech Converter</h1>
            <p style="margin: 15px 0 0 0; font-size: 1.3em; opacity: 0.9;">Convert text to natural speech using AI models</p>
            <p style="margin: 10px 0 0 0; font-size: 1em; opacity: 0.8;">Powered by Hugging Face Transformers</p>
        </div>
        """)
        
        # Model selection
        with gr.Row():
            with gr.Column(scale=2):
                model_dropdown = gr.Dropdown(
                    choices=[label for label, _ in AVAILABLE_MODELS],
                    value="SpeechT5 (High Quality)",
                    label="🤖 Select TTS Model",
                    info="Choose the AI model for speech generation"
                )
            
            with gr.Column(scale=1):
                system_info = gr.HTML()
        
        # Main processing area
        with gr.Row():
            with gr.Column():
                text_input = gr.Textbox(
                    label="📝 Input Text",
                    placeholder="Enter your text here to convert to speech...",
                    lines=6,
                    max_lines=12,
                    info="Maximum 1000 characters for optimal performance"
                )
                
                with gr.Row():
                    emotion_dropdown = gr.Dropdown(
                        choices=EMOTIONS,
                        value="neutral",
                        label="😊 Emotion",
                        info="Add emotional expression to the voice"
                    )
                    
                    language_dropdown = gr.Dropdown(
                        choices=LANGUAGES,
                        value="en",
                        label="🌍 Language",
                        info="Target language for speech"
                    )
                
                generate_btn = gr.Button(
                    "🎤 Generate Speech", 
                    variant="primary", 
                    size="lg"
                )
            
            with gr.Column():
                audio_output = gr.Audio(
                    label="🎧 Generated Audio",
                    type="filepath",
                    info="Click play to listen to the generated speech"
                )
                
                status_output = gr.HTML()
                
                # Audio controls
                with gr.Row():
                    download_btn = gr.Button("📥 Download Audio", variant="secondary")
                    cleanup_btn = gr.Button("🗑️ Clean Memory", variant="stop")
        
        # Information panel
        with gr.Accordion("ℹ️ System Information", open=False):
            info_output = gr.HTML()
        
        # Generation function
        def generate_speech(text, model_label, emotion, language):
            """Handle speech generation with progress updates."""
            if not text or not text.strip():
                return None, "❌ Please enter some text to convert.", ""
            
            try:
                # Convert model label to internal name
                model_name = None
                for label, name in AVAILABLE_MODELS:
                    if label == model_label:
                        model_name = name
                        break
                
                if not model_name:
                    return None, "❌ Invalid model selection.", ""
                
                # Generate speech
                result = tts_system.generate_speech(text, model_name, emotion, language)
                
                if result["success"]:
                    audio_path = result["audio_path"]
                    status_html = f"""
                    <div style="padding: 15px; background: #d4edda; border-radius: 8px; border-left: 4px solid #28a745;">
                        <h4 style="margin: 0 0 10px 0; color: #155724;">✅ Speech Generated Successfully!</h4>
                        <p style="margin: 5px 0;"><strong>Model:</strong> {result['model_used']}</p>
                        <p style="margin: 5px 0;"><strong>Emotion:</strong> {result['emotion']}</p>
                        <p style="margin: 5px 0;"><strong>Duration:</strong> {result['duration']:.1f} seconds</p>
                        <p style="margin: 5px 0;"><strong>Language:</strong> {result['language']}</p>
                    </div>
                    """
                    
                    # Update system info
                    sys_info = tts_system.get_system_info()
                    info_html = f"""
                    <div style="padding: 15px; background: #f8f9fa; border-radius: 8px;">
                        <h4 style="margin: 0 0 10px 0;">💻 System Status</h4>
                        <p style="margin: 5px 0;"><strong>Device:</strong> {sys_info['device']}</p>
                        <p style="margin: 5px 0;"><strong>CUDA Available:</strong> {sys_info['cuda_available']}</p>
                        <p style="margin: 5px 0;"><strong>Current Model:</strong> {sys_info['current_model'] or 'None'}</p>
                        <p style="margin: 5px 0;"><strong>Model Loaded:</strong> {sys_info['model_loaded']}</p>
                    </div>
                    """
                    
                    return audio_path, status_html, info_html
                else:
                    error_html = f"""
                    <div style="padding: 15px; background: #f8d7da; border-radius: 8px; border-left: 4px solid #dc3545;">
                        <h4 style="margin: 0 0 10px 0; color: #721c24;">❌ Generation Failed</h4>
                        <p style="margin: 5px 0;"><strong>Error:</strong> {result['error']}</p>
                        <p style="margin: 5px 0; font-style: italic;">Try with shorter text or a different model.</p>
                    </div>
                    """
                    return None, error_html, ""
                    
            except Exception as e:
                error_html = f"""
                <div style="padding: 15px; background: #f8d7da; border-radius: 8px; border-left: 4px solid #dc3545;">
                    <h4 style="margin: 0 0 10px 0; color: #721c24;">❌ Unexpected Error</h4>
                    <p style="margin: 5px 0;"><strong>Error:</strong> {str(e)}</p>
                </div>
                """
                return None, error_html, ""
        
        def update_system_info():
            """Update system information display."""
            sys_info = tts_system.get_system_info()
            
            memory_str = ""
            if sys_info.get("memory_info"):
                memory_info = sys_info["memory_info"]
                memory_str = f"<p style='margin: 5px 0;'><strong>GPU Memory:</strong> {memory_info.get('allocated', 'N/A')} allocated</p>"
            
            return f"""
            <div style="padding: 20px; background: #e3f2fd; border-radius: 10px; border-left: 4px solid #2196f3;">
                <h4 style="margin: 0 0 15px 0; color: #1565c0;">📊 Current Status</h4>
                <p style="margin: 5px 0;"><strong>Device:</strong> {sys_info['device']}</p>
                <p style="margin: 5px 0;"><strong>CUDA Available:</strong> {sys_info['cuda_available']}</p>
                <p style="margin: 5px 0;"><strong>Current Model:</strong> {sys_info['current_model'] or 'None'}</p>
                {memory_str}
                <p style="margin: 5px 0; font-size: 0.9em; color: #666;">💡 GPU models load faster but use more memory</p>
            </div>
            """
        
        def cleanup_memory():
            """Clean up memory and update info."""
            success = tts_system.cleanup_memory()
            if success:
                return "✅ Memory cleaned successfully!", update_system_info()
            else:
                return "❌ Cleanup failed", update_system_info()
        
        def download_audio(audio_path):
            """Handle audio download."""
            if audio_path and os.path.exists(audio_path):
                return audio_path
            return None
        
        # Event handlers
        generate_btn.click(
            fn=generate_speech,
            inputs=[text_input, model_dropdown, emotion_dropdown, language_dropdown],
            outputs=[audio_output, status_output, system_info]
        )
        
        download_btn.click(
            fn=download_audio,
            inputs=[audio_output],
            outputs=[]
        )
        
        cleanup_btn.click(
            fn=cleanup_memory,
            outputs=[status_output, system_info]
        )
        
        # Initialize system info
        interface.load(
            fn=update_system_info,
            outputs=[system_info]
        )
    
    return interface


def main():
    """Main application entry point for Hugging Face Spaces."""
    try:
        logger.info("🚀 Starting Text-to-Speech Spaces Application")
        
        # Create and launch interface
        interface = create_gradio_interface()
        
        # Launch with Spaces-optimized settings
        interface.launch(
            server_name="0.0.0.0",
            server_port=7860,
            share=False,
            inbrowser=False,
            quiet=False,
            show_error=True,
            height=800,
            title="Text-to-Speech Converter"
        )
        
    except KeyboardInterrupt:
        logger.info("👋 Application stopped by user")
    except Exception as e:
        logger.error(f"❌ Application error: {str(e)}")
        logger.error(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()