#!/bin/bash

# Hugging Face Spaces Deployment Script
# This script helps deploy the TTS application to Hugging Face Spaces

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to show help
show_help() {
    cat << EOF
🚀 Hugging Face Spaces TTS Deployment Script

Usage: $0 [OPTIONS] [SPACE_NAME]

OPTIONS:
  -h, --help          Show this help message
  -d, --deploy        Deploy to Hugging Face Spaces
  -l, --local         Test locally before deploying
  --sdk TYPE          SDK type (gradio or docker, default: gradio)
  --private           Make space private (default: public)
  --hardware TYPE     Hardware type (cpu, cpu-plus, t4-small, etc.)

EXAMPLES:
  $0 --deploy my-tts-space           # Deploy with default settings
  $0 --deploy --private my-tts-space # Deploy as private space
  $0 --local                         # Test locally first

REQUIREMENTS:
  - Hugging Face account (https://huggingface.co/join)
  - Hugging Face CLI installed: pip install -U huggingface_hub
  - Git installed
  - Space name should be unique on Hugging Face

FILES NEEDED:
  - app.py (main application)
  - requirements.txt (Python dependencies)
  - spaces.yml (Space configuration)
  - README.md (documentation)

EOF
}

# Function to check prerequisites
check_prerequisites() {
    print_info "Checking prerequisites..."
    
    # Check if Hugging Face CLI is installed
    if ! command_exists huggingface-cli; then
        print_error "Hugging Face CLI not found!"
        print_info "Install it with: pip install -U huggingface_hub"
        exit 1
    fi
    
    # Check if git is installed
    if ! command_exists git; then
        print_error "Git is not installed!"
        exit 1
    fi
    
    # Check if logged in to Hugging Face
    if ! huggingface-cli whoami >/dev/null 2>&1; then
        print_error "Not logged in to Hugging Face!"
        print_info "Run: huggingface-cli login"
        exit 1
    fi
    
    print_success "All prerequisites met!"
}

# Function to check required files
check_files() {
    print_info "Checking required files..."
    
    local required_files=("app.py" "requirements.txt" "spaces.yml" "README.md")
    local missing_files=()
    
    for file in "${required_files[@]}"; do
        if [[ ! -f "$file" ]]; then
            missing_files+=("$file")
        fi
    done
    
    if [[ ${#missing_files[@]} -gt 0 ]]; then
        print_error "Missing required files:"
        for file in "${missing_files[@]}"; do
            echo "  - $file"
        done
        exit 1
    fi
    
    print_success "All required files present!"
}

# Function to test locally
test_locally() {
    print_info "Testing application locally..."
    
    # Install dependencies
    print_info "Installing dependencies..."
    pip install -r requirements.txt
    
    # Test import
    print_info "Testing imports..."
    python -c "import app; print('✅ Import test passed')" || {
        print_error "Import test failed!"
        exit 1
    }
    
    # Start local server (in background)
    print_info "Starting local server..."
    python app.py &
    local pid=$!
    
    # Wait a bit for startup
    sleep 5
    
    # Check if server is running
    if curl -f http://localhost:7860/ >/dev/null 2>&1; then
        print_success "Local test server is running!"
        print_info "Open http://localhost:7860 in your browser"
        print_info "Press Ctrl+C to stop the test server"
        wait $pid
    else
        print_error "Local server failed to start!"
        kill $pid 2>/dev/null || true
        exit 1
    fi
}

# Function to create Space repository
create_space() {
    local space_name="$1"
    local sdk_type="$2"
    local hardware="$3"
    local private="$4"
    
    print_info "Creating Space repository: $space_name"
    
    local hf_args=()
    if [[ "$private" == "true" ]]; then
        hf_args+=("--private")
    fi
    
    # Create the space
    huggingface-cli space create \
        --name "$space_name" \
        --sdk "$sdk_type" \
        --hardware "$hardware" \
        "${hf_args[@]}"
    
    print_success "Space created successfully!"
}

# Function to deploy to Spaces
deploy_space() {
    local space_name="$1"
    local sdk_type="$2"
    local hardware="$3"
    local private="$4"
    
    print_info "Deploying to Hugging Face Spaces..."
    print_info "Space name: $space_name"
    print_info "SDK type: $sdk_type"
    print_info "Hardware: $hardware"
    print_info "Private: $private"
    
    # Create space if it doesn't exist
    if ! huggingface-cli api spaces/$space_name >/dev/null 2>&1; then
        print_info "Space doesn't exist, creating..."
        create_space "$space_name" "$sdk_type" "$hardware" "$private"
    fi
    
    # Initialize git repository if not already done
    if [[ ! -d ".git" ]]; then
        print_info "Initializing git repository..."
        git init
        git add .
        git commit -m "Initial commit: TTS application"
    fi
    
    # Set remote if not already set
    if ! git remote get-url origin >/dev/null 2>&1; then
        local hf_username=$(huggingface-cli whoami | grep -o '^[^\s]*')
        git remote add origin "https://huggingface.co/spaces/$hf_username/$space_name"
    fi
    
    # Push to Hugging Face
    print_info "Pushing to Hugging Face..."
    git push -u origin main
    
    print_success "Deployment complete!"
    print_info "Your Space is available at:"
    print_info "https://huggingface.co/spaces/$(huggingface-cli whoami | grep -o '^[^\s]*')/$space_name"
}

# Function to show deployment status
show_status() {
    local space_name="$1"
    print_info "Checking deployment status for: $space_name"
    
    # This would require additional API calls to check space status
    print_info "Visit https://huggingface.co/spaces/$(huggingface-cli whoami | grep -o '^[^\s]*')/$space_name"
    print_info "The Space will be built automatically. This may take a few minutes."
}

# Main script logic
main() {
    local deploy_mode=false
    local local_mode=false
    local space_name=""
    local sdk_type="gradio"
    local hardware="cpu-plus"
    local private="false"
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--deploy)
                deploy_mode=true
                shift
                ;;
            -l|--local)
                local_mode=true
                shift
                ;;
            --sdk)
                sdk_type="$2"
                shift 2
                ;;
            --hardware)
                hardware="$2"
                shift 2
                ;;
            --private)
                private="true"
                shift
                ;;
            -*)
                print_error "Unknown option: $1"
                show_help
                exit 1
                ;;
            *)
                space_name="$1"
                shift
                ;;
        esac
    done
    
    # Validate arguments
    if [[ "$deploy_mode" == "true" && -z "$space_name" ]]; then
        print_error "Space name is required for deployment!"
        echo
        show_help
        exit 1
    fi
    
    # Show banner
    echo
    echo "🚀 Hugging Face Spaces TTS Deployment"
    echo "====================================="
    echo
    
    # Run checks
    check_prerequisites
    check_files
    
    # Handle deployment modes
    if [[ "$local_mode" == "true" ]]; then
        test_locally
    fi
    
    if [[ "$deploy_mode" == "true" ]]; then
        deploy_space "$space_name" "$sdk_type" "$hardware" "$private"
        show_status "$space_name"
    fi
    
    if [[ "$local_mode" == "false" && "$deploy_mode" == "false" ]]; then
        print_info "No action specified. Use --help for usage information."
        echo
        echo "Quick start:"
        echo "  $0 --local                    # Test locally first"
        echo "  $0 --deploy my-tts-space     # Deploy to Spaces"
        echo
    fi
}

# Run main function
main "$@"