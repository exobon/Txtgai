"""
Performance tests for TTS models to ensure performance benchmarks are maintained.
Run with: pytest tests/test_performance.py --benchmark-only
"""

import pytest
import time
import psutil
import torch
import os
from pathlib import Path
import tempfile
import shutil

# Import TTS modules
from code.tts_processor import TTSProcessor
from code.advanced_tts import BatchTTSProcessor, AdvancedTTSProcessor


class TestTTSPerformance:
    """Performance tests for TTS models."""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for test outputs."""
        temp_dir = tempfile.mkdtemp()
        yield temp_dir
        shutil.rmtree(temp_dir, ignore_errors=True)
    
    @pytest.fixture
    def short_text(self):
        """Short text for performance testing."""
        return "This is a short test sentence for performance benchmarking."
    
    @pytest.fixture
    def medium_text(self):
        """Medium-length text for performance testing."""
        return "This is a medium-length text that contains more words and sentences. " \
               "It should provide a realistic test of text-to-speech processing time " \
               "while not taking too long to process in the test environment."
    
    @pytest.fixture
    def long_text(self):
        """Long text for performance testing."""
        return "This is a longer text that contains multiple sentences. " \
               "Text-to-speech systems need to handle varying lengths of input text. " \
               "This test will help ensure that processing time scales appropriately " \
               "with text length. The system should be able to process longer texts " \
               "without significant performance degradation or memory issues. " \
               "Performance benchmarks are important for production deployment."


class TestModelLoadingPerformance:
    """Test model loading performance across different TTS models."""
    
    @pytest.mark.benchmark(group="model_loading")
    @pytest.mark.parametrize("model_name", ["speecht5", "mms_tts", "bark"])
    def test_model_loading_time(self, model_name, benchmark):
        """Test that models load within acceptable time limits."""
        def load_model():
            processor = TTSProcessor(model_name)
            return processor
        
        result = benchmark.pedantic(load_model, rounds=3, warmup_rounds=1)
        
        # Assert that model loaded successfully (actual timing assertions
        # would depend on specific performance requirements)
        assert result is not None
        assert result.model_name == model_name
    
    @pytest.mark.benchmark(group="model_loading")
    def test_model_loading_memory_usage(self):
        """Test memory usage during model loading."""
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Load each model and check memory usage
        for model_name in ["speecht5", "mms_tts", "bark"]:
            try:
                processor = TTSProcessor(model_name)
                peak_memory = process.memory_info().rss / 1024 / 1024  # MB
                
                memory_increase = peak_memory - initial_memory
                
                # Log memory usage (actual limits would depend on requirements)
                print(f"{model_name} memory usage: {memory_increase:.2f} MB increase")
                
                # Clean up
                del processor
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    
            except Exception as e:
                print(f"Model {model_name} loading failed (expected in some environments): {e}")


class TestTTSProcessingPerformance:
    """Test TTS processing performance for different models and text lengths."""
    
    @pytest.mark.benchmark(group="tts_processing")
    @pytest.mark.parametrize("model_name", ["speecht5", "mms_tts"])
    @pytest.mark.parametrize("text_type", ["short_text", "medium_text"])
    def test_tts_processing_time(self, model_name, text_type, short_text, medium_text, benchmark):
        """Test TTS processing time for different models and text lengths."""
        processor = TTSProcessor(model_name)
        
        # Get appropriate text
        text = short_text if text_type == "short_text" else medium_text
        
        def process_text():
            with tempfile.TemporaryDirectory() as temp_dir:
                output_file = os.path.join(temp_dir, f"test_{text_type}.wav")
                result = processor.generate_speech(text, output_file)
                return result
        
        try:
            result = benchmark.pedantic(process_text, rounds=2, warmup_rounds=1)
            assert result is not None
        except Exception as e:
            print(f"TTS processing failed for {model_name} (may be expected): {e}")
            # Don't fail the test for model loading issues in CI environment
            pytest.skip(f"Model {model_name} not available in this environment")
    
    @pytest.mark.benchmark(group="tts_processing")
    def test_audio_generation_scalability(self, medium_text):
        """Test that processing time scales reasonably with text length."""
        processor = TTSProcessor("speecht5")
        
        # Test different text lengths
        texts = [
            medium_text[:50],      # Short
            medium_text[:150],     # Medium
            medium_text,           # Long
        ]
        
        processing_times = []
        
        for text in texts:
            start_time = time.time()
            try:
                with tempfile.TemporaryDirectory() as temp_dir:
                    output_file = os.path.join(temp_dir, "test.wav")
                    processor.generate_speech(text, output_file)
                
                end_time = time.time()
                processing_time = end_time - start_time
                processing_times.append(processing_time)
                print(f"Text length {len(text)}: {processing_time:.2f}s")
                
            except Exception as e:
                print(f"Processing failed for text length {len(text)}: {e}")
                processing_times.append(None)
        
        # Verify processing times are reasonable (not strictly increasing test)
        # This is more of a performance monitoring test
        for i, time_taken in enumerate(processing_times):
            if time_taken is not None:
                # Log performance metrics
                print(f"Text length {len(texts[i])} processing: {time_taken:.2f}s")


class TestBatchProcessingPerformance:
    """Test batch processing performance and scalability."""
    
    @pytest.mark.benchmark(group="batch_processing")
    def test_batch_processing_performance(self, benchmark):
        """Test batch processing performance."""
        texts = [
            "First test sentence.",
            "Second test sentence.",
            "Third test sentence.",
        ]
        
        def process_batch():
            batch_processor = BatchTTSProcessor("speecht5", max_workers=2)
            with tempfile.TemporaryDirectory() as temp_dir:
                results = batch_processor.process_batch(texts, temp_dir)
            return results
        
        try:
            results = benchmark.pedantic(process_batch, rounds=2, warmup_rounds=1)
            assert len(results) == len(texts)
            
            # Check that batch processing completed successfully
            successful_results = [r for r in results if r['success']]
            assert len(successful_results) > 0
        except Exception as e:
            print(f"Batch processing test failed (may be expected): {e}")
            pytest.skip("Batch processing not available in this environment")
    
    @pytest.mark.benchmark(group="batch_processing")
    def test_batch_scalability(self):
        """Test batch processing with different batch sizes."""
        batch_sizes = [1, 3, 5]
        texts = [
            "Test sentence one.",
            "Test sentence two.",
            "Test sentence three.",
            "Test sentence four.",
            "Test sentence five.",
        ]
        
        for batch_size in batch_sizes:
            if batch_size > len(texts):
                continue
                
            batch_processor = BatchTTSProcessor("speecht5", max_workers=batch_size)
            test_texts = texts[:batch_size]
            
            start_time = time.time()
            try:
                with tempfile.TemporaryDirectory() as temp_dir:
                    results = batch_processor.process_batch(test_texts, temp_dir)
                
                end_time = time.time()
                total_time = end_time - start_time
                
                successful_results = [r for r in results if r['success']]
                print(f"Batch size {batch_size}: {len(successful_results)}/{batch_size} successful, {total_time:.2f}s total")
                
            except Exception as e:
                print(f"Batch size {batch_size} test failed: {e}")


class TestMemoryUsage:
    """Test memory usage and memory leaks."""
    
    def test_memory_usage_stability(self):
        """Test that memory usage remains stable during processing."""
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Process multiple texts
        processor = TTSProcessor("speecht5")
        texts = [
            "Memory test sentence one.",
            "Memory test sentence two.",
            "Memory test sentence three.",
        ]
        
        peak_memory = initial_memory
        
        for i, text in enumerate(texts):
            try:
                with tempfile.TemporaryDirectory() as temp_dir:
                    output_file = os.path.join(temp_dir, f"memory_test_{i}.wav")
                    processor.generate_speech(text, output_file)
                
                current_memory = process.memory_info().rss / 1024 / 1024  # MB
                peak_memory = max(peak_memory, current_memory)
                
                print(f"After text {i+1}: {current_memory:.2f} MB")
                
            except Exception as e:
                print(f"Memory test failed for text {i+1}: {e}")
                break
        
        memory_increase = peak_memory - initial_memory
        print(f"Total memory increase: {memory_increase:.2f} MB")
        
        # Check memory usage is reasonable (actual limits would depend on requirements)
        # For now, just log the results
        assert memory_increase < 500  # Should not increase by more than 500MB
        
        # Clean up
        del processor
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def test_cuda_memory_management(self):
        """Test CUDA memory management if available."""
        if not torch.cuda.is_available():
            pytest.skip("CUDA not available")
        
        initial_memory = torch.cuda.memory_allocated()
        
        # Load model and process text
        processor = TTSProcessor("speecht5")
        
        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                output_file = os.path.join(temp_dir, "cuda_test.wav")
                processor.generate_speech("CUDA memory test.", output_file)
            
            # Check for memory leaks
            peak_memory = torch.cuda.max_memory_allocated()
            current_memory = torch.cuda.memory_allocated()
            
            print(f"CUDA initial: {initial_memory / 1024 / 1024:.2f} MB")
            print(f"CUDA peak: {peak_memory / 1024 / 1024:.2f} MB")
            print(f"CUDA current: {current_memory / 1024 / 1024:.2f} MB")
            
            # Clean up
            del processor
            torch.cuda.empty_cache()
            
            final_memory = torch.cuda.memory_allocated()
            print(f"CUDA final: {final_memory / 1024 / 1024:.2f} MB")
            
        except Exception as e:
            print(f"CUDA test failed: {e}")
            del processor
            torch.cuda.empty_cache()


class TestAdvancedFeaturesPerformance:
    """Test performance of advanced TTS features."""
    
    @pytest.mark.benchmark(group="advanced_features")
    def test_advanced_tts_initialization(self, benchmark):
        """Test AdvancedTTSProcessor initialization performance."""
        def init_advanced():
            return AdvancedTTSProcessor("speecht5")
        
        result = benchmark.pedantic(init_advanced, rounds=3, warmup_rounds=1)
        assert result is not None
    
    @pytest.mark.benchmark(group="advanced_features")
    def test_emotion_generation_performance(self, short_text):
        """Test emotion-based TTS generation performance."""
        try:
            processor = AdvancedTTSProcessor("speecht5")
            
            emotions = ["neutral", "happy"]  # Test a few emotions
            
            for emotion in emotions:
                start_time = time.time()
                try:
                    with tempfile.TemporaryDirectory() as temp_dir:
                        output_file = os.path.join(temp_dir, f"emotion_{emotion}.wav")
                        processor.generate_with_emotion(short_text, emotion, output_file)
                    
                    end_time = time.time()
                    processing_time = end_time - start_time
                    print(f"Emotion {emotion}: {processing_time:.2f}s")
                    
                except Exception as e:
                    print(f"Emotion {emotion} generation failed: {e}")
            
            del processor
            
        except Exception as e:
            print(f"Advanced TTS test failed: {e}")
            pytest.skip("Advanced TTS not available in this environment")


class TestGradioInterfacePerformance:
    """Test Gradio interface performance."""
    
    @pytest.mark.benchmark(group="interface")
    def test_interface_creation_performance(self, benchmark):
        """Test Gradio interface creation time."""
        def create_interface():
            from code.gradio_interface import create_interface
            return create_interface()
        
        result = benchmark.pedantic(create_interface, rounds=2, warmup_rounds=1)
        assert result is not None
        assert result.title is not None


# Performance regression detection
class TestPerformanceRegression:
    """Tests to detect performance regressions."""
    
    @pytest.mark.performance_regression
    def test_processing_time_regression(self, short_text):
        """Test that processing time hasn't regressed significantly."""
        # This would compare current performance against baselines
        # For now, just establish a baseline
        
        processor = TTSProcessor("speecht5")
        
        processing_times = []
        for _ in range(3):
            start_time = time.time()
            try:
                with tempfile.TemporaryDirectory() as temp_dir:
                    output_file = os.path.join(temp_dir, "regression_test.wav")
                    processor.generate_speech(short_text, output_file)
                
                end_time = time.time()
                processing_times.append(end_time - start_time)
                
            except Exception as e:
                print(f"Regression test failed: {e}")
                break
        
        if processing_times:
            avg_time = sum(processing_times) / len(processing_times)
            print(f"Average processing time: {avg_time:.2f}s")
            
            # This would be where you check against baseline
            # For example, if avg_time > baseline * 1.5: fail the test
            assert avg_time < 30  # Should complete within 30 seconds
    
    @pytest.mark.performance_regression
    def test_memory_usage_regression(self):
        """Test that memory usage hasn't regressed significantly."""
        process = psutil.Process()
        
        # Test memory usage across multiple model loads
        memory_usage = []
        
        for model_name in ["speecht5", "mms_tts"]:
            try:
                processor = TTSProcessor(model_name)
                memory = process.memory_info().rss / 1024 / 1024  # MB
                memory_usage.append(memory)
                print(f"{model_name} memory usage: {memory:.2f} MB")
                
                del processor
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    
            except Exception as e:
                print(f"Memory regression test failed for {model_name}: {e}")
        
        # This would compare against baseline memory usage
        if memory_usage:
            avg_memory = sum(memory_usage) / len(memory_usage)
            print(f"Average memory usage: {avg_memory:.2f} MB")
            
            # Check against reasonable limits
            assert avg_memory < 2000  # Should not exceed 2GB on average


if __name__ == "__main__":
    # Run performance tests manually
    pytest.main([__file__, "--benchmark-only", "-v"])
