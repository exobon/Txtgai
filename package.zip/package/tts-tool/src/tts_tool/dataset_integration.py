"""
Dataset integration for loading and processing Hugging Face audio datasets.
"""

import os
import json
import warnings
from typing import Dict, List, Optional, Tuple, Union
from pathlib import Path
import numpy as np
import librosa
import soundfile as sf
from datasets import load_dataset, Dataset, Audio, load_from_disk
import pandas as pd
import matplotlib.pyplot as plt

try:
    from configs.settings import DatasetConfig
except ImportError:
    # Fallback for direct execution
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from configs.settings import DatasetConfig


class DatasetLoader:
    """
    Load and manage Hugging Face audio datasets for TTS training and evaluation.
    """
    
    def __init__(self, cache_dir: str = "dataset_cache"):
        """
        Initialize dataset loader.
        
        Args:
            cache_dir: Directory for caching downloaded datasets
        """
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
        # Dataset configurations
        self.dataset_configs = DatasetConfig()
        
        # Loaded datasets cache
        self.loaded_datasets = {}
    
    def load_dataset(self, 
                    dataset_name: str, 
                    split: str = "train",
                    subset: Optional[str] = None,
                    **kwargs) -> Dataset:
        """
        Load a specific dataset.
        
        Args:
            dataset_name: Name of the dataset
            split: Dataset split to load (train, test, validation)
            subset: Optional subset specification
            **kwargs: Additional arguments for load_dataset
            
        Returns:
            Loaded dataset
        """
        cache_key = f"{dataset_name}_{split}_{subset}"
        
        if cache_key in self.loaded_datasets:
            print(f"Loading {dataset_name} from cache")
            return self.loaded_datasets[cache_key]
        
        try:
            print(f"Loading dataset: {dataset_name}")
            
            # Load the dataset
            if subset:
                dataset = load_dataset(dataset_name, subset, split=split, **kwargs)
            else:
                dataset = load_dataset(dataset_name, split=split, **kwargs)
            
            # Cache the dataset
            cache_path = os.path.join(self.cache_dir, cache_key)
            dataset.save_to_disk(cache_path)
            
            self.loaded_datasets[cache_key] = dataset
            print(f"Dataset {dataset_name} loaded successfully")
            
            return dataset
            
        except Exception as e:
            print(f"Error loading dataset {dataset_name}: {str(e)}")
            raise
    
    def get_lj_speech_dataset(self, split: str = "train") -> Dataset:
        """
        Load LJ Speech dataset (single-speaker English).
        
        Args:
            split: Dataset split
            
        Returns:
            LJ Speech dataset
        """
        dataset = self.load_dataset(
            "lj_speech",
            split=split,
            cache_dir=self.cache_dir
        )
        
        # Add audio decoding for LJ Speech
        dataset = dataset.cast_column("audio", Audio())
        
        print(f"LJ Speech dataset loaded: {len(dataset)} samples")
        return dataset
    
    def get_common_voice_dataset(self, 
                               language: str = "en", 
                               split: str = "train") -> Dataset:
        """
        Load Common Voice dataset (multilingual).
        
        Args:
            language: Language code
            split: Dataset split
            
        Returns:
            Common Voice dataset
        """
        # Use the specific version
        dataset = self.load_dataset(
            "mozilla-foundation/common_voice_16_1",
            split=split,
            language=language,
            cache_dir=self.cache_dir
        )
        
        # Add audio decoding
        dataset = dataset.cast_column("audio", Audio())
        
        print(f"Common Voice ({language}) dataset loaded: {len(dataset)} samples")
        return dataset
    
    def get_vctk_dataset(self, split: str = "train") -> Dataset:
        """
        Load VCTK dataset (multi-speaker English).
        
        Args:
            split: Dataset split
            
        Returns:
            VCTK dataset
        """
        dataset = self.load_dataset(
            "vctk",
            split=split,
            cache_dir=self.cache_dir
        )
        
        # Add audio decoding
        dataset = dataset.cast_column("audio", Audio())
        
        print(f"VCTK dataset loaded: {len(dataset)} samples")
        return dataset
    
    def list_available_datasets(self) -> List[str]:
        """List all available datasets."""
        return [
            "lj_speech",
            "common_voice", 
            "vctk"
        ]


class DatasetAnalyzer:
    """
    Analyze dataset characteristics and create reports.
    """
    
    @staticmethod
    def analyze_dataset_statistics(dataset: Dataset) -> Dict:
        """
        Analyze dataset statistics.
        
        Args:
            dataset: Input dataset
            
        Returns:
            Dictionary with dataset statistics
        """
        stats = {
            'total_samples': len(dataset),
            'features': list(dataset.features.keys())
        }
        
        # Audio-specific analysis
        if 'audio' in dataset.features:
            stats.update(DatasetAnalyzer._analyze_audio_dataset(dataset))
        
        # Text-specific analysis
        if 'transcript' in dataset.features:
            text_data = dataset['transcript']
            stats.update(DatasetAnalyzer._analyze_text_dataset(text_data))
        
        return stats
    
    @staticmethod
    def _analyze_audio_dataset(dataset: Dataset) -> Dict:
        """Analyze audio characteristics."""
        audio_data = []
        durations = []
        
        # Sample first 1000 entries for analysis (performance)
        sample_size = min(1000, len(dataset))
        sample_indices = np.random.choice(len(dataset), sample_size, replace=False)
        
        for i in sample_indices:
            try:
                audio_info = dataset[i]['audio']
                if audio_info and 'array' in audio_info:
                    audio_array = audio_info['array']
                    sr = audio_info.get('sampling_rate', 16000)
                    
                    # Convert to seconds
                    duration = len(audio_array) / sr
                    durations.append(duration)
                    audio_data.append({
                        'duration': duration,
                        'sample_rate': sr,
                        'array_shape': audio_array.shape
                    })
            except Exception:
                continue
        
        if durations:
            durations = np.array(durations)
            return {
                'audio_analysis': {
                    'sample_count': len(audio_data),
                    'duration_stats': {
                        'mean': float(np.mean(durations)),
                        'std': float(np.std(durations)),
                        'min': float(np.min(durations)),
                        'max': float(np.max(durations)),
                        'median': float(np.median(durations))
                    },
                    'sample_rates': list(set(a['sample_rate'] for a in audio_data)),
                    'avg_silence_ratio': DatasetAnalyzer._estimate_silence_ratio(audio_data)
                }
            }
        else:
            return {
                'audio_analysis': {
                    'sample_count': 0,
                    'error': 'No valid audio data found'
                }
            }
    
    @staticmethod
    def _analyze_text_dataset(text_data: List[str]) -> Dict:
        """Analyze text characteristics."""
        if not text_data:
            return {'text_analysis': {'error': 'No text data found'}}
        
        text_lengths = [len(text) for text in text_data if text]
        word_counts = [len(text.split()) for text in text_data if text]
        
        if text_lengths:
            return {
                'text_analysis': {
                    'sample_count': len(text_data),
                    'character_stats': {
                        'mean': float(np.mean(text_lengths)),
                        'std': float(np.std(text_lengths)),
                        'min': int(np.min(text_lengths)),
                        'max': int(np.max(text_lengths))
                    },
                    'word_stats': {
                        'mean': float(np.mean(word_counts)),
                        'std': float(np.std(word_counts)),
                        'min': int(np.min(word_counts)),
                        'max': int(np.max(word_counts))
                    }
                }
            }
        else:
            return {'text_analysis': {'error': 'No valid text data found'}}
    
    @staticmethod
    def _estimate_silence_ratio(audio_data: List[Dict]) -> float:
        """Estimate silence ratio in audio files."""
        silence_ratios = []
        
        for audio_info in audio_data:
            try:
                # Simple silence detection using RMS threshold
                audio_array = audio_info.get('audio', {}).get('array')
                if audio_array is not None:
                    # Calculate RMS energy
                    rms = np.sqrt(np.mean(audio_array**2))
                    # Estimate silence ratio based on low RMS values
                    silence_threshold = 0.01  # Adjust as needed
                    silence_ratio = np.mean(np.abs(audio_array) < silence_threshold)
                    silence_ratios.append(silence_ratio)
            except:
                continue
        
        return float(np.mean(silence_ratios)) if silence_ratios else 0.0
    
    @staticmethod
    def create_dataset_report(dataset: Dataset, output_file: str = "dataset_report.json"):
        """
        Create a comprehensive dataset report.
        
        Args:
            dataset: Input dataset
            output_file: Output file for the report
        """
        stats = DatasetAnalyzer.analyze_dataset_statistics(dataset)
        
        # Add timestamp
        from datetime import datetime
        stats['report_generated'] = datetime.now().isoformat()
        stats['dataset_info'] = {
            'dataset_type': str(type(dataset)),
            'split_infos': getattr(dataset, 'split', 'unknown')
        }
        
        # Save report
        with open(output_file, 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"Dataset report saved to: {output_file}")
        return stats
    
    @staticmethod
    def visualize_dataset_stats(stats: Dict, output_dir: str = "visualizations"):
        """
        Create visualizations for dataset statistics.
        
        Args:
            stats: Dataset statistics
            output_dir: Output directory for plots
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Audio duration histogram
        if 'audio_analysis' in stats and 'duration_stats' in stats['audio_analysis']:
            audio_stats = stats['audio_analysis']
            
            # Create histogram of audio durations (simulated data based on stats)
            durations = np.random.normal(
                audio_stats['duration_stats']['mean'],
                audio_stats['duration_stats']['std'],
                1000
            )
            durations = np.maximum(durations, 0)  # Ensure non-negative
            
            plt.figure(figsize=(10, 6))
            plt.hist(durations, bins=50, alpha=0.7, edgecolor='black')
            plt.xlabel('Audio Duration (seconds)')
            plt.ylabel('Frequency')
            plt.title('Audio Duration Distribution')
            plt.grid(True, alpha=0.3)
            plt.savefig(os.path.join(output_dir, 'audio_duration_distribution.png'), dpi=300, bbox_inches='tight')
            plt.close()
        
        # Text length distribution
        if 'text_analysis' in stats and 'character_stats' in stats['text_analysis']:
            text_stats = stats['text_analysis']
            
            # Create histogram of text lengths
            text_lengths = np.random.normal(
                text_stats['character_stats']['mean'],
                text_stats['character_stats']['std'],
                1000
            )
            text_lengths = np.maximum(text_lengths, 1)  # Ensure positive
            
            plt.figure(figsize=(10, 6))
            plt.hist(text_lengths, bins=50, alpha=0.7, edgecolor='black')
            plt.xlabel('Text Length (characters)')
            plt.ylabel('Frequency')
            plt.title('Text Length Distribution')
            plt.grid(True, alpha=0.3)
            plt.savefig(os.path.join(output_dir, 'text_length_distribution.png'), dpi=300, bbox_inches='tight')
            plt.close()
        
        print(f"Visualizations saved to: {output_dir}")


class DatasetSampler:
    """
    Sample datasets for training and evaluation purposes.
    """
    
    def __init__(self, dataset: Dataset):
        """
        Initialize dataset sampler.
        
        Args:
            dataset: Input dataset
        """
        self.dataset = dataset
        self.sample_cache = {}
    
    def get_random_sample(self, num_samples: int = 10, seed: int = 42) -> List[Dict]:
        """
        Get random samples from dataset.
        
        Args:
            num_samples: Number of samples to return
            seed: Random seed for reproducibility
            
        Returns:
            List of random samples
        """
        np.random.seed(seed)
        
        if num_samples >= len(self.dataset):
            return self.dataset.to_list()
        
        indices = np.random.choice(len(self.dataset), num_samples, replace=False)
        samples = [self.dataset[i] for i in indices]
        
        return samples
    
    def get_balanced_sample(self, 
                          target_field: str = "speaker_id", 
                          samples_per_class: int = 5,
                          max_classes: int = 10) -> List[Dict]:
        """
        Get balanced sample across classes/groups.
        
        Args:
            target_field: Field to balance on
            samples_per_class: Number of samples per class
            max_classes: Maximum number of classes to include
            
        Returns:
            List of balanced samples
        """
        if target_field not in self.dataset.features:
            raise ValueError(f"Field '{target_field}' not found in dataset")
        
        # Group by target field
        class_groups = {}
        for i, sample in enumerate(self.dataset):
            class_value = sample.get(target_field, 'unknown')
            if class_value not in class_groups:
                class_groups[class_value] = []
            class_groups[class_value].append(i)
        
        # Limit number of classes
        class_names = list(class_groups.keys())[:max_classes]
        
        samples = []
        for class_name in class_names:
            indices = class_groups[class_name]
            selected = np.random.choice(
                indices, 
                min(samples_per_class, len(indices)), 
                replace=False
            )
            samples.extend([self.dataset[i] for i in selected])
        
        return samples
    
    def split_for_training(self, 
                          train_ratio: float = 0.8, 
                          val_ratio: float = 0.1, 
                          test_ratio: float = 0.1,
                          seed: int = 42) -> Tuple[List, List, List]:
        """
        Split dataset for training, validation, and testing.
        
        Args:
            train_ratio: Proportion for training set
            val_ratio: Proportion for validation set  
            test_ratio: Proportion for test set
            seed: Random seed
            
        Returns:
            Tuple of (train_samples, val_samples, test_samples)
        """
        np.random.seed(seed)
        
        if abs(train_ratio + val_ratio + test_ratio - 1.0) > 1e-6:
            raise ValueError("Ratios must sum to 1.0")
        
        indices = np.random.permutation(len(self.dataset))
        n = len(indices)
        
        # Calculate split points
        train_end = int(train_ratio * n)
        val_end = train_end + int(val_ratio * n)
        
        train_indices = indices[:train_end]
        val_indices = indices[train_end:val_end]
        test_indices = indices[val_end:]
        
        train_samples = [self.dataset[i] for i in train_indices]
        val_samples = [self.dataset[i] for i in val_indices]
        test_samples = [self.dataset[i] for i in test_indices]
        
        return train_samples, val_samples, test_samples
    
    def create_mini_dataset(self, 
                          num_samples: int = 100,
                          output_file: str = "mini_dataset.json",
                          include_audio: bool = False) -> str:
        """
        Create a mini dataset for testing purposes.
        
        Args:
            num_samples: Number of samples to include
            output_file: Output file path
            include_audio: Whether to include audio data (large files)
            
        Returns:
            Path to saved mini dataset
        """
        samples = self.get_random_sample(num_samples)
        
        # Remove or minimize audio data if requested
        if not include_audio:
            for sample in samples:
                if 'audio' in sample:
                    # Keep only metadata
                    audio_info = sample['audio']
                    sample['audio'] = {
                        'sampling_rate': audio_info.get('sampling_rate'),
                        'duration_estimated': len(audio_info.get('array', [])) / audio_info.get('sampling_rate', 16000)
                    }
        
        # Save mini dataset
        with open(output_file, 'w') as f:
            json.dump(samples, f, indent=2)
        
        print(f"Mini dataset saved to: {output_file} with {len(samples)} samples")
        return output_file


# Convenience functions
def quick_load_dataset(dataset_name: str, split: str = "train") -> Dataset:
    """Quick function to load a dataset without caching complexity."""
    loader = DatasetLoader()
    
    if dataset_name == "lj_speech":
        return loader.get_lj_speech_dataset(split)
    elif dataset_name == "common_voice":
        return loader.get_common_voice_dataset(split=split)
    elif dataset_name == "vctk":
        return loader.get_vctk_dataset(split)
    else:
        return loader.load_dataset(dataset_name, split)


def analyze_dataset_quick(dataset_name: str, split: str = "train") -> Dict:
    """Quick function to analyze a dataset."""
    dataset = quick_load_dataset(dataset_name, split)
    return DatasetAnalyzer.analyze_dataset_statistics(dataset)


if __name__ == "__main__":
    # Example usage
    loader = DatasetLoader()
    
    # Load and analyze LJ Speech dataset
    try:
        print("Loading LJ Speech dataset...")
        dataset = loader.get_lj_speech_dataset("train")
        
        print("Analyzing dataset...")
        stats = DatasetAnalyzer.analyze_dataset_statistics(dataset)
        print("Dataset Statistics:", json.dumps(stats, indent=2))
        
        print("Creating dataset report...")
        DatasetAnalyzer.create_dataset_report(dataset, "lj_speech_report.json")
        
        print("Creating visualizations...")
        DatasetAnalyzer.visualize_dataset_stats(stats, "lj_speech_visualizations")
        
        # Sample data
        sampler = DatasetSampler(dataset)
        samples = sampler.get_random_sample(5)
        print(f"Retrieved {len(samples)} sample records")
        
    except Exception as e:
        print(f"Error during dataset testing: {e}")
        print("This is expected if datasets haven't been downloaded yet.")