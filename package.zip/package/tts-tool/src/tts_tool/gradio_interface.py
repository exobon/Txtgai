"""
Gradio web interface for the Text-to-Speech system.
"""

import os
import json
import gradio as gr
import torch
import tempfile
from typing import List, Dict, Optional, Tuple
from pathlib import Path

from .tts_processor import TTSProcessor
from .advanced_tts import AdvancedTTSProcessor, BatchTTSProcessor, AudioFormatConverter
from .dataset_integration import DatasetLoader, DatasetAnalyzer
try:
    from configs.settings import (
        TTS_MODELS, GradioConfig, DEFAULT_MODEL, DEFAULT_GRADIO_CONFIG
    )
except ImportError:
    # Fallback for direct execution
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from configs.settings import (
        TTS_MODELS, GradioConfig, DEFAULT_MODEL, DEFAULT_GRADIO_CONFIG
    )


class TTSGradioInterface:
    """
    Gradio interface for the TTS system with multiple modes and features.
    """
    
    def __init__(self, 
                 model_name: str = DEFAULT_MODEL,
                 config: GradioConfig = DEFAULT_GRADIO_CONFIG):
        """
        Initialize the Gradio interface.
        
        Args:
            model_name: Default TTS model to use
            config: Gradio configuration settings
        """
        self.config = config
        self.current_model = model_name
        
        # Initialize processors
        self.processor = None
        self.advanced_processor = None
        self.batch_processor = None
        
        self._initialize_processors()
        
        # Interface state
        self.generated_files = []
        self.current_output_dir = "gradio_outputs"
        
        # Create output directory
        os.makedirs(self.current_output_dir, exist_ok=True)
    
    def _initialize_processors(self):
        """Initialize all TTS processors."""
        try:
            print(f"Initializing TTS processors with model: {self.current_model}")
            self.processor = TTSProcessor(self.current_model)
            self.advanced_processor = AdvancedTTSProcessor(self.current_model)
            self.batch_processor = BatchTTSProcessor(self.current_model)
        except Exception as e:
            print(f"Error initializing processors: {str(e)}")
            # Initialize with default model as fallback
            if self.current_model != DEFAULT_MODEL:
                try:
                    self.current_model = DEFAULT_MODEL
                    self.processor = TTSProcessor(DEFAULT_MODEL)
                    self.advanced_processor = AdvancedTTSProcessor(DEFAULT_MODEL)
                    self.batch_processor = BatchTTSProcessor(DEFAULT_MODEL)
                except Exception as e2:
                    print(f"Error with fallback model: {str(e2)}")
    
    def get_model_info(self) -> Dict:
        """Get current model information."""
        if self.processor:
            return self.processor.get_model_info()
        return {"error": "Processor not initialized"}
    
    def tts_single(self, 
                   text: str, 
                   model_choice: str, 
                   emotion: str = "neutral",
                   language: str = "en",
                   normalize_audio: bool = True) -> Tuple[str, str]:
        """
        Single text-to-speech conversion.
        
        Args:
            text: Input text
            model_choice: TTS model to use
            emotion: Emotion for generation
            language: Target language
            normalize_audio: Whether to normalize audio
            
        Returns:
            Tuple of (audio_output, status_message)
        """
        try:
            # Switch model if needed
            if model_choice != self.current_model:
                self.current_model = model_choice
                self._initialize_processors()
            
            if not self.processor:
                return None, "Error: TTS processor not available"
            
            # Generate output filename
            text_preview = text[:20].replace(" ", "_").replace("\n", "_")
            output_path = os.path.join(
                self.current_output_dir, 
                f"tts_{text_preview}.wav"
            )
            
            # Generate speech based on available features
            if hasattr(self.advanced_processor, 'emotion_tags') and emotion != "neutral":
                audio_path = self.advanced_processor.generate_with_emotion(
                    text, emotion, output_path
                )
            else:
                audio_path = self.processor.generate_speech(
                    text, output_path, normalize=normalize_audio
                )
            
            # Track generated files
            self.generated_files.append(audio_path)
            
            return audio_path, f"✅ Speech generated successfully!\n\nModel: {model_choice}\nEmotion: {emotion}\nLanguage: {language}"
            
        except Exception as e:
            error_msg = f"❌ Error generating speech: {str(e)}"
            print(error_msg)
            return None, error_msg
    
    def tts_batch(self, 
                  batch_text: str, 
                  model_choice: str,
                  format_type: str = "wav") -> Tuple[str, str]:
        """
        Batch text-to-speech conversion.
        
        Args:
            batch_text: Multiple texts separated by newlines or semicolons
            model_choice: TTS model to use
            format_type: Output audio format
            
        Returns:
            Tuple of (summary_output, status_message)
        """
        try:
            # Switch model if needed
            if model_choice != self.current_model:
                self.current_model = model_choice
                self._initialize_processors()
            
            if not self.batch_processor:
                return None, "Error: Batch processor not available"
            
            # Parse batch text
            texts = self._parse_batch_text(batch_text)
            
            if not texts:
                return None, "❌ No valid text found in input"
            
            # Create output directory for batch
            batch_output_dir = os.path.join(self.current_output_dir, "batch_output")
            os.makedirs(batch_output_dir, exist_ok=True)
            
            # Process batch with progress callback
            def progress_callback(completed, total, current_text):
                gr.Progress().track(lambda: completed/total * 100, desc=f"Processing {completed}/{total}")
            
            results = self.batch_processor.process_batch(
                texts, 
                batch_output_dir,
                progress_callback=progress_callback
            )
            
            # Create summary
            successful = sum(1 for r in results if r['success'])
            failed = len(results) - successful
            
            summary = f"""📊 Batch Processing Summary

Total texts: {len(results)}
✅ Successful: {successful}
❌ Failed: {failed}

📁 Output directory: {batch_output_dir}

🎵 Generated files:"""
            
            for result in results:
                if result['success']:
                    summary += f"\n  • {os.path.basename(result['output_file'])} ({result['duration']:.1f}s)"
                else:
                    summary += f"\n  • FAILED: {result['text'][:30]}..."
            
            return batch_output_dir, summary
            
        except Exception as e:
            error_msg = f"❌ Error in batch processing: {str(e)}"
            print(error_msg)
            return None, error_msg
    
    def _parse_batch_text(self, batch_text: str) -> List[str]:
        """Parse batch text input into list of texts."""
        if not batch_text.strip():
            return []
        
        # Split by newlines and semicolons
        texts = []
        for line in batch_text.split('\n'):
            for part in line.split(';'):
                part = part.strip()
                if part:
                    texts.append(part)
        
        return texts
    
    def convert_audio_format(self, 
                           audio_file: str, 
                           target_format: str = "mp3",
                           bitrate: str = "192k") -> Tuple[str, str]:
        """
        Convert audio file to different format.
        
        Args:
            audio_file: Input audio file path
            target_format: Target format (mp3, wav, flac)
            bitrate: Bitrate for compressed formats
            
        Returns:
            Tuple of (converted_file_path, status_message)
        """
        try:
            if not audio_file or not os.path.exists(audio_file):
                return None, "❌ Please provide a valid audio file"
            
            converter = AudioFormatConverter()
            
            # Generate output filename
            base_name = os.path.splitext(audio_file)[0]
            output_path = f"{base_name}_converted.{target_format}"
            
            # Convert format
            success = converter.convert_format(audio_file, output_path, target_format, bitrate)
            
            if success:
                return output_path, f"✅ Audio converted successfully!\n\nOriginal: {os.path.basename(audio_file)}\nConverted: {os.path.basename(output_path)}\nFormat: {target_format.upper()}\nBitrate: {bitrate}"
            else:
                return None, "❌ Format conversion failed"
                
        except Exception as e:
            error_msg = f"❌ Error converting audio: {str(e)}"
            print(error_msg)
            return None, error_msg
    
    def dataset_analysis(self, 
                        dataset_choice: str = "lj_speech",
                        analysis_type: str = "statistics") -> str:
        """
        Analyze Hugging Face datasets.
        
        Args:
            dataset_choice: Dataset to analyze
            analysis_type: Type of analysis
            
        Returns:
            Analysis results string
        """
        try:
            loader = DatasetLoader()
            
            if dataset_choice == "lj_speech":
                dataset = loader.get_lj_speech_dataset("train")
            elif dataset_choice == "common_voice":
                dataset = loader.get_common_voice_dataset("en", "train")
            elif dataset_choice == "vctk":
                dataset = loader.get_vctk_dataset("train")
            else:
                return "❌ Dataset not available"
            
            if analysis_type == "statistics":
                stats = DatasetAnalyzer.analyze_dataset_statistics(dataset)
                return self._format_dataset_stats(stats)
            else:
                return "❌ Analysis type not implemented"
                
        except Exception as e:
            error_msg = f"❌ Error analyzing dataset: {str(e)}"
            print(error_msg)
            return error_msg
    
    def _format_dataset_stats(self, stats: Dict) -> str:
        """Format dataset statistics for display."""
        formatted = f"""📊 Dataset Analysis Results

🗂️ Dataset Information:
• Total samples: {stats.get('total_samples', 'N/A')}
• Features: {', '.join(stats.get('features', []))}

🎵 Audio Analysis:"""
        
        if 'audio_analysis' in stats:
            audio_stats = stats['audio_analysis']
            formatted += f"""
• Sample count: {audio_stats.get('sample_count', 'N/A')}
• Avg duration: {audio_stats.get('duration_stats', {}).get('mean', 0):.2f}s
• Duration range: {audio_stats.get('duration_stats', {}).get('min', 0):.2f}s - {audio_stats.get('duration_stats', {}).get('max', 0):.2f}s
• Sample rates: {', '.join(map(str, audio_stats.get('sample_rates', [])))}
"""
        
        formatted += "\n📝 Text Analysis:"
        
        if 'text_analysis' in stats:
            text_stats = stats['text_analysis']
            formatted += f"""
• Sample count: {text_stats.get('sample_count', 'N/A')}
• Avg length: {text_stats.get('character_stats', {}).get('mean', 0):.1f} chars
• Length range: {text_stats.get('character_stats', {}).get('min', 0)} - {text_stats.get('character_stats', {}).get('max', 0)} chars
• Avg words: {text_stats.get('word_stats', {}).get('mean', 0):.1f} words
"""
        
        return formatted
    
    def get_model_options(self) -> List[str]:
        """Get available model options."""
        if self.processor:
            return self.processor.list_available_models()
        return list(TTS_MODELS.keys())
    
    def cleanup_files(self):
        """Clean up generated files."""
        try:
            for file_path in self.generated_files:
                if os.path.exists(file_path):
                    os.remove(file_path)
            self.generated_files.clear()
            return "🗑️ Generated files cleaned up successfully!"
        except Exception as e:
            return f"❌ Error during cleanup: {str(e)}"
    
    def build_interface(self) -> gr.Interface:
        """
        Build the complete Gradio interface.
        
        Returns:
            Configured Gradio interface
        """
        # Get current model info
        model_info = self.get_model_info()
        
        # Custom CSS for better styling
        css = """
        .gradio-container {max-width: 1200px !important; margin: auto !important;}
        .gr-button {font-weight: bold !important;}
        .gr-input, .gr-textbox {font-size: 16px !important;}
        .gr-audio {border: 2px solid #e0e0e0 !important; border-radius: 8px !important;}
        """
        
        with gr.Blocks(css=css, title="Text-to-Speech Converter") as interface:
            
            # Header
            gr.HTML("""
            <div style="text-align: center; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 10px; margin-bottom: 20px;">
                <h1 style="margin: 0; font-size: 2.5em;">🎤 Text-to-Speech Converter</h1>
                <p style="margin: 10px 0 0 0; font-size: 1.2em;">Convert text to natural speech using Hugging Face models</p>
            </div>
            """)
            
            # Model selection and info
            with gr.Row():
                with gr.Column(scale=2):
                    model_choice = gr.Dropdown(
                        choices=self.get_model_options(),
                        value=DEFAULT_MODEL,
                        label="🤖 Select TTS Model",
                        info="Choose the model for speech generation"
                    )
                
                with gr.Column(scale=1):
                    model_status = gr.HTML(f"""
                    <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #007bff;">
                        <h4 style="margin: 0 0 10px 0;">📋 Model Information</h4>
                        <p style="margin: 5px 0;"><strong>Current:</strong> {model_info.get('model_name', 'N/A')}</p>
                        <p style="margin: 5px 0;"><strong>Quality:</strong> {model_info.get('voice_quality', 'N/A')}</p>
                        <p style="margin: 5px 0;"><strong>Speed:</strong> {model_info.get('speed', 'N/A')}</p>
                        <p style="margin: 5px 0;"><strong>Languages:</strong> {len(model_info.get('supported_languages', []))} supported</p>
                    </div>
                    """)
            
            # Main tabs
            with gr.Tabs():
                # Tab 1: Single TTS
                with gr.TabItem("🎵 Single Conversion"):
                    with gr.Row():
                        with gr.Column():
                            text_input = gr.Textbox(
                                label="📝 Input Text",
                                placeholder="Enter your text here...",
                                lines=4,
                                max_lines=10
                            )
                            
                            with gr.Row():
                                emotion = gr.Dropdown(
                                    choices=["neutral", "happy", "sad", "excited", "whisper"],
                                    value="neutral",
                                    label="😊 Emotion",
                                    info="Add emotion to the voice"
                                )
                                
                                language = gr.Dropdown(
                                    choices=["en", "es", "fr", "de", "it", "pt", "ru", "zh", "ja", "ko"],
                                    value="en",
                                    label="🌍 Language",
                                    info="Target language for speech"
                                )
                            
                            generate_btn = gr.Button("🎤 Generate Speech", variant="primary", size="lg")
                        
                        with gr.Column():
                            audio_output = gr.Audio(
                                label="🎧 Generated Audio",
                                type="filepath"
                            )
                            
                            status_output = gr.HTML("""
                            <div style="padding: 15px; background: #e8f5e8; border-radius: 8px; border-left: 4px solid #28a745;">
                                <p style="margin: 0; font-style: italic;">Ready to generate speech...</p>
                            </div>
                            """)
                    
                    # Single TTS event
                    generate_btn.click(
                        fn=self.tts_single,
                        inputs=[text_input, model_choice, emotion, language],
                        outputs=[audio_output, status_output]
                    )
                
                # Tab 2: Batch Processing
                with gr.TabItem("📦 Batch Processing"):
                    with gr.Row():
                        with gr.Column():
                            batch_text = gr.Textbox(
                                label="📝 Batch Text Input",
                                placeholder="Enter multiple texts separated by newlines or semicolons...",
                                lines=8,
                                info="Example: First text\\nSecond text; Third text"
                            )
                            
                            batch_btn = gr.Button("🚀 Process Batch", variant="primary", size="lg")
                        
                        with gr.Column():
                            batch_output = gr.File(
                                label="📁 Batch Output Directory",
                                file_count="multiple"
                            )
                            
                            batch_status = gr.HTML("""
                            <div style="padding: 15px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                                <p style="margin: 0; font-style: italic;">Enter text above and click Process Batch...</p>
                            </div>
                            """)
                    
                    # Batch TTS event
                    batch_btn.click(
                        fn=self.tts_batch,
                        inputs=[batch_text, model_choice],
                        outputs=[batch_output, batch_status]
                    )
                
                # Tab 3: Audio Conversion
                with gr.TabItem("🔄 Audio Converter"):
                    with gr.Row():
                        with gr.Column():
                            convert_audio = gr.Audio(
                                label="🎵 Audio File to Convert",
                                type="filepath"
                            )
                            
                            with gr.Row():
                                target_format = gr.Dropdown(
                                    choices=["mp3", "wav", "flac", "ogg"],
                                    value="mp3",
                                    label="📁 Target Format"
                                )
                                
                                bitrate = gr.Dropdown(
                                    choices=["128k", "192k", "256k", "320k"],
                                    value="192k",
                                    label="🎛️ Bitrate"
                                )
                            
                            convert_btn = gr.Button("🔄 Convert Format", variant="primary", size="lg")
                        
                        with gr.Column():
                            converted_audio = gr.Audio(
                                label="✅ Converted Audio",
                                type="filepath"
                            )
                            
                            convert_status = gr.HTML("""
                            <div style="padding: 15px; background: #d4edda; border-radius: 8px; border-left: 4px solid #28a745;">
                                <p style="margin: 0; font-style: italic;">Select an audio file to convert...</p>
                            </div>
                            """)
                    
                    # Audio conversion event
                    convert_btn.click(
                        fn=self.convert_audio_format,
                        inputs=[convert_audio, target_format, bitrate],
                        outputs=[converted_audio, convert_status]
                    )
                
                # Tab 4: Dataset Analysis
                with gr.TabItem("📊 Dataset Analysis"):
                    with gr.Row():
                        with gr.Column():
                            dataset_choice = gr.Dropdown(
                                choices=["lj_speech", "common_voice", "vctk"],
                                value="lj_speech",
                                label="🗂️ Dataset",
                                info="Choose dataset to analyze"
                            )
                            
                            analyze_btn = gr.Button("📈 Analyze Dataset", variant="primary", size="lg")
                        
                        with gr.Column():
                            analysis_output = gr.HTML("""
                            <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; text-align: center;">
                                <p style="margin: 0; color: #6c757d;">Click "Analyze Dataset" to get started...</p>
                            </div>
                            """)
                    
                    # Dataset analysis event
                    analyze_btn.click(
                        fn=self.dataset_analysis,
                        inputs=[dataset_choice],
                        outputs=[analysis_output]
                    )
                
                # Tab 5: Settings & Info
                with gr.TabItem("⚙️ Settings & Info"):
                    with gr.Row():
                        with gr.Column():
                            gr.HTML("""
                            <div style="padding: 20px; background: #e9ecef; border-radius: 8px; margin-bottom: 20px;">
                                <h3>🛠️ System Settings</h3>
                                <p><strong>Current Model:</strong> {model_info.get('model_name', 'N/A')}</p>
                                <p><strong>Device:</strong> {model_info.get('device', 'N/A')}</p>
                                <p><strong>Sample Rate:</strong> {model_info.get('sample_rate', 'N/A')} Hz</p>
                                <p><strong>Max Text Length:</strong> {model_info.get('max_text_length', 'N/A')} characters</p>
                            </div>
                            """)
                            
                            cleanup_btn = gr.Button("🗑️ Clean Up Generated Files", variant="secondary")
                            cleanup_status = gr.HTML("")
                        
                        with gr.Column():
                            gr.HTML("""
                            <div style="padding: 20px; background: #d1ecf1; border-radius: 8px; margin-bottom: 20px;">
                                <h3>ℹ️ About This Tool</h3>
                                <p><strong>Features:</strong></p>
                                <ul>
                                    <li>Multiple TTS models (SpeechT5, MMS-TTS, Bark)</li>
                                    <li>Emotion and speaker control</li>
                                    <li>Batch processing</li>
                                    <li>Audio format conversion</li>
                                    <li>Dataset analysis</li>
                                    <li>Offline generation</li>
                                </ul>
                                <p><strong>Requirements:</strong> Python 3.8+, PyTorch, Transformers</p>
                            </div>
                            """)
            
            # Cleanup event
            cleanup_btn.click(
                fn=self.cleanup_files,
                outputs=[cleanup_status]
            )
            
            # Update model info when model changes
            model_choice.change(
                fn=lambda x: self._update_model_info(x),
                inputs=[model_choice],
                outputs=[model_status]
            )
        
        return interface
    
    def _update_model_info(self, new_model: str) -> str:
        """Update model information display."""
        try:
            if new_model != self.current_model:
                self.current_model = new_model
                self._initialize_processors()
            
            model_info = self.get_model_info()
            
            return f"""
            <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #007bff;">
                <h4 style="margin: 0 0 10px 0;">📋 Model Information</h4>
                <p style="margin: 5px 0;"><strong>Current:</strong> {model_info.get('model_name', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Quality:</strong> {model_info.get('voice_quality', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Speed:</strong> {model_info.get('speed', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Languages:</strong> {len(model_info.get('supported_languages', []))} supported</p>
                <p style="margin: 5px 0;"><strong>Memory:</strong> {model_info.get('memory_usage', 'N/A')}</p>
            </div>
            """
        except Exception as e:
            return f"""
            <div style="padding: 15px; background: #f8d7da; border-radius: 8px; border-left: 4px solid #dc3545;">
                <h4 style="margin: 0 0 10px 0;">⚠️ Model Error</h4>
                <p style="margin: 5px 0;">Error switching to model: {str(e)}</p>
            </div>
            """
    
    def launch(self, **kwargs):
        """Launch the Gradio interface."""
        interface = self.build_interface()
        interface.launch(**kwargs)


def create_interface(model_name: str = DEFAULT_MODEL) -> TTSGradioInterface:
    """
    Create and return a TTS Gradio interface.
    
    Args:
        model_name: Default TTS model to use
        
    Returns:
        TTSGradioInterface instance
    """
    return TTSGradioInterface(model_name)


if __name__ == "__main__":
    # Launch interface for testing
    interface = create_interface()
    interface.launch(
        share=False,
        inbrowser=True,
        server_name="0.0.0.0",
        server_port=7860
    )