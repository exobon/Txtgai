"""
Advanced TTS features including batch processing, multiple formats, and advanced controls.
"""

import os
import json
import time
from typing import List, Dict, Optional, Union
from pathlib import Path
import torch
import soundfile as sf
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed
from pydub import AudioSegment
import librosa

from .tts_processor import TTSProcessor
try:
    from configs.settings import TTS_MODELS, AudioConfig
except ImportError:
    # Fallback for direct execution
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from configs.settings import TTS_MODELS, AudioConfig


class BatchTTSProcessor:
    """
    Batch processing for multiple text inputs with optimization features.
    """
    
    def __init__(self, model_name: str = "speecht5", max_workers: int = 4):
        """
        Initialize batch TTS processor.
        
        Args:
            model_name: TTS model to use
            max_workers: Maximum number of parallel workers
        """
        self.model_name = model_name
        self.max_workers = max_workers
        self.audio_config = AudioConfig()
        
        # Initialize single processor for model reuse
        self.processor = TTSProcessor(model_name=model_name)
        
        # Results storage
        self.results = []
    
    def process_batch(self, 
                     texts: List[str], 
                     output_dir: str = "batch_outputs",
                     custom_filenames: Optional[List[str]] = None,
                     progress_callback: Optional[callable] = None) -> List[Dict]:
        """
        Process multiple texts in batch.
        
        Args:
            texts: List of texts to convert
            output_dir: Directory to save output files
            custom_filenames: Optional custom filenames for outputs
            progress_callback: Optional callback for progress updates
            
        Returns:
            List of results with file paths and metadata
        """
        os.makedirs(output_dir, exist_ok=True)
        
        results = []
        completed = 0
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all tasks
            future_to_text = {
                executor.submit(self._process_single, text, output_dir, 
                               custom_filename if custom_filenames else None): text
                for text, custom_filename in zip(texts, custom_filenames or [None] * len(texts))
            }
            
            # Process completed tasks
            for future in as_completed(future_to_text):
                try:
                    result = future.result()
                    results.append(result)
                    completed += 1
                    
                    if progress_callback:
                        progress_callback(completed, len(texts), result['text'][:50])
                    
                except Exception as e:
                    text = future_to_text[future]
                    error_result = {
                        'text': text,
                        'success': False,
                        'error': str(e),
                        'output_file': None,
                        'duration': 0.0
                    }
                    results.append(error_result)
                    completed += 1
        
        self.results = results
        return results
    
    def _process_single(self, text: str, output_dir: str, custom_filename: Optional[str]) -> Dict:
        """Process a single text input."""
        start_time = time.time()
        
        try:
            # Generate output filename
            if custom_filename:
                filename = f"{custom_filename}.{self.audio_config.audio_format}"
                output_path = os.path.join(output_dir, filename)
            else:
                output_path = None
            
            # Generate speech
            output_file = self.processor.generate_speech(text, output_path)
            
            # Get audio duration
            duration = self.get_audio_duration(output_file)
            
            end_time = time.time()
            
            return {
                'text': text,
                'success': True,
                'output_file': output_file,
                'duration': duration,
                'processing_time': end_time - start_time,
                'error': None
            }
            
        except Exception as e:
            end_time = time.time()
            return {
                'text': text,
                'success': False,
                'output_file': None,
                'duration': 0.0,
                'processing_time': end_time - start_time,
                'error': str(e)
            }
    
    def get_audio_duration(self, file_path: str) -> float:
        """Get duration of audio file in seconds."""
        try:
            info = sf.info(file_path)
            return info.duration
        except:
            return 0.0
    
    def export_batch_summary(self, results: List[Dict], output_file: str = "batch_summary.json"):
        """Export batch processing summary to JSON."""
        summary = {
            'total_texts': len(results),
            'successful': sum(1 for r in results if r['success']),
            'failed': sum(1 for r in results if not r['success']),
            'total_duration': sum(r['duration'] for r in results if r['success']),
            'total_processing_time': sum(r['processing_time'] for r in results),
            'average_text_length': np.mean([len(r['text']) for r in results]),
            'results': results
        }
        
        with open(output_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        return summary


class AudioFormatConverter:
    """
    Convert audio files between different formats and apply audio effects.
    """
    
    @staticmethod
    def convert_format(input_path: str, 
                      output_path: str, 
                      target_format: str = "mp3",
                      bitrate: str = "192k") -> bool:
        """
        Convert audio file to different format.
        
        Args:
            input_path: Input audio file path
            output_path: Output audio file path  
            target_format: Target format (mp3, wav, flac, etc.)
            bitrate: Bitrate for compressed formats
            
        Returns:
            True if conversion successful, False otherwise
        """
        try:
            audio = AudioSegment.from_file(input_path)
            
            if target_format.lower() == "mp3":
                audio.export(output_path, format="mp3", bitrate=bitrate)
            else:
                audio.export(output_path, format=target_format)
            
            return True
            
        except Exception as e:
            print(f"Error converting format: {str(e)}")
            return False
    
    @staticmethod
    def apply_audio_effects(input_path: str, 
                          output_path: str,
                          normalize: bool = True,
                          fade_in: float = 0.0,
                          fade_out: float = 0.0,
                          speed_factor: float = 1.0) -> bool:
        """
        Apply audio effects to the file.
        
        Args:
            input_path: Input audio file path
            output_path: Output audio file path
            normalize: Normalize audio levels
            fade_in: Fade in duration in seconds
            fade_out: Fade out duration in seconds
            speed_factor: Playback speed factor (1.0 = normal speed)
            
        Returns:
            True if effects applied successfully
        """
        try:
            audio = AudioSegment.from_file(input_path)
            
            # Apply effects
            if normalize:
                audio = audio.normalize()
            
            if fade_in > 0:
                audio = audio.fade_in(int(fade_in * 1000))
            
            if fade_out > 0:
                audio = audio.fade_out(int(fade_out * 1000))
            
            if speed_factor != 1.0:
                audio = audio.speedup(playback_speed=speed_factor)
            
            # Export
            audio.export(output_path, format="wav")
            
            return True
            
        except Exception as e:
            print(f"Error applying audio effects: {str(e)}")
            return False
    
    @staticmethod
    def merge_audio_files(file_list: List[str], output_path: str) -> bool:
        """Merge multiple audio files into one."""
        try:
            combined = AudioSegment.empty()
            
            for file_path in file_list:
                audio = AudioSegment.from_file(file_path)
                combined += audio
            
            combined.export(output_path, format="wav")
            return True
            
        except Exception as e:
            print(f"Error merging audio files: {str(e)}")
            return False


class AdvancedTTSProcessor(TTSProcessor):
    """
    Extended TTS processor with advanced features like speaker control,
    emotion tags, and multi-language support.
    """
    
    def __init__(self, model_name: str = "speecht5"):
        """Initialize advanced TTS processor."""
        super().__init__(model_name)
        self.speaker_controls = {}
        self.emotion_tags = {}
        self.language_settings = {}
        
        self._initialize_controls()
    
    def _initialize_controls(self):
        """Initialize speaker and emotion controls."""
        if self.model_name == "bark":
            # Bark supports emotion and music tags
            self.emotion_tags = {
                "happy": "[happy]",
                "sad": "[sad]",
                "excited": "[excited]",
                "whisper": "[whisper]",
                "laugh": "[laugh]"
            }
        
        elif self.model_name == "speecht5":
            # SpeechT5 supports speaker embeddings
            self.speaker_controls = {
                "default": None,
                "male": self._get_random_embedding(),
                "female": self._get_random_embedding(),
                "child": self._get_random_embedding()
            }
    
    def _get_random_embedding(self):
        """Generate random speaker embedding for demo purposes."""
        return torch.tensor(np.random.normal(0, 1, 512)).float()
    
    def generate_with_emotion(self, 
                             text: str, 
                             emotion: str = "neutral",
                             output_path: Optional[str] = None) -> str:
        """
        Generate speech with emotion tags.
        
        Args:
            text: Input text
            emotion: Emotion type (happy, sad, excited, etc.)
            output_path: Output file path
            
        Returns:
            Path to generated audio file
        """
        if self.model_name == "bark" and emotion in self.emotion_tags:
            # Add emotion tag to text
            emotion_tag = self.emotion_tags[emotion]
            text = f"{emotion_tag}{text}"
        elif self.model_name == "speecht5" and emotion in self.speaker_controls:
            # Use different speaker embedding
            self.speaker_embeddings = self.speaker_controls[emotion]
        
        return self.generate_speech(text, output_path)
    
    def generate_multilingual(self, 
                             text: str, 
                             language: str = "en",
                             output_path: Optional[str] = None) -> str:
        """
        Generate speech in specified language.
        
        Args:
            text: Input text in target language
            language: Target language code
            output_path: Output file path
            
        Returns:
            Path to generated audio file
        """
        model_languages = TTS_MODELS[self.model_name].supported_languages
        
        if language not in model_languages:
            print(f"Warning: Language '{language}' may not be supported by {self.model_name}")
        
        # Add language-specific formatting if needed
        if self.model_name == "bark":
            # Bark can work with multilingual input directly
            pass
        
        return self.generate_speech(text, output_path)
    
    def create_audio_playlist(self, 
                             text_list: List[str],
                             output_dir: str = "playlist",
                             include_silence: float = 1.0) -> str:
        """
        Create a playlist by concatenating multiple audio files.
        
        Args:
            text_list: List of texts to convert
            output_dir: Directory to save individual files
            include_silence: Silence duration between tracks (seconds)
            
        Returns:
            Path to the final playlist file
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate all audio files
        audio_files = []
        for i, text in enumerate(text_list):
            output_path = os.path.join(output_dir, f"track_{i:03d}.wav")
            audio_file = self.generate_speech(text, output_path)
            audio_files.append(audio_file)
        
        # Merge all files with silence
        converter = AudioFormatConverter()
        playlist_path = os.path.join(output_dir, "complete_playlist.wav")
        
        # Create silence segment
        silence = AudioSegment.silent(duration=int(include_silence * 1000))
        
        # Combine all files
        combined = AudioSegment.empty()
        for audio_file in audio_files:
            audio = AudioSegment.from_wav(audio_file)
            combined += audio
            combined += silence
        
        combined.export(playlist_path, format="wav")
        
        return playlist_path


if __name__ == "__main__":
    # Test advanced features
    processor = AdvancedTTSProcessor("speecht5")
    
    # Test emotion-based generation
    try:
        text = "This is a test of emotion-based speech synthesis."
        output = processor.generate_with_emotion(text, "happy")
        print(f"Emotion-based audio: {output}")
    except Exception as e:
        print(f"Error testing emotion features: {e}")
    
    # Test batch processing
    try:
        batch_processor = BatchTTSProcessor()
        texts = [
            "First sentence for batch processing.",
            "Second sentence for batch processing.",
            "Third sentence for batch processing."
        ]
        results = batch_processor.process_batch(texts)
        print(f"Batch results: {len(results)} files processed")
    except Exception as e:
        print(f"Error testing batch processing: {e}")