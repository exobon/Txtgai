"""
Text-to-Speech Converter using Hugging Face models.
"""

from .tts_processor import TTSProcessor
from .advanced_tts import AdvancedTTSProcessor, BatchTTSProcessor, AudioFormatConverter
from .dataset_integration import DatasetLoader, DatasetAnalyzer, DatasetSampler
from .gradio_interface import TTSGradioInterface, create_interface

__version__ = "1.0.0"
__author__ = "MiniMax Agent"

__all__ = [
    "TTSProcessor",
    "AdvancedTTSProcessor", 
    "BatchTTSProcessor",
    "AudioFormatConverter",
    "DatasetLoader",
    "DatasetAnalyzer",
    "DatasetSampler",
    "TTSGradioInterface",
    "create_interface"
]

# Version info
VERSION_INFO = {
    "version": __version__,
    "supported_models": ["speecht5", "mms_tts", "bark"],
    "supported_languages": ["en", "es", "fr", "de", "it", "pt", "ru", "pl", "tr", "zh", "ja", "ko", "hi", "ar", "fa", "ur", "id", "vi", "th", "nl"],
    "supported_formats": ["wav", "mp3", "flac", "ogg"],
    "features": [
        "Single text-to-speech conversion",
        "Batch processing",
        "Audio format conversion",
        "Emotion and speaker control",
        "Dataset analysis",
        "Web interface (Gradio)",
        "Offline operation"
    ]
}