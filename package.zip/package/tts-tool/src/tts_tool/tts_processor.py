"""
Core Text-to-Speech processor using Hugging Face models.
"""

import os
import torch
import torchaudio
import soundfile as sf
import numpy as np
from typing import Dict, List, Optional, Union, Tuple
from pathlib import Path
from transformers import pipeline, AutoTokenizer, AutoModel
from datasets import load_dataset
import warnings
warnings.filterwarnings("ignore")

try:
    from configs.settings import (
        TTS_MODELS, AudioConfig, DEFAULT_DEVICE, 
        MAX_TEXT_LENGTH, CACHE_DIR
    )
except ImportError:
    # Fallback for direct execution
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from configs.settings import (
        TTS_MODELS, AudioConfig, DEFAULT_DEVICE, 
        MAX_TEXT_LENGTH, CACHE_DIR
    )


class TTSProcessor:
    """
    Main TTS processor class that handles text-to-speech conversion
    using multiple Hugging Face models.
    """
    
    def __init__(self, 
                 model_name: str = "speecht5",
                 device: str = DEFAULT_DEVICE,
                 cache_dir: str = CACHE_DIR):
        """
        Initialize the TTS processor.
        
        Args:
            model_name: Name of the TTS model to use
            device: Device to run the model on ('cpu', 'cuda', 'mps')
            cache_dir: Directory for caching downloaded models
        """
        self.model_name = model_name
        self.device = device
        self.cache_dir = cache_dir
        self.audio_config = AudioConfig()
        
        # Create cache directory
        os.makedirs(cache_dir, exist_ok=True)
        
        # Initialize model
        self.model = None
        self.tokenizer = None
        self.processor = None
        self.speaker_embeddings = None
        
        self._load_model()
    
    def _load_model(self):
        """Load the specified TTS model and associated components."""
        try:
            model_config = TTS_MODELS.get(self.model_name)
            if not model_config:
                raise ValueError(f"Model {self.model_name} not found in configuration")
            
            print(f"Loading model: {model_config.model_path}")
            
            # Load the text-to-speech pipeline
            self.processor = pipeline(
                "text-to-speech",
                model=model_config.model_path,
                device=0 if self.device == "cuda" else -1,
                cache_dir=self.cache_dir
            )
            
            # For SpeechT5, load speaker embeddings
            if self.model_name == "speecht5":
                self._load_speaker_embeddings()
            
            print(f"Model {self.model_name} loaded successfully on {self.device}")
            
        except Exception as e:
            print(f"Error loading model {self.model_name}: {str(e)}")
            raise
    
    def _load_speaker_embeddings(self):
        """Load speaker embeddings for SpeechT5 model."""
        try:
            # Use default speaker embedding
            self.speaker_embeddings = torch.tensor(np.random.normal(0, 1, 512)).float()
            print("Speaker embeddings loaded")
        except Exception as e:
            print(f"Warning: Could not load speaker embeddings: {str(e)}")
            self.speaker_embeddings = None
    
    def generate_speech(self, 
                       text: str, 
                       output_path: Optional[str] = None,
                       sample_rate: int = 16000,
                       normalize: bool = True) -> str:
        """
        Generate speech from text and save as audio file.
        
        Args:
            text: Input text to convert to speech
            output_path: Path to save the audio file (optional)
            sample_rate: Sample rate for the output audio
            normalize: Whether to normalize audio levels
            
        Returns:
            Path to the generated audio file
        """
        # Validate input
        if not text or not text.strip():
            raise ValueError("Input text cannot be empty")
        
        if len(text) > MAX_TEXT_LENGTH:
            print(f"Warning: Input text is {len(text)} characters, "
                  f"truncating to {MAX_TEXT_LENGTH}")
            text = text[:MAX_TEXT_LENGTH]
        
        try:
            # Generate speech
            print("Generating speech...")
            
            if self.model_name == "speecht5" and self.speaker_embeddings is not None:
                # Use speaker embeddings for SpeechT5
                audio_data = self.processor(
                    text, 
                    speaker_embeddings=self.speaker_embeddings,
                    return_tensors=True
                )
            else:
                # Standard generation
                audio_data = self.processor(text, return_tensors=True)
            
            # Extract audio tensor
            if isinstance(audio_data, dict):
                if "audio" in audio_data:
                    audio = audio_data["audio"]
                elif "waveform" in audio_data:
                    audio = audio_data["waveform"]
                else:
                    # If the output doesn't contain expected keys, 
                    # it might be a tuple or other format
                    audio = audio_data
            else:
                audio = audio_data
            
            # Handle different audio formats
            audio = self._process_audio(audio, sample_rate, normalize)
            
            # Save audio file
            if output_path is None:
                output_path = self._generate_output_path(text)
            
            self._save_audio(audio, output_path, sample_rate)
            
            print(f"Speech generated and saved to: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"Error generating speech: {str(e)}")
            raise
    
    def _process_audio(self, audio: torch.Tensor, target_sr: int, normalize: bool) -> torch.Tensor:
        """Process and format the audio tensor."""
        # Remove batch dimension if present
        if audio.dim() > 2:
            audio = audio.squeeze(0)
        
        # Convert to numpy for processing
        audio_np = audio.cpu().numpy()
        
        # Resample if necessary
        if hasattr(audio, 'sample_rate'):
            current_sr = audio.sample_rate
        else:
            # Default sample rate for the model
            current_sr = 22050 if self.model_name == "speecht5" else 16000
        
        if current_sr != target_sr:
            import librosa
            audio_np = librosa.resample(audio_np, orig_sr=current_sr, target_sr=target_sr)
        
        # Normalize audio if requested
        if normalize:
            audio_max = np.abs(audio_np).max()
            if audio_max > 0:
                audio_np = audio_np / audio_max
        
        # Convert back to tensor
        audio = torch.from_numpy(audio_np).float()
        
        return audio
    
    def _generate_output_path(self, text: str) -> str:
        """Generate output file path based on text content."""
        # Create output directory
        output_dir = Path(self.audio_config.output_directory)
        output_dir.mkdir(exist_ok=True)
        
        # Create filename from first few words of text
        words = text.strip().split()[:3]
        filename_base = "_".join(words).replace("/", "_").replace("\\", "_")
        if not filename_base:
            filename_base = "output"
        
        # Clean filename
        filename_base = "".join(c for c in filename_base if c.isalnum() or c in "_-").strip()
        filename_base = filename_base[:50]  # Limit length
        
        # Add timestamp for uniqueness
        from datetime import datetime
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        output_path = output_dir / f"{filename_base}_{timestamp}.{self.audio_config.audio_format}"
        
        return str(output_path)
    
    def _save_audio(self, audio: torch.Tensor, output_path: str, sample_rate: int):
        """Save audio tensor to file."""
        try:
            # Convert tensor to numpy
            audio_np = audio.cpu().numpy()
            
            # Use soundfile for high-quality audio saving
            sf.write(output_path, audio_np, sample_rate, subtype='PCM_16')
            
        except Exception as e:
            # Fallback to torchaudio
            try:
                torchaudio.save(output_path, audio.unsqueeze(0), sample_rate)
            except Exception as e2:
                print(f"Error saving audio with both soundfile and torchaudio: {str(e2)}")
                raise e2
    
    def get_model_info(self) -> Dict:
        """Get information about the loaded model."""
        model_config = TTS_MODELS.get(self.model_name, {})
        return {
            "model_name": self.model_name,
            "model_path": model_config.get("model_path", ""),
            "supported_languages": model_config.get("supported_languages", []),
            "voice_quality": model_config.get("voice_quality", ""),
            "speed": model_config.get("speed", ""),
            "memory_usage": model_config.get("memory_usage", ""),
            "description": model_config.get("description", ""),
            "device": self.device,
            "sample_rate": self.audio_config.sample_rate,
            "max_text_length": MAX_TEXT_LENGTH
        }
    
    def list_available_models(self) -> List[str]:
        """List all available TTS models."""
        return list(TTS_MODELS.keys())
    
    def switch_model(self, new_model_name: str):
        """Switch to a different TTS model."""
        if new_model_name not in TTS_MODELS:
            raise ValueError(f"Model {new_model_name} not available")
        
        self.model_name = new_model_name
        print(f"Switching to model: {new_model_name}")
        self._load_model()


# Utility functions
def validate_audio_file(file_path: str) -> bool:
    """Validate if the audio file is readable."""
    try:
        sf.info(file_path)
        return True
    except:
        return False


def get_audio_duration(file_path: str) -> float:
    """Get duration of an audio file in seconds."""
    try:
        info = sf.info(file_path)
        return info.duration
    except:
        return 0.0


if __name__ == "__main__":
    # Example usage
    processor = TTSProcessor()
    
    # Print model information
    info = processor.get_model_info()
    print("Model Info:", info)
    
    # Generate sample speech
    sample_text = "Hello! This is a test of the text-to-speech system."
    try:
        output_file = processor.generate_speech(sample_text)
        print(f"Sample audio generated: {output_file}")
    except Exception as e:
        print(f"Error generating sample: {e}")