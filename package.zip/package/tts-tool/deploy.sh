#!/bin/bash

# 🚀 TTS Tool Quick Deployment Script
# This script helps you quickly deploy your TTS tool to GitHub and cloud platforms

echo "🎤 Text-to-Speech Tool Deployment Script"
echo "========================================"
echo ""

# Check if we're in the right directory
if [ ! -f "main.py" ]; then
    echo "❌ Error: Please run this script from the tts-tool directory"
    echo "   Run: cd tts-tool && ./deploy.sh"
    exit 1
fi

echo "📁 Current directory: $(pwd)"
echo ""

# Function to deploy to Hugging Face Spaces
deploy_huggingface() {
    echo "🚀 Deploying to Hugging Face Spaces..."
    echo ""
    echo "Steps:"
    echo "1. Create a new Space at https://huggingface.co/spaces"
    echo "2. Choose 'Gradio' as SDK"
    echo "3. Select this repository"
    echo "4. Click 'Create a Space'"
    echo ""
    echo "Your app will be available at:"
    echo "https://your-username-tts-tool.hf.space"
    echo ""
    echo "📋 Files needed for deployment:"
    echo "  - app.py (Gradio interface)"
    echo "  - requirements.txt (dependencies)"
    echo "  - spaces.yml (configuration)"
}

# Function to deploy to GitHub
deploy_github() {
    echo "📤 Preparing GitHub repository..."
    echo ""
    
    # Check if git is initialized
    if [ ! -d ".git" ]; then
        echo "Initializing Git repository..."
        git init
        git add .
        git commit -m "Initial TTS tool deployment - $(date)"
        git branch -M main
    fi
    
    echo "✅ Git repository ready!"
    echo ""
    echo "Next steps:"
    echo "1. Create repository on GitHub: https://github.com/new"
    echo "2. Repository name: tts-tool (or your preferred name)"
    echo "3. Make it public for Hugging Face Spaces"
    echo "4. Copy the repository URL"
    echo "5. Run: git remote add origin YOUR_REPO_URL"
    echo "6. Run: git push -u origin main"
}

# Function to test local deployment
test_local() {
    echo "🧪 Testing local deployment..."
    echo ""
    
    # Test basic functionality
    echo "Testing CLI interface..."
    python main.py --help > /dev/null
    if [ $? -eq 0 ]; then
        echo "✅ CLI interface working"
    else
        echo "❌ CLI interface failed"
        exit 1
    fi
    
    # Test web interface
    echo "Testing web interface..."
    echo "🌐 Starting web server on port 7860..."
    echo "📝 Test URL: http://localhost:7860"
    echo "⚠️  Press Ctrl+C to stop the server"
    echo ""
    
    python main.py --web --port 7860
}

# Main menu
echo "Choose deployment option:"
echo "1. Prepare GitHub repository"
echo "2. Deploy to Hugging Face Spaces"
echo "3. Test local deployment"
echo "4. Show all deployment options"
echo "5. Exit"
echo ""
read -p "Enter your choice (1-5): " choice

case $choice in
    1)
        deploy_github
        ;;
    2)
        deploy_huggingface
        ;;
    3)
        test_local
        ;;
    4)
        echo "📋 All Deployment Options:"
        echo ""
        echo "🏗️  GitHub Repository:"
        echo "   1. git init"
        echo "   2. git add ."
        echo "   3. git commit -m 'Initial deployment'"
        echo "   4. Create repo on GitHub"
        echo "   5. git remote add origin URL"
        echo "   6. git push -u origin main"
        echo ""
        echo "☁️  Hugging Face Spaces:"
        echo "   1. Go to https://huggingface.co/spaces"
        echo "   2. Create new Space"
        echo "   3. Choose Gradio SDK"
        echo "   4. Select your GitHub repo"
        echo "   5. Deploy automatically"
        echo ""
        echo "🚀 Render.com:"
        echo "   1. Go to https://render.com"
        echo "   2. Create Web Service"
        echo "   3. Connect GitHub repo"
        echo "   4. Build: pip install -r requirements.txt"
        echo "   5. Start: python main.py --web --port \$PORT"
        ;;
    5)
        echo "👋 Goodbye!"
        exit 0
        ;;
    *)
        echo "❌ Invalid choice. Please run the script again."
        exit 1
        ;;
esac

echo ""
echo "🎉 Deployment script completed!"
echo "📚 For detailed instructions, see: DEPLOYMENT_COMPLETE.md"
