# Contributing to TTS Tool

Thank you for your interest in contributing to TTS Tool! This document provides guidelines and information for contributors.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Making Changes](#making-changes)
- [Testing](#testing)
- [Code Style](#code-style)
- [Submitting Pull Requests](#submitting-pull-requests)
- [Documentation](#documentation)

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please read it before contributing.

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally
3. Create a new branch for your feature or fix
4. Make your changes
5. Test your changes
6. Submit a pull request

## Development Setup

### Prerequisites

- Python 3.8 or higher
- Git
- FFmpeg (for audio processing)

### Setup

```bash
# Clone your fork
git clone https://github.com/yourusername/tts-tool.git
cd tts-tool

# Install development dependencies
make install-dev

# Set up pre-commit hooks
make dev-setup
```

### Running Tests

```bash
# Run all tests
make test

# Run only unit tests
make test-unit

# Run only integration tests
make test-integration
```

### Code Formatting and Linting

```bash
# Format code
make format

# Check formatting
make format-check

# Run linting
make lint

# Run security checks
make security
```

## Making Changes

### Branch Naming

Use descriptive branch names:

- `feature/add-batch-processing` - New features
- `fix/audio-format-bug` - Bug fixes
- `docs/update-readme` - Documentation updates
- `refactor/tts-processor` - Code refactoring
- `test/add-integration-tests` - Adding tests

### Commit Messages

Follow conventional commit format:

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance tasks

Examples:
```
feat(tts): add emotion control to AdvancedTTSProcessor
fix(audio): resolve MP3 conversion issue
docs: update installation instructions
```

## Testing

### Writing Tests

- Write tests for all new features
- Update existing tests for bug fixes
- Place tests in `tests/` directory
- Use descriptive test names
- Follow pytest conventions

### Test Structure

```python
def test_feature_description():
    """Test description."""
    # Arrange
    # Act
    # Assert
```

### Running Tests

```bash
# Run all tests
pytest tests/

# Run with coverage
pytest tests/ --cov=src/tts_tool

# Run specific test file
pytest tests/test_specific.py

# Run with markers
pytest -m unit  # Run only unit tests
pytest -m "not slow"  # Skip slow tests
```

## Code Style

### Python Style Guide

We follow PEP 8 with these exceptions:

- Line length: 88 characters (Black default)
- Use type hints for all public functions and methods
- Use docstrings for all public functions, classes, and modules

### Code Formatting

We use:
- **Black** for code formatting
- **isort** for import sorting
- **flake8** for linting
- **mypy** for type checking

### Type Hints

Use type hints for better code documentation:

```python
from typing import List, Dict, Optional

def process_texts(texts: List[str], output_dir: str) -> Dict[str, str]:
    """Process texts to speech."""
    pass
```

### Documentation

Use Google-style docstrings:

```python
def generate_speech(text: str, output_file: str) -> str:
    """Generate speech from text.
    
    Args:
        text: Text to convert to speech
        output_file: Output audio file path
        
    Returns:
        Path to generated audio file
        
    Raises:
        ValueError: If text is empty
        RuntimeError: If TTS generation fails
    """
    pass
```

## Submitting Pull Requests

### Before Submitting

1. Run all tests: `make test`
2. Check code style: `make lint`
3. Format code: `make format`
4. Update documentation if needed
5. Add tests for new features

### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Code refactoring

## Testing
- [ ] Tests pass locally
- [ ] Added tests for new functionality
- [ ] Manual testing performed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] Tests added/updated
```

### Review Process

1. **Automated Checks**: All CI checks must pass
2. **Code Review**: At least one maintainer review required
3. **Testing**: Manual testing may be required for features
4. **Documentation**: Documentation must be updated for new features

## Documentation

### API Documentation

- Document all public classes and functions
- Include usage examples
- Update docstrings when changing APIs

### User Documentation

- Update README.md for user-facing changes
- Add examples for new features
- Keep installation instructions current

### Developer Documentation

- Document architecture decisions
- Update CONTRIBUTING.md for process changes
- Add comments for complex code sections

## Additional Resources

- [Python Style Guide](https://pep8.org/)
- [Type Hints Guide](https://docs.python.org/3/library/typing.html)
- [pytest Documentation](https://docs.pytest.org/)
- [GitHub Flow](https://guides.github.com/introduction/flow/)

## Questions?

Feel free to open an issue for:
- Questions about contributing
- Feature requests
- Bug reports
- Discussion of changes

Thank you for contributing to TTS Tool!
