# TTS Tool

A comprehensive Text-to-Speech (TTS) converter using Hugging Face models with support for multiple languages, emotions, and batch processing.

## Features

- **Multiple TTS Models**: Support for SpeechT5, MMS-TTS, and Bark models
- **Multilingual Support**: 20+ languages supported
- **Batch Processing**: Convert multiple texts efficiently
- **Audio Format Conversion**: Convert between WAV, MP3, FLAC, OGG formats
- **Dataset Integration**: Analyze and process Hugging Face datasets
- **Web Interface**: Interactive Gradio interface for easy use
- **Emotion Control**: Add emotions like happy, sad, excited to generated speech
- **Speaker Control**: Use different speaker embeddings with SpeechT5

## Installation

### From Source

```bash
git clone https://github.com/yourusername/tts-tool.git
cd tts-tool
pip install -r requirements.txt
```

### As a Package

```bash
pip install tts-tool
```

## Quick Start

### Command Line Usage

```bash
# Launch web interface
python main.py --web

# Convert text to speech
python main.py --text "Hello world" --output hello.wav

# Batch conversion
python main.py --batch texts.txt --output-dir batch_output

# Analyze dataset
python main.py --analyze-dataset lj_speech

# Convert audio format
python main.py --convert-audio input.wav --format mp3
```

### Python API

```python
from tts_tool import AdvancedTTSProcessor

# Create processor
processor = AdvancedTTSProcessor("speecht5")

# Generate speech
output_file = processor.generate_speech(
    "Hello, this is a test of the TTS system.",
    "output.wav"
)

# Generate with emotion
output_file = processor.generate_with_emotion(
    "This is exciting news!",
    "excited.wav", 
    emotion="happy"
)
```

### Web Interface

```python
from tts_tool import create_interface

# Launch web interface
interface = create_interface("speecht5")
interface.launch()
```

## Supported Models

### SpeechT5 (Microsoft)
- **Quality**: High
- **Languages**: English
- **Features**: Speaker embeddings, unified architecture
- **Best for**: Professional English TTS with voice control

### MMS-TTS (Facebook)
- **Quality**: Medium  
- **Languages**: 20+ languages
- **Features**: Multilingual, low resource usage, fast inference
- **Best for**: Multilingual applications and edge deployment

### Bark (Suno)
- **Quality**: Very High
- **Languages**: 13 languages  
- **Features**: Creative audio, emotion tags, sound effects
- **Best for**: Creative content and highest quality audio

## Examples

See the `examples/` directory for more detailed usage examples:

- `basic_usage.py` - Basic TTS conversion
- `batch_processing.py` - Batch text-to-speech conversion
- `demo.py` - Complete demo with all features

## Dataset Integration

Analyze and process Hugging Face datasets:

```python
from tts_tool import DatasetLoader, DatasetAnalyzer

# Load dataset
loader = DatasetLoader()
dataset = loader.get_lj_speech_dataset("train")

# Analyze dataset
stats = DatasetAnalyzer.analyze_dataset_statistics(dataset)
print(stats)
```

Supported datasets:
- LJ Speech
- Common Voice  
- VCTK

## Batch Processing

Process multiple texts efficiently:

```python
from tts_tool import BatchTTSProcessor

processor = BatchTTSProcessor("speecht5", workers=4)

texts = [
    "First text to convert",
    "Second text to convert", 
    "Third text to convert"
]

results = processor.process_batch(texts, "output_dir")
```

## Audio Format Conversion

Convert between different audio formats:

```python
from tts_tool import AudioFormatConverter

converter = AudioFormatConverter()
converter.convert_format("input.wav", "output.mp3", "mp3", "192k")
```

## API Reference

### Core Classes

- `TTSProcessor` - Base TTS processor
- `AdvancedTTSProcessor` - Advanced TTS with emotions and speaker control
- `BatchTTSProcessor` - Batch processing for multiple texts
- `AudioFormatConverter` - Audio format conversion utility
- `DatasetLoader` - Hugging Face dataset integration
- `DatasetAnalyzer` - Dataset analysis utilities
- `TTSGradioInterface` - Web interface component

### Configuration

The tool supports various configuration options:

- `--model` - Choose TTS model (speecht5, mms_tts, bark)
- `--device` - Set device (cpu, cuda, mps)
- `--cache-dir` - Model cache directory
- `--emotion` - Voice emotion (neutral, happy, sad, excited, whisper)
- `--language` - Target language code
- `--normalize` - Normalize audio levels

## Development

### Setup for Development

```bash
git clone https://github.com/yourusername/tts-tool.git
cd tts-tool
pip install -r requirements.txt
pip install -e .
```

### Running Tests

```bash
pytest tests/ --cov=src/tts_tool
```

### Code Style

This project uses:
- `flake8` for linting
- `pytest` for testing
- `black` for code formatting

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Run tests and linting
6. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Acknowledgments

- Microsoft for SpeechT5
- Facebook for MMS-TTS
- Suno for Bark
- Hugging Face for transformers library
- Gradio for the web interface
