"""
Basic tests for TTS Tool package structure.
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

import tts_tool
from tts_tool import TTSProcessor, AdvancedTTSProcessor, DatasetLoader, create_interface


def test_package_import():
    """Test that all main components can be imported."""
    assert tts_tool.__version__ is not None
    assert TTSProcessor is not None
    assert AdvancedTTSProcessor is not None
    assert DatasetLoader is not None
    assert create_interface is not None
    print("✓ All imports successful")


def test_version_info():
    """Test that version info is available."""
    assert 'version' in tts_tool.VERSION_INFO
    assert 'supported_models' in tts_tool.VERSION_INFO
    assert 'features' in tts_tool.VERSION_INFO
    print(f"✓ Version: {tts_tool.__version__}")


def test_supported_models():
    """Test that supported models are defined."""
    models = tts_tool.VERSION_INFO['supported_models']
    assert 'speecht5' in models
    assert 'mms_tts' in models
    assert 'bark' in models
    print(f"✓ Supported models: {', '.join(models)}")


if __name__ == '__main__':
    test_package_import()
    test_version_info()
    test_supported_models()
    print("\n✓ All tests passed!")
