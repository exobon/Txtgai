"""
Demo script showcasing the complete Text-to-Speech Converter functionality.

This script provides a comprehensive demonstration of all features.
"""

import os
import sys
import time
from pathlib import Path

# Add code directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'code'))

from code import TTSProcessor, AdvancedTTSProcessor, BatchTTSProcessor, create_interface
from code.dataset_integration import DatasetLoader, DatasetAnalyzer
from code.advanced_tts import AudioFormatConverter
from configs.settings import TTS_MODELS


def print_header(title, width=60):
    """Print formatted header."""
    print("\n" + "="*width)
    print(f" {title} ".center(width))
    print("="*width)


def demo_intro():
    """Introduction and system check."""
    print_header("Text-to-Speech Converter Demo")
    
    print("🎤 Welcome to the comprehensive TTS demonstration!")
    print("This demo will showcase all major features of the converter.")
    
    # System check
    print("\n🔍 System Check:")
    
    try:
        import torch
        print(f"  ✅ PyTorch: {torch.__version__}")
        print(f"  ✅ CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"  ✅ GPU: {torch.cuda.get_device_name(0)}")
    except ImportError:
        print("  ❌ PyTorch not found")
    
    try:
        import transformers
        print(f"  ✅ Transformers: {transformers.__version__}")
    except ImportError:
        print("  ❌ Transformers not found")
    
    try:
        import gradio
        print(f"  ✅ Gradio: {gradio.__version__}")
    except ImportError:
        print("  ❌ Gradio not found")
    
    print(f"  ✅ System ready for demonstration")
    
    # Create demo directories
    os.makedirs("demo_outputs", exist_ok=True)
    print(f"  📁 Demo directory created: demo_outputs/")


def demo_single_conversion():
    """Demonstrate single text-to-speech conversion."""
    print_header("Single Text-to-Speech Conversion")
    
    text = "Welcome to our text-to-speech demonstration. This technology can convert any text into natural-sounding speech."
    
    for model_name in ["speecht5", "mms_tts"]:
        try:
            print(f"\n🤖 Testing model: {model_name}")
            start_time = time.time()
            
            processor = TTSProcessor(model_name)
            output_file = f"demo_outputs/single_{model_name}.wav"
            
            result_file = processor.generate_speech(text, output_file)
            
            end_time = time.time()
            info = processor.get_model_info()
            
            print(f"  ✅ Generated: {result_file}")
            print(f"  ⏱️ Processing time: {end_time - start_time:.2f} seconds")
            print(f"  📊 Quality: {info.get('voice_quality', 'N/A')}")
            print(f"  🗣️ Language: {', '.join(info.get('supported_languages', []))}")
            
        except Exception as e:
            print(f"  ❌ Error with {model_name}: {e}")


def demo_advanced_features():
    """Demonstrate advanced TTS features."""
    print_header("Advanced TTS Features")
    
    try:
        # Test advanced processor
        processor = AdvancedTTSProcessor("speecht5")
        
        # Emotion-based generation
        text = "This is an exciting announcement about our new product launch!"
        
        print(f"\n🎭 Emotion-based generation:")
        emotions = ["neutral", "happy"]
        
        for emotion in emotions:
            try:
                output_file = f"demo_outputs/emotion_{emotion}.wav"
                result_file = processor.generate_with_emotion(text, emotion, output_file)
                print(f"  ✅ {emotion.capitalize()}: {os.path.basename(result_file)}")
            except Exception as e:
                print(f"  ⚠️ {emotion.capitalize()} emotion: {e}")
        
        # Multilingual generation
        print(f"\n🌍 Multilingual generation:")
        multilingual_texts = {
            "en": "Hello, welcome to our service.",
            "es": "Hola, bienvenido a nuestro servicio."
        }
        
        for lang, text in multilingual_texts.items():
            try:
                output_file = f"demo_outputs/multilingual_{lang}.wav"
                result_file = processor.generate_multilingual(text, lang, output_file)
                print(f"  ✅ {lang.upper()}: {os.path.basename(result_file)}")
            except Exception as e:
                print(f"  ⚠️ {lang.upper()}: {e}")
        
    except Exception as e:
        print(f"❌ Error in advanced features: {e}")


def demo_batch_processing():
    """Demonstrate batch processing capabilities."""
    print_header("Batch Processing Demo")
    
    try:
        batch_processor = BatchTTSProcessor("speecht5", max_workers=2)
        
        # Sample texts for batch processing
        texts = [
            "First announcement for our morning broadcast.",
            "Weather update: Sunny skies expected today.", 
            "Important reminder about tomorrow's meeting.",
            "Thank you for listening to our channel.",
            "Final message: Have a wonderful day!"
        ]
        
        print(f"📦 Processing {len(texts)} texts in batch...")
        
        # Process batch
        results = batch_processor.process_batch(
            texts,
            output_dir="demo_outputs/batch",
            progress_callback=lambda completed, total, text: print(f"  📈 {completed}/{total}")
        )
        
        # Summary
        successful = sum(1 for r in results if r['success'])
        total_duration = sum(r['duration'] for r in results if r['success'])
        
        print(f"\n📊 Batch Results:")
        print(f"  ✅ Successful: {successful}/{len(texts)}")
        print(f"  ⏱️ Total duration: {total_duration:.1f} seconds")
        print(f"  📁 Output directory: demo_outputs/batch/")
        
        # Export summary
        summary_file = batch_processor.export_batch_summary(
            results, "demo_outputs/batch_summary.json"
        )
        print(f"  📄 Summary file: batch_summary.json")
        
    except Exception as e:
        print(f"❌ Error in batch processing: {e}")


def demo_audio_conversion():
    """Demonstrate audio format conversion and effects."""
    print_header("Audio Conversion & Effects")
    
    try:
        # First generate a sample audio
        processor = TTSProcessor("speecht5")
        sample_text = "This audio will be converted to different formats and enhanced with effects."
        
        print(f"🎵 Generating sample audio...")
        wav_file = processor.generate_speech(sample_text, "demo_outputs/sample.wav")
        print(f"  ✅ Generated: {wav_file}")
        
        # Test format conversion
        converter = AudioFormatConverter()
        
        print(f"\n🔄 Format conversion:")
        formats = ["mp3", "flac"]
        
        for fmt in formats:
            try:
                output_file = f"demo_outputs/sample_converted.{fmt}"
                success = converter.convert_format(wav_file, output_file, fmt)
                if success:
                    print(f"  ✅ Converted to {fmt.upper()}: {os.path.basename(output_file)}")
                else:
                    print(f"  ❌ Failed to convert to {fmt}")
            except Exception as e:
                print(f"  ❌ Error converting to {fmt}: {e}")
        
        # Test audio effects
        print(f"\n🎛️ Audio effects:")
        try:
            enhanced_file = "demo_outputs/sample_enhanced.wav"
            success = converter.apply_audio_effects(
                wav_file,
                enhanced_file,
                normalize=True,
                fade_in=0.5,
                fade_out=0.5
            )
            
            if success:
                print(f"  ✅ Enhanced audio: {os.path.basename(enhanced_file)}")
                print(f"    - Normalization applied")
                print(f"    - Fade in/out effects added")
            else:
                print(f"  ❌ Failed to apply effects")
                
        except Exception as e:
            print(f"  ❌ Error applying effects: {e}")
        
    except Exception as e:
        print(f"❌ Error in audio conversion: {e}")


def demo_dataset_analysis():
    """Demonstrate dataset analysis capabilities."""
    print_header("Dataset Analysis Demo")
    
    try:
        print("📊 Analyzing LJ Speech dataset...")
        
        # Load dataset (this may take a while on first run)
        loader = DatasetLoader()
        dataset = loader.get_lj_speech_dataset("train")
        
        print(f"  📥 Dataset loaded: {len(dataset)} samples")
        
        # Analyze statistics
        stats = DatasetAnalyzer.analyze_dataset_statistics(dataset)
        
        print(f"\n📈 Dataset Statistics:")
        print(f"  🗂️ Total samples: {stats.get('total_samples', 'N/A')}")
        print(f"  📋 Features: {', '.join(stats.get('features', []))}")
        
        if 'audio_analysis' in stats:
            audio_stats = stats['audio_analysis']
            if 'duration_stats' in audio_stats:
                dur_stats = audio_stats['duration_stats']
                print(f"  🎵 Audio duration:")
                print(f"    - Average: {dur_stats.get('mean', 0):.2f} seconds")
                print(f"    - Range: {dur_stats.get('min', 0):.2f}s - {dur_stats.get('max', 0):.2f}s")
        
        if 'text_analysis' in stats:
            text_stats = stats['text_analysis']
            if 'character_stats' in text_stats:
                char_stats = text_stats['character_stats']
                print(f"  📝 Text characteristics:")
                print(f"    - Average length: {char_stats.get('mean', 0):.1f} characters")
                print(f"    - Range: {char_stats.get('min', 0)} - {char_stats.get('max', 0)} characters")
        
        # Create mini dataset sample
        print(f"\n📦 Creating mini dataset sample...")
        from code.dataset_integration import DatasetSampler
        
        sampler = DatasetSampler(dataset)
        mini_samples = sampler.get_random_sample(5, seed=42)
        
        print(f"  ✅ Created sample of {len(mini_samples)} records")
        print(f"  💾 Sample saved to dataset cache")
        
    except Exception as e:
        print(f"❌ Error in dataset analysis: {e}")


def demo_web_interface():
    """Demonstrate web interface capabilities."""
    print_header("Web Interface Demo")
    
    try:
        print("🌐 Web interface components:")
        
        # Create interface
        interface = create_interface("speecht5")
        
        # Get model info
        info = interface.get_model_info()
        
        print(f"  🤖 Model loaded: {info.get('model_name', 'N/A')}")
        print(f"  📊 Quality: {info.get('voice_quality', 'N/A')}")
        print(f"  ⚡ Speed: {info.get('speed', 'N/A')}")
        print(f"  🌍 Languages: {len(info.get('supported_languages', []))}")
        
        print(f"\n🚀 Web Interface Features:")
        print(f"  ✅ Single text-to-speech conversion")
        print(f"  ✅ Batch processing with progress tracking")
        print(f"  ✅ Audio format conversion")
        print(f"  ✅ Dataset analysis tools")
        print(f"  ✅ Model selection and configuration")
        print(f"  ✅ Real-time audio playback and download")
        
        print(f"\n🌐 To launch web interface:")
        print(f"  python main.py --web --port 7860")
        print(f"  Visit: http://localhost:7860")
        
    except Exception as e:
        print(f"❌ Error in web interface demo: {e}")


def demo_performance_comparison():
    """Compare performance across different models."""
    print_header("Performance Comparison")
    
    text = "Performance comparison test for text-to-speech models."
    
    model_results = {}
    
    for model_name in ["speecht5", "mms_tts"]:
        try:
            print(f"\n⚡ Testing {model_name}...")
            
            # Warm up
            processor = TTSProcessor(model_name)
            processor.generate_speech("Warm up text.", "demo_outputs/warmup.wav")
            
            # Actual test
            start_time = time.time()
            output_file = f"demo_outputs/performance_{model_name}.wav"
            result_file = processor.generate_speech(text, output_file)
            end_time = time.time()
            
            processing_time = end_time - start_time
            
            # Get model info
            info = processor.get_model_info()
            
            model_results[model_name] = {
                'processing_time': processing_time,
                'quality': info.get('voice_quality', 'N/A'),
                'speed': info.get('speed', 'N/A'),
                'memory': info.get('memory_usage', 'N/A')
            }
            
            print(f"  ⏱️ Processing time: {processing_time:.2f} seconds")
            print(f"  ⭐ Quality: {info.get('voice_quality', 'N/A')}")
            print(f"  🚀 Speed rating: {info.get('speed', 'N/A')}")
            
        except Exception as e:
            print(f"  ❌ Error testing {model_name}: {e}")
    
    # Summary
    print(f"\n📊 Performance Summary:")
    for model, results in model_results.items():
        print(f"  🤖 {model}:")
        print(f"    - Time: {results['processing_time']:.2f}s")
        print(f"    - Quality: {results['quality']}")
        print(f"    - Speed: {results['speed']}")
        print(f"    - Memory: {results['memory']}")


def demo_cleanup():
    """Clean up demo files and show summary."""
    print_header("Demo Summary & Cleanup")
    
    print("🧹 Demo completed! Here's what was generated:")
    
    demo_files = []
    if os.path.exists("demo_outputs"):
        for root, dirs, files in os.walk("demo_outputs"):
            for file in files:
                if file.endswith(('.wav', '.mp3', '.flac', '.json')):
                    demo_files.append(os.path.join(root, file))
    
    if demo_files:
        print(f"\n📁 Generated {len(demo_files)} files:")
        for file in demo_files[:10]:  # Show first 10 files
            print(f"  📄 {os.path.relpath(file)}")
        
        if len(demo_files) > 10:
            print(f"  ... and {len(demo_files) - 10} more files")
        
        print(f"\n🗑️ To clean up demo files:")
        print(f"  rm -rf demo_outputs/")
        print(f"  rm -rf models_cache/")
        print(f"  rm -rf dataset_cache/")
    else:
        print("  No files were generated (some features may have failed)")
    
    print(f"\n🎯 Next Steps:")
    print(f"  1. Run 'python main.py --web' to launch the web interface")
    print(f"  2. Try 'python examples/basic_usage.py' for more examples")
    print(f"  3. Check 'docs/' directory for detailed documentation")
    print(f"  4. Modify 'configs/settings.py' to customize behavior")
    
    print(f"\n💡 Tips:")
    print(f"  - Use GPU for faster processing (--device cuda)")
    print(f"  - Increase workers for batch processing (--workers 4)")
    print(f"  - Check 'examples/' directory for usage patterns")
    print(f"  - Monitor 'demo_outputs/' for generated audio files")


def main():
    """Run the complete demo."""
    print("🎤" * 20)
    print("TEXT-TO-SPEECH CONVERTER DEMONSTRATION")
    print("🎤" * 20)
    
    try:
        demo_intro()
        demo_single_conversion()
        demo_advanced_features()
        demo_batch_processing()
        demo_audio_conversion()
        demo_dataset_analysis()
        demo_web_interface()
        demo_performance_comparison()
        demo_cleanup()
        
        print(f"\n🎉 Demo completed successfully!")
        print(f"Thank you for trying the Text-to-Speech Converter!")
        
    except KeyboardInterrupt:
        print(f"\n👋 Demo interrupted by user")
    except Exception as e:
        print(f"\n❌ Demo failed with error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()