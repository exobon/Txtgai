"""
Basic usage examples for the Text-to-Speech Converter.

This script demonstrates fundamental TTS functionality using different models.
"""

import os
import sys
from pathlib import Path

# Add code directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'code'))

from code import TTSProcessor, AdvancedTTSProcessor
from configs.settings import TTS_MODELS


def example_basic_tts():
    """Basic text-to-speech conversion example."""
    print("🎤 Example 1: Basic TTS Conversion")
    print("-" * 40)
    
    try:
        # Initialize processor with SpeechT5
        processor = TTSProcessor("speecht5")
        
        # Sample text
        text = "Hello! This is a basic example of text-to-speech conversion using Hugging Face models."
        
        print(f"📝 Text: {text}")
        print(f"🤖 Model: speecht5")
        
        # Generate speech
        output_file = processor.generate_speech(text, "examples/output_basic.wav")
        
        print(f"✅ Generated: {output_file}")
        print(f"📊 Model Info: {processor.get_model_info()}")
        
    except Exception as e:
        print(f"❌ Error: {e}")


def example_multiple_models():
    """Compare multiple TTS models."""
    print("\n🔄 Example 2: Comparing Multiple Models")
    print("-" * 40)
    
    text = "This is a test of different text-to-speech models."
    
    for model_name in ["speecht5", "mms_tts", "bark"]:
        try:
            print(f"\n🤖 Testing model: {model_name}")
            processor = TTSProcessor(model_name)
            
            # Generate output filename
            output_file = f"examples/output_{model_name}.wav"
            
            # Generate speech
            result_file = processor.generate_speech(text, output_file)
            
            # Show model info
            info = processor.get_model_info()
            print(f"  ✅ Generated: {result_file}")
            print(f"  📊 Quality: {info.get('voice_quality', 'N/A')}")
            print(f"  ⚡ Speed: {info.get('speed', 'N/A')}")
            
        except Exception as e:
            print(f"  ❌ Error with {model_name}: {e}")


def example_advanced_features():
    """Advanced TTS features with emotions and controls."""
    print("\n🎭 Example 3: Advanced Features")
    print("-" * 40)
    
    try:
        # Initialize advanced processor
        processor = AdvancedTTSProcessor("bark")
        
        text = "This is an example with emotions and advanced controls!"
        
        # Test different emotions (if supported)
        emotions = ["neutral", "happy", "excited"]
        
        for emotion in emotions:
            print(f"\n😊 Generating with emotion: {emotion}")
            output_file = f"examples/output_emotion_{emotion}.wav"
            
            try:
                result_file = processor.generate_with_emotion(text, emotion, output_file)
                print(f"  ✅ Generated: {result_file}")
            except Exception as e:
                print(f"  ⚠️ Emotion '{emotion}' not available: {e}")
        
        # Test multilingual support (if supported)
        print(f"\n🌍 Testing language support...")
        multilingual_texts = {
            "en": "Hello, this is English text.",
            "es": "Hola, este es texto en español.",
            "fr": "Bonjour, c'est du texte en français."
        }
        
        for lang, text in multilingual_texts.items():
            try:
                print(f"  📝 Language: {lang}")
                output_file = f"examples/output_language_{lang}.wav"
                result_file = processor.generate_multilingual(text, lang, output_file)
                print(f"    ✅ Generated: {result_file}")
            except Exception as e:
                print(f"    ❌ Language {lang} not supported: {e}")
        
    except Exception as e:
        print(f"❌ Error in advanced features: {e}")


def example_audio_processing():
    """Audio processing and format conversion examples."""
    print("\n🔄 Example 4: Audio Processing")
    print("-" * 40)
    
    try:
        from code import AudioFormatConverter
        
        # First, generate a WAV file
        processor = TTSProcessor("speecht5")
        text = "This audio will be converted to different formats."
        
        wav_file = processor.generate_speech(text, "examples/temp_audio.wav")
        print(f"🎵 Generated base audio: {wav_file}")
        
        # Test format conversion
        converter = AudioFormatConverter()
        target_formats = ["mp3", "flac", "ogg"]
        
        for target_format in target_formats:
            try:
                output_file = f"examples/temp_audio_converted.{target_format}"
                success = converter.convert_format(wav_file, output_file, target_format)
                
                if success:
                    print(f"  ✅ Converted to {target_format.upper()}: {output_file}")
                else:
                    print(f"  ❌ Failed to convert to {target_format}")
                    
            except Exception as e:
                print(f"  ❌ Error converting to {target_format}: {e}")
        
        # Test audio effects
        print(f"\n🎛️ Testing audio effects...")
        enhanced_file = "examples/temp_audio_enhanced.wav"
        
        success = converter.apply_audio_effects(
            wav_file, 
            enhanced_file,
            normalize=True,
            fade_in=0.5,
            fade_out=0.5,
            speed_factor=1.0
        )
        
        if success:
            print(f"  ✅ Enhanced audio: {enhanced_file}")
        else:
            print(f"  ❌ Failed to apply effects")
        
    except Exception as e:
        print(f"❌ Error in audio processing: {e}")


def example_model_info():
    """Display detailed model information."""
    print("\n📊 Example 5: Model Information")
    print("-" * 40)
    
    for model_name, config in TTS_MODELS.items():
        print(f"\n🤖 Model: {model_name}")
        print(f"  📝 Description: {config.description}")
        print(f"  🌍 Languages: {len(config.supported_languages)} supported")
        print(f"  ⭐ Quality: {config.voice_quality}")
        print(f"  ⚡ Speed: {config.speed}")
        print(f"  💾 Memory: {config.memory_usage}")
        print(f"  💡 Best for: {config.recommended_usage}")
        
        # Show sample languages
        sample_langs = config.supported_languages[:5]
        if len(config.supported_languages) > 5:
            sample_langs.append("...")
        print(f"  🗣️ Sample languages: {', '.join(sample_langs)}")


def main():
    """Run all examples."""
    print("🚀 Text-to-Speech Converter - Basic Examples")
    print("=" * 50)
    
    # Create examples directory
    os.makedirs("examples", exist_ok=True)
    
    try:
        # Run examples
        example_basic_tts()
        example_multiple_models()
        example_advanced_features()
        example_audio_processing()
        example_model_info()
        
        print(f"\n🎉 All examples completed!")
        print(f"📁 Check the 'examples/' directory for generated audio files")
        
    except KeyboardInterrupt:
        print(f"\n👋 Examples interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()