"""
Batch processing examples for the Text-to-Speech Converter.

This script demonstrates batch text-to-speech conversion with various features.
"""

import os
import sys
from pathlib import Path

# Add code directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'code'))

from code import BatchTTSProcessor
from code.advanced_tts import AudioFormatConverter


def example_simple_batch():
    """Simple batch processing example."""
    print("📦 Example 1: Simple Batch Processing")
    print("-" * 40)
    
    try:
        # Initialize batch processor
        batch_processor = BatchTTSProcessor("speecht5", max_workers=2)
        
        # Sample texts for batch processing
        texts = [
            "Welcome to our company presentation today.",
            "The weather forecast shows sunny skies ahead.",
            "Thank you for listening to our announcement.",
            "This is the final message of our broadcast.",
            "Have a wonderful day ahead, everyone!"
        ]
        
        print(f"📝 Processing {len(texts)} texts...")
        
        # Process batch with progress tracking
        def progress_callback(completed, total, current_text):
            percentage = (completed / total) * 100
            print(f"  Progress: {completed}/{total} ({percentage:.1f}%) - {current_text[:30]}...")
        
        results = batch_processor.process_batch(
            texts, 
            output_dir="examples/batch_simple",
            progress_callback=progress_callback
        )
        
        # Print summary
        successful = sum(1 for r in results if r['success'])
        failed = len(results) - successful
        
        print(f"\n📊 Batch Summary:")
        print(f"  ✅ Successful: {successful}")
        print(f"  ❌ Failed: {failed}")
        print(f"  📁 Output directory: examples/batch_simple/")
        
        # Show detailed results
        for i, result in enumerate(results, 1):
            if result['success']:
                print(f"  {i}. ✅ {result['text'][:30]}... ({result['duration']:.1f}s)")
            else:
                print(f"  {i}. ❌ {result['text'][:30]}... ({result['error']})")
        
        # Export batch summary
        summary_file = batch_processor.export_batch_summary(
            results, "examples/batch_simple_summary.json"
        )
        print(f"  📄 Summary saved: examples/batch_simple_summary.json")
        
    except Exception as e:
        print(f"❌ Error in batch processing: {e}")


def example_custom_batch():
    """Batch processing with custom filenames."""
    print("\n🎨 Example 2: Custom Filenames Batch")
    print("-" * 40)
    
    try:
        batch_processor = BatchTTSProcessor("mms_tts", max_workers=3)
        
        # Texts with custom output names
        texts_with_filenames = {
            "Welcome to our platform. Please sign up to get started.": "welcome_message",
            "Your appointment has been confirmed for tomorrow at 2 PM.": "appointment_reminder", 
            "Payment processing complete. Thank you for your purchase.": "payment_confirmation",
            "System maintenance scheduled for this weekend.": "maintenance_notice"
        }
        
        texts = list(texts_with_filenames.keys())
        custom_filenames = list(texts_with_filenames.values())
        
        print(f"📝 Processing {len(texts)} texts with custom filenames...")
        
        results = batch_processor.process_batch(
            texts,
            output_dir="examples/batch_custom",
            custom_filenames=custom_filenames
        )
        
        # Show results with custom names
        print(f"\n📁 Generated files:")
        for result in results:
            if result['success']:
                filename = os.path.basename(result['output_file'])
                print(f"  ✅ {filename}")
            else:
                print(f"  ❌ Failed: {result['text'][:30]}...")
        
    except Exception as e:
        print(f"❌ Error in custom batch processing: {e}")


def example_large_batch():
    """Large batch processing example (simulated)."""
    print("\n🚀 Example 3: Large Batch Processing")
    print("-" * 40)
    
    try:
        batch_processor = BatchTTSProcessor("speecht5", max_workers=4)
        
        # Generate a large number of sample texts (simulation)
        base_texts = [
            "This is message number {} for testing purposes.",
            "Batch processing test number {} with different content.",
            "Audio generation number {} completed successfully.",
            "Processing request number {} in the queue."
        ]
        
        # Create 20 sample texts (reduced for demo purposes)
        texts = []
        for i in range(1, 21):  # 20 texts instead of 100
            template = base_texts[i % len(base_texts)]
            texts.append(template.format(i))
        
        print(f"📝 Processing {len(texts)} texts (large batch simulation)...")
        
        # Process batch
        results = batch_processor.process_batch(
            texts,
            output_dir="examples/batch_large",
            progress_callback=lambda completed, total, text: print(f"  📈 {completed}/{total}: {text[:25]}...")
        )
        
        # Performance analysis
        total_duration = sum(r['duration'] for r in results if r['success'])
        total_processing_time = sum(r['processing_time'] for r in results)
        avg_text_length = sum(len(r['text']) for r in results) / len(results)
        
        print(f"\n📊 Performance Analysis:")
        print(f"  ⏱️ Total audio duration: {total_duration:.1f} seconds")
        print(f"  🕐 Total processing time: {total_processing_time:.1f} seconds")
        print(f"  📏 Average text length: {avg_text_length:.1f} characters")
        print(f"  ⚡ Processing speed: {len(results)/total_processing_time:.2f} texts/second")
        
        # Show processing distribution
        print(f"\n📈 Processing Time Distribution:")
        processing_times = [r['processing_time'] for r in results if r['success']]
        if processing_times:
            min_time = min(processing_times)
            max_time = max(processing_times)
            avg_time = sum(processing_times) / len(processing_times)
            print(f"  ⏱️ Fastest: {min_time:.2f}s")
            print(f"  ⏱️ Slowest: {max_time:.2f}s")
            print(f"  ⏱️ Average: {avg_time:.2f}s")
        
    except Exception as e:
        print(f"❌ Error in large batch processing: {e}")


def example_audio_playlist():
    """Create audio playlist from batch processing."""
    print("\n🎵 Example 4: Audio Playlist Creation")
    print("-" * 40)
    
    try:
        # Use advanced TTS processor for playlist creation
        from code import AdvancedTTSProcessor
        
        processor = AdvancedTTSProcessor("speecht5")
        
        # Create a playlist of announcements
        playlist_texts = [
            "Welcome to our radio station. This is the morning show.",
            "Here's the latest news update from around the world.",
            "Don't forget to check out our upcoming events this weekend.",
            "Weather forecast: Sunny skies with a high of 75 degrees.",
            "This has been your host, thank you for listening. Have a great day!"
        ]
        
        print(f"🎵 Creating audio playlist with {len(playlist_texts)} segments...")
        
        # Generate playlist
        playlist_file = processor.create_audio_playlist(
            playlist_texts,
            output_dir="examples/playlist",
            include_silence=2.0  # 2 seconds between segments
        )
        
        print(f"✅ Playlist created: {playlist_file}")
        
        # Get playlist info
        if os.path.exists(playlist_file):
            from code.advanced_tts import get_audio_duration
            duration = get_audio_duration(playlist_file)
            print(f"  ⏱️ Total duration: {duration:.1f} seconds")
            print(f"  📁 Individual segments: examples/playlist/track_*.wav")
            print(f"  🔗 Combined playlist: {os.path.basename(playlist_file)}")
        
    except Exception as e:
        print(f"❌ Error creating playlist: {e}")


def example_multilingual_batch():
    """Batch processing with multilingual content."""
    print("\n🌍 Example 5: Multilingual Batch Processing")
    print("-" * 40)
    
    try:
        batch_processor = BatchTTSProcessor("mms_tts", max_workers=2)
        
        # Multilingual texts
        multilingual_texts = [
            "Hello, welcome to our service. How can I help you today?",  # English
            "Bonjour, bienvenue dans notre service. Comment puis-je vous aider?",  # French
            "Hola, bienvenido a nuestro servicio. ¿Cómo puedo ayudarte?",  # Spanish
            "Guten Tag, willkommen bei unserem Service. Wie kann ich Ihnen helfen?",  # German
            "Ciao, benvenuto nel nostro servizio. Come posso aiutarti?"  # Italian
        ]
        
        print(f"🌍 Processing {len(multilingual_texts)} texts in different languages...")
        
        results = batch_processor.process_batch(
            multilingual_texts,
            output_dir="examples/batch_multilingual"
        )
        
        print(f"\n📁 Generated multilingual audio files:")
        for i, result in enumerate(results, 1):
            if result['success']:
                filename = os.path.basename(result['output_file'])
                print(f"  {i}. ✅ {filename}")
            else:
                print(f"  {i}. ❌ Failed: {result['error']}")
        
        # Language detection simulation (basic)
        languages = ["EN", "FR", "ES", "DE", "IT"]
        print(f"\n🗣️ Languages processed: {', '.join(languages)}")
        
    except Exception as e:
        print(f"❌ Error in multilingual batch processing: {e}")


def main():
    """Run all batch processing examples."""
    print("🚀 Text-to-Speech Converter - Batch Processing Examples")
    print("=" * 55)
    
    # Create examples directory
    os.makedirs("examples", exist_ok=True)
    
    try:
        # Run examples
        example_simple_batch()
        example_custom_batch()
        example_large_batch()
        example_audio_playlist()
        example_multilingual_batch()
        
        print(f"\n🎉 All batch examples completed!")
        print(f"📁 Check the 'examples/' directory for all generated files")
        print(f"💡 Tips for large batches:")
        print(f"  - Use more workers for faster processing")
        print(f"  - Monitor memory usage with large datasets")  
        print(f"  - Check GPU availability for better performance")
        print(f"  - Use custom filenames for better organization")
        
    except KeyboardInterrupt:
        print(f"\n👋 Batch examples interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()