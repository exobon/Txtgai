# 🚀 Installation Guide

This guide provides detailed installation instructions for the Text-to-Speech Converter across different platforms and environments.

## 📋 Prerequisites

### System Requirements

- **Python**: 3.8 or higher
- **Memory**: 4GB RAM minimum (8GB recommended)
- **Storage**: 5GB free space (for models and dependencies)
- **Internet**: Required for initial model downloads

### Optional Hardware

- **GPU**: NVIDIA GPU with CUDA support (for faster inference)
- **CPU**: Multi-core processor recommended for batch processing

## 🔧 Installation Methods

### Method 1: Standard Installation

#### 1. Clone Repository
```bash
git clone <repository-url>
cd text-to-speech-converter
```

#### 2. Create Virtual Environment (Recommended)
```bash
# Create virtual environment
python -m venv tts_env

# Activate virtual environment
# On Linux/macOS:
source tts_env/bin/activate
# On Windows:
tts_env\Scripts\activate
```

#### 3. Install Dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

#### 4. Verify Installation
```bash
python -c "from code import TTSProcessor; print('✅ Installation successful!')"
```

### Method 2: Conda Installation

#### 1. Create Conda Environment
```bash
conda create -n tts_converter python=3.9
conda activate tts_converter
```

#### 2. Install PyTorch (GPU Optional)
```bash
# CPU version
conda install pytorch torchvision torchaudio cpuonly -c pytorch

# GPU version (CUDA 11.8)
conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia

# GPU version (CUDA 12.1)
conda install pytorch torchvision torchaudio pytorch-cuda=12.1 -c pytorch -c nvidia
```

#### 3. Install Remaining Dependencies
```bash
pip install transformers datasets huggingface-hub gradio librosa soundfile pydub
pip install numpy pandas matplotlib tqdm ipython
```

### Method 3: Docker Installation

#### 1. Create Dockerfile
```dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    ffmpeg \
    libsndfile1 \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Expose port for web interface
EXPOSE 7860

CMD ["python", "main.py", "--web"]
```

#### 2. Build and Run
```bash
# Build Docker image
docker build -t tts-converter .

# Run container
docker run -p 7860:7860 -v $(pwd)/outputs:/app/outputs tts-converter
```

## 🌍 Platform-Specific Instructions

### Windows

#### Requirements
- Windows 10/11 (64-bit)
- Visual C++ Build Tools (for some dependencies)

#### Installation Steps
```bash
# Install Python from python.org or use Windows Store
# Install Git from git-scm.com

# Clone and setup
git clone <repository-url>
cd text-to-speech-converter

# Create virtual environment
python -m venv tts_env
tts_env\Scripts\activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Run
python main.py --web
```

#### Potential Windows Issues
1. **ffmpeg not found**: Install ffmpeg manually or add to PATH
2. **Permission errors**: Run terminal as administrator
3. **Path length**: Enable long path support in Windows

### macOS

#### Requirements
- macOS 10.15 (Catalina) or higher
- Xcode Command Line Tools

#### Installation Steps
```bash
# Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install ffmpeg and other dependencies
brew install ffmpeg libsndfile

# Clone repository
git clone <repository-url>
cd text-to-speech-converter

# Create virtual environment
python3 -m venv tts_env
source tts_env/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Run
python main.py --web
```

### Linux (Ubuntu/Debian)

#### Installation Steps
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install system dependencies
sudo apt install -y python3 python3-pip python3-venv ffmpeg libsndfile1

# Clone repository
git clone <repository-url>
cd text-to-speech-converter

# Create virtual environment
python3 -m venv tts_env
source tts_env/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Run
python main.py --web
```

### Linux (CentOS/RHEL)

#### Installation Steps
```bash
# Install development tools
sudo yum groupinstall "Development Tools"
sudo yum install python3 python3-pip python3-venv ffmpeg

# Clone repository
git clone <repository-url>
cd text-to-speech-converter

# Create virtual environment
python3 -m venv tts_env
source tts_env/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Run
python main.py --web
```

## ☁️ Cloud Platform Installation

### Google Colab

```python
# Install in Colab cell
!pip install -r https://raw.githubusercontent.com/username/text-to-speech-converter/main/requirements.txt

# Clone repository
!git clone https://github.com/username/text-to-speech-converter.git
%cd text-to-speech-converter

# Import and use
from code import TTSProcessor
processor = TTSProcessor("speecht5")
```

### AWS EC2

```bash
# Create EC2 instance (t3.medium or larger recommended)
# SSH into instance

# Install dependencies
sudo yum update -y
sudo yum install -y python3 python3-pip git ffmpeg

# Clone and setup
git clone <repository-url>
cd text-to-speech-converter
python3 -m venv tts_env
source tts_env/bin/activate
pip install -r requirements.txt

# Run
python main.py --web --port 80
```

### Azure VM

```bash
# Create Ubuntu VM in Azure Portal
# SSH into VM

# Install dependencies
sudo apt update && sudo apt install -y python3 python3-pip git ffmpeg

# Clone and setup
git clone <repository-url>
cd text-to-speech-converter
python3 -m venv tts_env
source tts_env/bin/activate
pip install -r requirements.txt

# Run
python main.py --web --port 8080
```

### Heroku

#### 1. Create requirements.txt (already included)
```bash
# Already provided in the repository
```

#### 2. Create Procfile
```
web: python main.py --web --port $PORT
```

#### 3. Deploy
```bash
# Install Heroku CLI and login
heroku create your-app-name
git push heroku main
```

### Streamlit Cloud

```python
# Create app.py
import streamlit as st
from code import TTSProcessor

st.title("Text-to-Speech Converter")

text = st.text_area("Enter text:")
if st.button("Generate Speech"):
    processor = TTSProcessor("speecht5")
    audio_file = processor.generate_speech(text)
    st.audio(audio_file)
```

Deploy to Streamlit Cloud by connecting your GitHub repository.

## 🔧 GPU Setup (Optional)

### NVIDIA GPU Support

#### Check GPU Availability
```python
import torch
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"GPU count: {torch.cuda.device_count()}")
if torch.cuda.is_available():
    print(f"GPU name: {torch.cuda.get_device_name(0)}")
```

#### Install GPU Version of PyTorch
```bash
# For CUDA 11.8
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# For CUDA 12.1  
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# Verify installation
python -c "import torch; print(torch.cuda.is_available())"
```

### AMD GPU Support (ROCm)

```bash
# Install ROCm
sudo apt install rocm-dev rocm-libs

# Install PyTorch ROCm version
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/rocm5.4.2
```

## 🐛 Troubleshooting

### Common Installation Issues

#### 1. Import Errors
```bash
# Check Python version
python --version

# Check if virtual environment is activated
which python

# Reinstall problematic packages
pip uninstall torch transformers
pip install torch transformers
```

#### 2. Audio Dependencies
```bash
# Install system audio libraries
# Ubuntu/Debian
sudo apt install portaudio19-dev python3-pyaudio

# macOS
brew install portaudio

# Windows
# Usually included with PyAudio
```

#### 3. Model Download Issues
```bash
# Clear Hugging Face cache
rm -rf ~/.cache/huggingface/

# Set custom cache directory
export HF_HOME=/path/to/custom/cache
```

#### 4. Permission Issues
```bash
# Fix Python permissions
chmod +x main.py

# Fix directory permissions
chmod 755 ./
chmod 644 requirements.txt
```

#### 5. Memory Issues
```bash
# Reduce batch size for large texts
export PYTORCH_MPS_HIGH_WATERMARK_RATIO=0.0  # Disable MPS on macOS

# Use CPU for memory-intensive operations
export TTS_DEVICE=cpu
```

### Performance Optimization

#### 1. Enable Model Caching
```bash
# Set cache directory
export HF_HOME=~/.cache/huggingface/
export TRANSFORMERS_CACHE=~/.cache/huggingface/transformers/

# Create cache directories
mkdir -p ~/.cache/huggingface/transformers/
mkdir -p ~/.cache/huggingface/datasets/
```

#### 2. Optimize for Your Hardware
```bash
# For low-memory systems
export TTS_DEVICE=cpu
export MAX_BATCH_SIZE=1

# For high-performance systems  
export TTS_DEVICE=cuda
export MAX_BATCH_SIZE=4
```

#### 3. Pre-download Models
```python
from transformers import AutoTokenizer, AutoModelForTextToSpeech

# Pre-download models to avoid runtime delays
models = ["microsoft/speecht5_tts", "facebook/mms-tts-tacotron2", "suno/bark"]
for model_name in models:
    AutoTokenizer.from_pretrained(model_name)
    AutoModelForTextToSpeech.from_pretrained(model_name)
```

## ✅ Verification

### Test Installation
```python
# Test basic functionality
python -c "
from code import TTSProcessor, create_interface
print('✅ Core modules imported successfully')

# Test processor
processor = TTSProcessor('speecht5')
info = processor.get_model_info()
print('✅ TTS processor working:', info['model_name'])

# Test interface
interface = create_interface()
print('✅ Web interface creation successful')

print('🎉 All tests passed!')
"
```

### Run Examples
```bash
# Test basic usage
python examples/basic_usage.py

# Test batch processing
python examples/batch_processing.py
```

### Launch Web Interface
```bash
# Test web interface
python main.py --web --port 7860
```

Visit `http://localhost:7860` to verify the web interface works.

## 📞 Getting Help

If you encounter installation issues:

1. **Check system requirements** - Ensure Python 3.8+ and sufficient memory
2. **Verify dependencies** - Run `pip check` to identify conflicts
3. **Check logs** - Use `--verbose` flag for detailed error messages
4. **Clear cache** - Remove cached models and try again
5. **Update pip** - Ensure you have the latest pip version

### Useful Commands
```bash
# Check installation
python -m pip list | grep -E "(torch|transformers|gradio)"

# Verify CUDA
python -c "import torch; print(torch.cuda.is_available())"

# Check system info
python -c "import sys, platform; print(f'Python: {sys.version}'); print(f'Platform: {platform.platform()}')"
```

---

**Need more help?** Check our [FAQ](faq.md) or create an issue on GitHub.