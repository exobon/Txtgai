# Hugging Face Datasets for Audio: Loading, Processing, Structures, Transformers Integration, and TTS/ASR Usage

## Executive Summary

Hugging Face Datasets provides a unified, efficient library for loading, streaming, and processing audio corpora for training and evaluation across speech tasks. It is designed for speed and scale, backed by Apache Arrow to enable zero‑copy reads and streaming mode for memory‑efficient pipelines that start fast and avoid full downloads. The library integrates deeply with the Hugging Face Hub, where dataset cards and preview tools support rapid exploration and reproducibility across audio collections. For practitioners, the key workflows are: load datasets from the Hub or local/remote sources; cast audio columns to the desired sampling rate; preprocess with map and filter; optionally stream large corpora; and finally integrate with Transformers processors and tokenizers for ASR (automatic speech recognition) and TTS (text‑to‑speech). These capabilities are documented in the Datasets documentation and the audio processing guides, and the Hub offers broad coverage of audio datasets and task filters to help teams select suitable corpora for their systems[^2][^1][^5][^6].

## Scope, Methodology, and Source Reliability

This report focuses on: (1) dataset loading methods and streaming; (2) audio processing and transformations with Datasets; (3) dataset structures and content for representative corpora including LJ Speech, Common Voice, and Multilingual LibriSpeech (MLS); (4) integration of Datasets with Transformers for ASR/TTS; and (5) concrete usage examples covering preprocessing, training, and evaluation. The primary sources are official Hugging Face documentation and dataset cards, augmented by the Common Voice data download portal and a peer‑reviewed paper on MLS. Where relevant, the report calls out access constraints such as rate limiting on certain pages. The synthesis prioritizes official documentation and dataset cards for technical accuracy, supported by third‑party references only where they provide verifiable technical specifics absent from the primary sources[^4][^11][^14].

## Hugging Face Datasets Library Overview

Hugging Face Datasets is a library for accessing and sharing datasets across modalities, including audio, computer vision, and NLP. It supports one‑line loading from the Hugging Face Hub, large‑scale processing, and streaming to avoid full downloads. The backend uses Apache Arrow to enable zero‑copy reads and efficient operations on large datasets. Datasets integrates with popular frameworks (PyTorch, TensorFlow, JAX, NumPy, Pandas, Polars, PyArrow, Spark), includes a command‑line interface, supports caching and multiple filesystems, and allows creating search indexes (FAISS and Elasticsearch). Beyond individual workflows, the library encourages sharing datasets on the Hub, complete with dataset cards that capture provenance, licensing, and usage notes[^2].

### Core Concepts: DatasetDict, Dataset, and the Audio Feature

Audio datasets are typically returned as a DatasetDict containing split‑named Dataset objects (e.g., “train”, “validation”, “test”). Each Dataset holds columnar data where the Audio feature denotes a column that loads and decodes audio arrays on access. Best practice is to query by sample index (e.g., dataset[0]["audio"]) rather than by column (e.g., dataset["audio"][0]) to avoid expensive materialization and ensure performance, particularly for large corpora[^1][^7].

### Streaming Mode

Streaming mode allows iteration over datasets without downloading everything to disk. It is ideal for rapid prototyping, constrained storage environments, and very large corpora where immediate access to samples matters more than cached completeness. The trade‑off is the absence of local caching: re‑iteration re‑fetches or re‑processes data. In audio, streaming enables early starts (e.g., begin preprocessing while archives are still being fetched) and supports sharded or TAR‑based formats that would otherwise be impractical to materialize[^4][^1].

## Dataset Loading Methods

Datasets offers flexible, unified APIs to load from the Hugging Face Hub, local files, and remote sources. It supports a wide range of formats (CSV, JSON, Parquet, Arrow, HDF5, SQL), multiprocessing for sharded datasets, split slicing, and offline loading from cache. For large‑scale audio, WebDataset TAR archives can be streamed directly, and in‑memory Dataset constructors enable ad‑hoc creation from Python structures or generators[^4][^19].

To illustrate the breadth of options and common parameters, Table 1 summarizes the core loading methods and supported formats.

### Table 1. Loading methods and supported formats (APIs and common parameters)

| Source/Format            | API/Function                 | Key Parameters/Notes                                                                                       |
|--------------------------|------------------------------|------------------------------------------------------------------------------------------------------------|
| Hugging Face Hub         | load_dataset(name, ...)      | revision, data_files, data_dir, split; map files to splits; subset selection via patterns                  |
| CSV                      | load_dataset("csv", ...)     | data_files; delimiter; column_names                                                                        |
| JSON                     | load_dataset("json", ...)    | data_files; field for nested data                                                                          |
| Parquet                  | load_dataset("parquet", ...) | data_files; split; columnar efficiency                                                                     |
| Arrow                    | load_dataset("arrow", ...)   | data_files; Dataset.from_file for memory‑mapped Arrow                                                      |
| HDF5                     | load_dataset("hdf5", ...)    | data_files; assumes tabular structure                                                                      |
| SQL                      | Dataset.from_sql             | con (SQLAlchemy URI); table name or SELECT query                                                           |
| WebDataset (TAR)         | load_dataset("webdataset", ...) | data_files for TAR URLs; streaming=True recommended                                                        |
| Multiprocessing (shards) | load_dataset(..., num_proc=N)| Parallel preparation across shards                                                                         |
| In‑memory (dict/list)    | Dataset.from_dict / from_list| Construct from Python structures                                                                           |
| Generator                | Dataset.from_generator       | Supports sharding and buffers; useful for data larger than memory                                          |
| Offline                  | HF_HUB_OFFLINE=1             | Load from cache only                                                                                       |
| Split slicing            | split=...                    | String API and ReadInstruction for ranges and concatenation                                                |

These approaches let teams design predictable pipelines regardless of source or format, and prepare splits safely using either concise string instructions or explicit ReadInstruction objects[^4][^19].

### Split Slicing

Datasets supports precise split slicing, including concatenation, ranges, and percentage‑based partitions. Table 2 provides concrete examples for common use cases.

### Table 2. Split slicing examples and use cases

| Example                                  | Use Case                                                                 |
|------------------------------------------|---------------------------------------------------------------------------|
| "train+test"                             | Combine disjoint splits for full‑set experiments                          |
| "train[10:20]"                           | Select a specific row range for a mini‑validation                        |
| "train[:10%]"                            | Create a quick validation subset (first 10%)                              |
| "train[50%:52%](pct1_dropremainder)"     | Equal‑sized percentage slices; drop remainder                            |
| datasets.ReadInstruction(..., rounding=…)| Fine‑grained control for percentage boundaries                            |

Rounding defaults to nearest integer; the pct1_dropremainder option ensures equal‑size percentage slices at the cost of truncating trailing examples not divisible by 100[^4].

## Audio Processing Capabilities in Datasets

The Audio feature provides on‑the‑fly decoding and resampling of audio columns. Casting a column to a target sampling rate (e.g., 16 kHz) ensures subsequent accesses yield arrays at the desired rate. Combined with map and filter, practitioners can implement end‑to‑end preprocessing pipelines aligned to model requirements, including feature extraction and tokenization through Transformers processors[^5][^1].

Table 3 outlines a concise capability matrix and typical operations.

### Table 3. Audio capabilities matrix

| Capability                     | API/Method                           | Notes                                                                                         |
|--------------------------------|--------------------------------------|-----------------------------------------------------------------------------------------------|
| Resampling                     | cast_column("audio", Audio(sr=...))  | On‑the‑fly decoding and resampling; verify with dataset[0]["audio"]["sampling_rate"]          |
| Batch preprocessing            | map(prepare_dataset, remove_columns=…) | Integrate feature extractors/processors; compute derived fields like input_length             |
| Column management              | remove_columns / rename_columns      | Retain only essential features; rename for downstream consistency                             |
| Filtering                      | filter(fn, input_columns=[…])        | Remove out‑of‑range durations or invalid samples                                              |
| Streaming & iteration          | load_dataset(..., streaming=True)    | Memory‑efficient iteration; use for very large or sharded corpora                             |

### Transformers Integration at Preprocessing Time

Transformers provides feature extractors, tokenizers, and unified processors (AutoProcessor) to prepare model inputs. For ASR, feature extractors normalize audio inputs and tokenizers encode transcripts, while processors combine both. Using processor.as_target_processor() ensures labels are correctly tokenized. This pattern yields training‑ready dictionaries with input_values, input_length, and labels, ready for models like Wav2Vec2[^5].

### AudioFolder Dataset Builder

For local audio collections, AudioFolder enables no‑code dataset creation. It infers class labels from directory names and supports split subdirectories, metadata files (.csv, .jsonl, .parquet) linking file names to captions, zipped audio, and multiple audio files per row. This builder is particularly useful when turning a file tree into a Datasets object ready for resampling and preprocessing, and for publishing to the Hub[^6].

Table 4 shows typical directory structures for AudioFolder.

### Table 4. AudioFolder directory structure examples

| Scenario                         | Structure                                                                                  |
|----------------------------------|---------------------------------------------------------------------------------------------|
| Single split with labels         | train/dog/golden_retriever.mp3; train/cat/maine_coon.mp3                                   |
| Multiple splits with labels      | train/dog/german_shepherd.mp3; test/dog/golden_retriever.mp3                               |
| Metadata‑driven                  | train/metadata.csv; train/0001.mp3; train/0002.mp3                                         |
| Multiple audio files per row     | input.mp3; output.mp3 (fields like *_file_name or file_names)                              |

## Dataset Structures and Content (LJ Speech, Common Voice, Multilingual LibriSpeech)

Different corpora serve different purposes. LJ Speech is a single‑speaker English TTS/ASR dataset with clean, short clips; Common Voice is a massively multilingual, crowdsourced dataset with MP3 audio and TSV metadata; MLS is a large‑scale audiobook corpus restructured for streaming, covering eight languages. Table 5 compares the three across dimensions relevant to engineering choices.

### Table 5. Comparative overview of LJ Speech, Common Voice, MLS

| Dataset                      | Language(s)     | Audio Format           | Splits           | Typical Fields                                  | Licensing/Notes                                                |
|-----------------------------|-----------------|------------------------|------------------|-------------------------------------------------|----------------------------------------------------------------|
| LJ Speech                   | English         | WAV, 16‑bit PCM, mono, 22,050 Hz | No pre‑split     | file, audio {path, array, sr}, text, normalized_text | Public domain; single speaker; clips ~1–10s; curated alignment |
| Common Voice                | Many languages  | MP3 (clips), TSV metadata | Varied per language | MP3 path, transcript; often demographic metadata | Open, crowd‑sourced; conversion often needed for ASR pipelines |
| Multilingual LibriSpeech    | 8 languages     | FLAC, 16 kHz           | train/dev/test   | file, audio {path, array, sr}, text, speaker_id, chapter_id, id | Public domain/CC‑BY; large‑scale; parquet for streaming        |

LJ Speech statistics are particularly tidy for single‑speaker TTS experiments, as summarized in Table 6[^7][^8].

### Table 6. LJ Speech statistics (key metrics)

| Metric                         | Value                    |
|--------------------------------|--------------------------|
| Total clips                    | 13,100                   |
| Total duration                 | 23:55:17                 |
| Mean clip duration             | 6.57 s                   |
| Min/Max clip duration          | 1.11 s / 10.10 s         |
| Mean words per clip            | 17.23                    |
| Distinct words                 | 13,821                   |
| Sampling rate                  | 22,050 Hz                |
| Channels / Bit depth           | Mono / 16‑bit PCM        |

MLS covers eight languages with detailed split statistics in the dataset card. Table 7 summarizes the samples and hours by language and split, which are useful for estimating training regimes and validation coverage[^14][^15].

### Table 7. MLS samples and hours by language and split

| Language   | Train Samples | Train Hours | Dev Samples | Dev Hours | Test Samples | Test Hours |
|------------|---------------|-------------|-------------|-----------|--------------|------------|
| English    | —             | 44,659.74   | —           | 15.75     | —            | 15.55      |
| German     | 469,942       | 1,966.51    | 3,469       | 14.28     | 3,394        | 14.29      |
| Dutch      | 374,287       | 1,554.24    | 3,095       | 12.76     | 3,075        | 12.76      |
| French     | 258,213       | 1,076.58    | 2,416       | 10.07     | 2,426        | 10.07      |
| Spanish    | 220,701       | 917.68      | 2,408       | 9.99      | 2,385        | 10.00      |
| Italian    | 59,623        | 247.38      | 1,248       | 5.18      | 1,262        | 5.27       |
| Portuguese | 37,533        | 160.96      | 826         | 3.64      | 871          | 3.74       |
| Polish     | 25,043        | 103.65      | 512         | 2.08      | 520          | 2.14       |

Note: English train hours reflect the large scale of the English subset; full sample counts are not enumerated here due to space constraints, but the dataset card provides exhaustive splits and speaker breakdowns[^14][^15].

### LJ Speech: Structure and Content

LJ Speech contains 13,100 English clips from a single speaker reading seven public‑domain non‑fiction books. Clips are segmented around silences and aligned to sentence or clause boundaries, with manual matching and QA. Each sample includes the audio path, decoded audio array at 22,050 Hz, and transcriptions in both raw and normalized forms (numbers, ordinals, monetary units expanded; common abbreviations expanded; 19 non‑ASCII transcriptions noted). The dataset is public domain and commonly used for single‑speaker TTS, with careful attention to text normalization for synthesis consistency[^7][^8].

### Common Voice: Structure, Splits, and Processing Requirements

Common Voice is an open, crowdsourced, multilingual dataset. In its raw form, it comprises MP3 audio under a “clips” directory and TSV metadata files with transcripts and demographic information where available. For many ASR pipelines, MP3 must be converted to WAV, and TSV must be normalized to CSV splits (train/dev/test). The Coqui STT importer converts MP3 to WAV per sample and produces split CSVs with fields like wav_filename, wav_filesize, and transcript. This structure is typical for Common Voice language packages and enables standard ASR training workflows[^11][^12].

Table 8 summarizes a typical structure before and after preprocessing.

### Table 8. Common Voice raw vs. processed structure

| Stage           | Files/Structure                                | Fields/Notes                                                |
|-----------------|-------------------------------------------------|-------------------------------------------------------------|
| Raw (download)  | clips/*.mp3; *.tsv metadata                     | MP3 audio; TSV with text and demographics where available   |
| Processed       | clips/train.csv; clips/dev.csv; clips/test.csv  | wav_filename; wav_filesize; transcript                      |
| Audio conversion| MP3 → WAV (per sample)                          | WAV needed for many ASR stacks                              |

### Multilingual LibriSpeech (MLS): Structure and Splits

MLS restructures read audiobooks from LibriVox for streaming, offering parquet‑based archives and detailed split statistics across eight languages. Instances include file paths, audio arrays at 16 kHz, transcripts, and metadata such as speaker_id and chapter_id. The dataset card provides samples, hours, and gender‑based speaker counts, with clear licensing (public domain or CC‑BY). This corpus supports ASR, speaker identification, and TTS, with parquet enabling fast, memory‑efficient access in Datasets[^14][^15].

## Integration with Transformers Library (ASR and TTS)

Transformers integrates smoothly with Datasets at preprocessing time. For ASR, feature extractors and tokenizers can be combined using AutoProcessor to produce model‑ready inputs and labels. For TTS, models such as SpeechT5, VITS, and Bark are available and can be paired with appropriate datasets depending on single‑speaker or multi‑speaker requirements. Given the dynamic nature of model availability and documentation access, teams should confirm current model choices and licensing before fine‑tuning[^5][^16][^17][^18].

Table 9 maps typical ASR/TTS pipelines and the corresponding Datasets/Transformers components.

### Table 9. Model‑dataset integration mapping

| Task | Typical Pipeline Components                         | Datasets Usage Pattern                                  |
|------|------------------------------------------------------|---------------------------------------------------------|
| ASR  | AutoFeatureExtractor + AutoTokenizer + AutoProcessor | cast_column("audio", Audio(sr=…)); map(prepare_dataset); filter(duration) |
| TTS  | Processor/Tokenizer + Model (SpeechT5, VITS, Bark)   | Load dataset; resample; normalize text; batch with map  |

### ASR with Datasets + Transformers

A standard ASR preprocessing flow is: resample the audio column to the target rate (often 16 kHz); use a processor to extract features and tokenize the transcript; compute input_length; and remove extraneous columns. Teams then filter out samples exceeding maximum duration to prevent memory spikes or truncation during training. This pattern yields well‑formed batches compatible with Wav2Vec2‑style training and evaluation loops[^5].

### TTS with Datasets + Transformers

For TTS, dataset choice hinges on speaker count and language coverage. LJ Speech suits single‑speaker synthesis experiments, while VCTK supports multi‑speaker modeling. Preprocessing typically includes text normalization to harmonize numerics and abbreviations, resampling to model‑specific rates, and batching via map to generate inputs and targets. Models such as SpeechT5, VITS, and Bark can be loaded from Transformers; confirm sampling rates and tokenizer compatibility against model cards[^7][^21][^16][^17][^18].

## Usage Examples for TTS Training and Evaluation

Below are step‑by‑step examples to preprocess datasets and integrate with Transformers. The intent is to provide robust defaults and patterns that generalize across corpora.

### TTS on LJ Speech: Preprocessing and Model Training Sketch

1. Load the dataset and inspect fields.
2. Resample audio to the model’s target rate (e.g., 22,050 Hz for LJ Speech).
3. Normalize text consistently using the dataset’s normalized_text when available.
4. Batch preprocess: compute inputs and targets via map; remove non‑essential columns.
5. Instantiate a TTS model and processor; confirm sampling rate and tokenizer compatibility.
6. Train with standard TTS objectives, monitoring audio quality and text alignment[^7][^16][^17][^18].

Example preprocessing sketch (Python):

```python
from datasets import load_dataset, Audio
from transformers import AutoProcessor

# Load dataset
ljspeech = load_dataset("keithito/lj_speech")

# Resample to 22050 Hz to match dataset native rate or model requirement
ljspeech = ljspeech.cast_column("audio", Audio(sampling_rate=22050))

# Text normalization (use normalized_text if consistent with model/tokenizer)
def normalize_text(example):
    example["text"] = example.get("normalized_text", example["text"])
    return example

ljspeech = ljspeech.map(normalize_text)

# Prepare inputs using a processor (confirm model checkpoint compatibilities)
processor = AutoProcessor.from_pretrained("transformers-repo/model-name")  # e.g., SpeechT5/VITS/Bark

def prepare_tts(batch):
    audio = batch["audio"]
    inputs = processor(
        text=batch["text"],
        audio=audio["array"],
        sampling_rate=audio["sampling_rate"],
        return_input_features=True,
        return_attention_mask=False,
        return_token_type_ids=False,
    )
    # Keep only model‑ready features
    batch["input_features"] = inputs["input_features"]
    batch["text_tokens"] = inputs.get("input_ids")  # if applicable
    return batch

# Batch preprocess and slim the dataset
ljspeech = ljspeech.map(prepare_tts, remove_columns=[c for c in ljspeech["train"].column_names if c not in {"input_features", "text_tokens"}])
```

Notes:
- Confirm the processor’s expected fields (input_features vs. raw waveforms) for the chosen model.
- If training end‑to‑end, align durations and ensure deterministic shuffling for stable batches[^7][^16][^17][^18].

### ASR on Common Voice: Preprocessing and Training Sketch

Common Voice requires MP3→WAV conversion and TSV→CSV normalization for many ASR stacks. After conversion, load splits and preprocess for Wav2Vec2‑style models.

Steps:
1. Convert MP3 to WAV and normalize TSV metadata into split CSVs (train/dev/test) containing wav_filename, wav_filesize, transcript.
2. Load the processed CSV splits; resample to 16 kHz if required by the feature extractor.
3. Preprocess with a processor to extract input_values and tokenize labels; compute input_length.
4. Filter out samples exceeding the maximum duration to avoid memory issues.
5. Train an ASR model (e.g., Wav2Vec2) with standard CTC/seq2seq objectives[^12][^5].

Example preprocessing sketch (Python):

```python
import pandas as pd
from datasets import load_dataset, Audio
from transformers import AutoProcessor

# Load processed CSVs (post conversion and split normalization)
train_df = pd.read_csv("clips/train.csv")
dev_df = pd.read_csv("clips/dev.csv")
test_df = pd.read_csv("clips/test.csv")

# Datasets supports loading from parquet-like structures; convert CSVs to Dataset
from datasets import Dataset

train_ds = Dataset.from_pandas(train_df)
dev_ds = Dataset.from_pandas(dev_df)
test_ds = Dataset.from_pandas(test_df)

cv = {"train": train_ds, "dev": dev_ds, "test": test_ds}

# Ensure audio column points to WAV files; resample to 16 kHz
for split in cv:
    cv[split] = cv[split].cast_column("audio", Audio(sampling_rate=16000))

# Processor for ASR (e.g., Wav2Vec2)
processor = AutoProcessor.from_pretrained("facebook/wav2vec2-base-960h")

def prepare_asr(batch):
    audio = batch["audio"]
    inputs = processor(
        audio["array"],
        sampling_rate=audio["sampling_rate"],
        return_tensors=None,
    )
    batch["input_values"] = inputs["input_values"] if "input_values" in inputs else inputs["input_features"]
    # Tokenize labels
    with processor.as_target_processor():
        batch["labels"] = processor(batch["transcript"]).input_ids
    batch["input_length"] = len(batch["input_values"])
    return batch

# Batch preprocess
for split in cv:
    cv[split] = cv[split].map(
        prepare_asr,
        remove_columns=[c for c in cv[split].column_names if c not in {"input_values", "labels", "input_length"}]
    )

# Filter out overly long samples
MAX_DURATION = 30.0  # seconds
cv["train"] = cv["train"].filter(
    lambda ex: ex["input_length"] < MAX_DURATION * 16000,  # input_length counts frames at 16 kHz
    input_columns=["input_length"],
)
```

If your environment does not allow direct MP3 decoding via Audio feature or the pipeline requires WAV, use the Coqui STT importer to convert MP3→WAV and generate split CSVs first[^12][^5].

### Streaming for Large Datasets

For very large corpora, enable streaming to avoid full downloads and immediate iteration:

```python
mls_stream = load_dataset("facebook/multilingual_librispeech", "german", split="train", streaming=True)
sample = next(iter(mls_stream))  # inspect first sample without full materialization
```

This approach starts quickly, minimizes disk usage, and supports sharded processing, but does not cache samples locally[^4][^14].

## Best Practices, Pitfalls, and Licensing

- Resampling and decoding are performed on access; cast audio columns early to set the target sampling rate and ensure consistent downstream processing[^5].
- Query by sample index (dataset[i]["audio"]) rather than column access (dataset["audio"][0]) to avoid expensive materialization and ensure performance at scale[^7].
- Filter long audio clips to prevent out‑of‑memory errors and ensure batch stability. Always compute input_length to make filtering precise[^1][^5].
- Use streaming for rapid iteration on large or sharded datasets; accept the trade‑off of no caching[^4].
- Respect dataset licensing and speaker privacy. LJ Speech is public domain; MLS carries public domain or CC‑BY; Common Voice is open but subject to dataset terms. Never attempt to identify individuals from voice data[^8][^14][^11].
- Prefer WAV or FLAC in pipelines that do not handle MP3 natively; convert MP3→WAV as necessary and normalize TSV/CSV metadata to match training scripts[^12].

## Appendix: Additional Audio Datasets and References

Beyond the three highlighted datasets, the Hub hosts many audio corpora. FLEURS is a multilingual ASR dataset used across languages and tasks; VCTK is a multi‑speaker TTS dataset used widely for voice modeling. Use the Hub’s dataset filters for ASR and TTS to discover datasets aligned to your needs, and review dataset cards for licensing, language coverage, and sampling rates before integration[^9][^20][^21].

## Information Gaps and Access Constraints

- Official Common Voice dataset pages on the Hub for recent versions experienced rate‑limit errors at access time, and exact per‑language field schemas may vary. Teams should confirm the current dataset cards and metadata fields per language before integration.
- Licensing details beyond dataset cards (e.g., for VCTK) require confirmation on the relevant dataset pages.
- Transformers TTS task pages experienced rate limiting during access; model availability and APIs should be cross‑checked on the latest official documentation.
- Audio classification specifics are out of scope here; this report focuses on ASR and TTS.
- Preprocessing and inference scripts are referenced; ensure versions align with current Transformers releases.

## References

[^1]: A Complete Guide to Audio Datasets - Hugging Face. https://huggingface.co/blog/audio-datasets  
[^2]: Datasets - Hugging Face. https://huggingface.co/docs/datasets/en/index  
[^3]: huggingface/datasets: The largest hub of ready-to-use datasets - GitHub. https://github.com/huggingface/datasets  
[^4]: Load datasets - Hugging Face. https://huggingface.co/docs/datasets/en/loading  
[^5]: Process audio data - Hugging Face. https://huggingface.co/docs/datasets/en/audio_process  
[^6]: Create an audio dataset - Hugging Face. https://huggingface.co/docs/datasets/en/audio_dataset  
[^7]: keithito/lj_speech · Datasets at Hugging Face. https://huggingface.co/datasets/keithito/lj_speech  
[^8]: The LJ Speech Dataset - Keith Ito. https://keithito.com/LJ-Speech-Dataset  
[^9]: Audio Dataset - Hugging Face Hub. https://huggingface.co/docs/hub/en/datasets-audio  
[^10]: Common Voice: A Massively-Multilingual Speech Corpus - arXiv. https://arxiv.org/abs/1912.06670  
[^11]: Mozilla Common Voice datasets. https://commonvoice.mozilla.org/en/datasets  
[^12]: Common Voice training data - Coqui STT documentation. https://stt.readthedocs.io/en/latest/COMMON_VOICE_DATA.html  
[^14]: facebook/multilingual_librispeech · Datasets at Hugging Face. https://huggingface.co/datasets/facebook/multilingual_librispeech  
[^15]: MLS: A Large-Scale Multilingual Dataset for Speech Research - arXiv. https://arxiv.org/abs/2012.03411  
[^16]: Text to speech - Hugging Face Transformers. https://huggingface.co/docs/transformers/en/tasks/text-to-speech  
[^17]: VITS - Hugging Face Transformers. https://huggingface.co/docs/transformers/en/model_doc/vits  
[^18]: Bark - Hugging Face Transformers. https://huggingface.co/docs/transformers/en/model_doc/bark  
[^19]: Quickstart - Hugging Face Datasets. https://huggingface.co/docs/datasets/en/quickstart  
[^20]: google/fleurs · Datasets at Hugging Face. https://huggingface.co/datasets/google/fleurs  
[^21]: kakao-enterprise/vits-vctk · Model card at Hugging Face. https://huggingface.co/kakao-enterprise/vits-vctk