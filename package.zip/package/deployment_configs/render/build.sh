#!/bin/bash

# Build script for TTS Application
# Supports multiple deployment platforms and environments

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
PLATFORM="generic"
ENVIRONMENT="production"
PYTHON_VERSION="3.10"
DOCKER_IMAGE="tts-converter"
VERSION="latest"
BUILD_ARGS=""
CLEANUP=false
VERBOSE=false

# Logging functions
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1"
    exit 1
}

# Usage information
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Build TTS Application for various deployment platforms"
    echo ""
    echo "Options:"
    echo "  -p, --platform PLATFORM     Target platform (generic, docker, heroku, render, huggingface)"
    echo "  -e, --environment ENV       Environment (development, staging, production)"
    echo "  -v, --version VERSION       Version tag (default: latest)"
    echo "  --python-version VERSION    Python version (default: 3.10)"
    echo "  --docker-image IMAGE        Docker image name (default: tts-converter)"
    echo "  --build-arg ARG             Additional build arguments"
    echo "  --cleanup                   Clean up temporary files after build"
    echo "  --verbose                   Enable verbose output"
    echo "  -h, --help                  Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --platform docker --environment production"
    echo "  $0 --platform heroku --version v1.0.0"
    echo "  $0 --platform render --environment staging --verbose"
    exit 0
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -p|--platform)
                PLATFORM="$2"
                shift 2
                ;;
            -e|--environment)
                ENVIRONMENT="$2"
                shift 2
                ;;
            -v|--version)
                VERSION="$2"
                shift 2
                ;;
            --python-version)
                PYTHON_VERSION="$2"
                shift 2
                ;;
            --docker-image)
                DOCKER_IMAGE="$2"
                shift 2
                ;;
            --build-arg)
                BUILD_ARGS="$BUILD_ARGS --build-arg $2"
                shift 2
                ;;
            --cleanup)
                CLEANUP=true
                shift
                ;;
            --verbose)
                VERBOSE=true
                shift
                ;;
            -h|--help)
                usage
                ;;
            *)
                error "Unknown option: $1"
                ;;
        esac
    done
}

# Validate environment
validate_environment() {
    log "Validating build environment..."
    
    # Check required tools
    local required_tools=("python3" "pip")
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            error "Required tool '$tool' is not installed"
        fi
    done
    
    # Check Python version
    local python_version=$(python3 --version | cut -d' ' -f2)
    log "Python version: $python_version"
    
    # Validate platform
    local valid_platforms=("generic" "docker" "heroku" "render" "huggingface")
    if [[ ! " ${valid_platforms[@]} " =~ " ${PLATFORM} " ]]; then
        error "Invalid platform: $PLATFORM. Valid platforms: ${valid_platforms[*]}"
    fi
    
    # Check if virtual environment exists
    if [[ ! -d "venv" ]]; then
        warn "Virtual environment not found, creating one..."
        python3 -m venv venv
    fi
    
    log "Environment validation completed"
}

# Create virtual environment and install dependencies
setup_dependencies() {
    log "Setting up dependencies for $PLATFORM platform..."
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    # Install dependencies based on platform
    case $PLATFORM in
        "docker")
            log "Installing Docker dependencies..."
            pip install -r deployment_configs/docker/requirements.txt
            ;;
        "heroku"|"render")
            log "Installing Streamlit dependencies..."
            pip install -r deployment_configs/streamlit/requirements-streamlit.txt
            ;;
        "huggingface")
            log "Installing Hugging Face Spaces dependencies..."
            pip install -r deployment_configs/huggingface/requirements.txt
            ;;
        "generic"|*)
            log "Installing generic dependencies..."
            pip install -r requirements.txt
            ;;
    esac
    
    # Install platform-specific tools
    case $PLATFORM in
        "docker")
            pip install docker
            ;;
        "heroku")
            pip install gunicorn
            ;;
        "render")
            pip install gunicorn uvicorn
            ;;
    esac
    
    log "Dependencies setup completed"
}

# Build for generic platform
build_generic() {
    log "Building for generic platform..."
    
    # Create build directory
    local build_dir="build/generic"
    mkdir -p "$build_dir"
    
    # Copy source code
    cp -r code/ "$build_dir/"
    cp -r configs/ "$build_dir/"
    cp requirements.txt "$build_dir/"
    cp main.py "$build_dir/"
    
    # Create run script
    cat > "$build_dir/run.sh" << 'EOF'
#!/bin/bash
python3 main.py --web --port 7860 --host 0.0.0.0
EOF
    chmod +x "$build_dir/run.sh"
    
    log "Generic build completed in $build_dir"
}

# Build for Docker platform
build_docker() {
    log "Building Docker image: $DOCKER_IMAGE:$VERSION"
    
    # Build Docker image
    docker build \
        $BUILD_ARGS \
        -t "$DOCKER_IMAGE:$VERSION" \
        -f deployment_configs/docker/Dockerfile \
        .
    
    # Create docker-compose file for production
    if [[ ! -f "docker-compose.prod.yml" ]]; then
        cp deployment_configs/docker/docker-compose.prod.yml .
    fi
    
    log "Docker build completed: $DOCKER_IMAGE:$VERSION"
}

# Build for Heroku platform
build_heroku() {
    log "Building for Heroku platform..."
    
    # Create Heroku build
    local build_dir="build/heroku"
    mkdir -p "$build_dir"
    
    # Copy source code
    cp -r code/ "$build_dir/"
    cp -r configs/ "$build_dir/"
    cp deployment_configs/streamlit/streamlit_app.py "$build_dir/app.py"
    cp deployment_configs/streamlit/Procfile "$build_dir/"
    cp deployment_configs/streamlit/requirements-streamlit.txt "$build_dir/requirements.txt"
    
    # Create runtime.txt
    echo "python-$PYTHON_VERSION" > "$build_dir/runtime.txt"
    
    log "Heroku build completed in $build_dir"
}

# Build for Render platform
build_render() {
    log "Building for Render platform..."
    
    # Create Render build
    local build_dir="build/render"
    mkdir -p "$build_dir"
    
    # Copy source code
    cp -r code/ "$build_dir/"
    cp -r configs/ "$build_dir/"
    cp deployment_configs/streamlit/streamlit_app.py "$build_dir/"
    cp deployment_configs/render/render.yaml "$build_dir/"
    cp deployment_configs/render/.env.example "$build_dir/"
    
    # Create start script for Render
    cat > "$build_dir/start.sh" << EOF
#!/bin/bash
gunicorn --bind 0.0.0.0:\\$PORT \\
         --workers 2 \\
         --worker-class uvicorn.workers.UvicornWorker \\
         --timeout 120 \\
         streamlit_app:app
EOF
    chmod +x "$build_dir/start.sh"
    
    log "Render build completed in $build_dir"
}

# Build for Hugging Face Spaces
build_huggingface() {
    log "Building for Hugging Face Spaces..."
    
    # Create Spaces build
    local build_dir="build/huggingface"
    mkdir -p "$build_dir"
    
    # Copy Spaces files
    cp deployment_configs/huggingface/* "$build_dir/"
    cp -r code/ "$build_dir/"
    cp -r configs/ "$build_dir/"
    
    # Create model cache directory
    mkdir -p "$build_dir/models_cache"
    
    # Set up model caching
    export TRANSFORMERS_CACHE="/tmp/transformers"
    export HF_HOME="/tmp/huggingface"
    export TORCH_HOME="/tmp/torch"
    
    log "Hugging Face Spaces build completed in $build_dir"
}

# Run tests
run_tests() {
    if [[ "$VERBOSE" == true ]]; then
        log "Running tests..."
        
        # Run basic Python tests if they exist
        if [[ -d "tests" ]]; then
            python -m pytest tests/ -v || warn "Some tests failed"
        fi
        
        # Test imports
        python -c "from code.tts_processor import TTSProcessor; print('Import test passed')" || error "Import test failed"
    fi
}

# Generate build artifacts
generate_artifacts() {
    log "Generating build artifacts..."
    
    local build_info="build/build-info.txt"
    mkdir -p build
    
    cat > "$build_info" << EOF
Build Information
=================
Platform: $PLATFORM
Environment: $ENVIRONMENT
Version: $VERSION
Python Version: $PYTHON_VERSION
Docker Image: $DOCKER_IMAGE
Build Date: $(date)
Build Host: $(hostname)
Git Commit: $(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
Git Branch: $(git branch --show-current 2>/dev/null || echo "unknown")
EOF
    
    # Create requirements hash for dependency locking
    case $PLATFORM in
        "docker")
            md5sum deployment_configs/docker/requirements.txt > build/requirements.hash
            ;;
        "heroku"|"render")
            md5sum deployment_configs/streamlit/requirements-streamlit.txt > build/requirements.hash
            ;;
        "huggingface")
            md5sum deployment_configs/huggingface/requirements.txt > build/requirements.hash
            ;;
    esac
    
    log "Build artifacts generated"
}

# Cleanup temporary files
cleanup() {
    if [[ "$CLEANUP" == true ]]; then
        log "Cleaning up temporary files..."
        
        # Remove temporary directories
        rm -rf venv
        rm -rf __pycache__
        rm -rf *.pyc
        rm -rf .pytest_cache
        
        log "Cleanup completed"
    fi
}

# Main build function
main() {
    log "🚀 Starting TTS Application build"
    log "Platform: $PLATFORM"
    log "Environment: $ENVIRONMENT"
    log "Version: $VERSION"
    
    # Parse arguments and validate
    parse_args "$@"
    validate_environment
    
    # Setup dependencies
    setup_dependencies
    
    # Run tests
    run_tests
    
    # Build based on platform
    case $PLATFORM in
        "generic")
            build_generic
            ;;
        "docker")
            build_docker
            ;;
        "heroku")
            build_heroku
            ;;
        "render")
            build_render
            ;;
        "huggingface")
            build_huggingface
            ;;
        *)
            error "Unknown platform: $PLATFORM"
            ;;
    esac
    
    # Generate build artifacts
    generate_artifacts
    
    # Cleanup
    cleanup
    
    log "✅ Build completed successfully!"
    log "Platform: $PLATFORM"
    log "Build artifacts: build/"
    
    if [[ "$PLATFORM" == "docker" ]]; then
        log "Docker image: $DOCKER_IMAGE:$VERSION"
        log "To run: docker run -p 7860:7860 $DOCKER_IMAGE:$VERSION"
    fi
}

# Run main function
main "$@"