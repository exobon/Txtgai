"""
Hugging Face Spaces optimized Text-to-Speech application.
"""

import os
import sys
import json
import logging
import gradio as gr
import torch
import tempfile
from typing import List, Dict, Optional, Tuple
from pathlib import Path

# Add the main code directory to Python path for imports
sys.path.append('/workspace/code')

from gradio_interface import TTSGradioInterface
from tts_processor import TTSProcessor
from advanced_tts import AdvancedTTSProcessor, BatchTTSProcessor, AudioFormatConverter
from dataset_integration import DatasetLoader, DatasetAnalyzer

# Configure logging for Spaces
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SpacesTTSInterface(TTSGradioInterface):
    """
    Hugging Face Spaces optimized TTS interface.
    """
    
    def __init__(self, model_name: str = "speecht5"):
        """Initialize with Spaces-optimized settings."""
        # Use smaller models for faster loading on Spaces
        self.spaces_config = {
            "max_text_length": 1000,
            "enable_cache": True,
            "optimize_memory": True,
            "model_timeout": 300  # 5 minutes for model loading
        }
        
        super().__init__(model_name)
        
        # Spaces-specific optimizations
        self._optimize_for_spaces()
    
    def _optimize_for_spaces(self):
        """Apply Spaces-specific optimizations."""
        logger.info("Optimizing for Hugging Face Spaces...")
        
        # Set environment variables for better performance
        os.environ["TRANSFORMERS_CACHE"] = "/tmp/transformers"
        os.environ["HF_HOME"] = "/tmp/huggingface"
        os.environ["TORCH_HOME"] = "/tmp/torch"
        
        # Enable memory optimization
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        # Create temporary directories
        for temp_dir in ["/tmp/transformers", "/tmp/huggingface", "/tmp/torch"]:
            os.makedirs(temp_dir, exist_ok=True)
    
    def get_system_info(self) -> Dict:
        """Get system information for Spaces."""
        info = super().get_model_info()
        info.update({
            "platform": "Hugging Face Spaces",
            "cpu_count": os.cpu_count(),
            "memory_available": self._get_memory_info(),
            "disk_space": self._get_disk_info(),
            "optimizations": [
                "Memory optimization enabled",
                "Model caching active",
                "Temp storage optimized"
            ]
        })
        return info
    
    def _get_memory_info(self) -> str:
        """Get available memory information."""
        try:
            import psutil
            memory = psutil.virtual_memory()
            return f"{memory.available / (1024**3):.1f}GB available"
        except:
            return "Memory info not available"
    
    def _get_disk_info(self) -> str:
        """Get disk space information."""
        try:
            disk = psutil.disk_usage('/tmp')
            return f"{disk.free / (1024**3):.1f}GB free"
        except:
            return "Disk info not available"
    
    def build_spaces_interface(self) -> gr.Interface:
        """
        Build optimized interface for Hugging Face Spaces.
        """
        # Get system info
        system_info = self.get_system_info()
        
        # Spaces-optimized CSS
        css = """
        .gradio-container {
            max-width: 1400px !important;
            margin: auto !important;
        }
        .gr-button {
            font-weight: bold !important;
            transition: all 0.3s ease !important;
        }
        .gr-input, .gr-textbox {
            font-size: 16px !important;
        }
        .gr-audio {
            border: 2px solid #e0e0e0 !important;
            border-radius: 8px !important;
        }
        .spaces-banner {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .status-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            border-left: 4px solid #007bff;
            margin: 10px 0;
        }
        """
        
        with gr.Blocks(css=css, title="TTS Converter - Hugging Face Spaces") as interface:
            
            # Spaces banner
            gr.HTML("""
            <div class="spaces-banner">
                <h1 style="margin: 0; font-size: 2.5em;">🎤 Text-to-Speech Converter</h1>
                <p style="margin: 10px 0 0 0; font-size: 1.2em;">
                    🤖 Powered by Hugging Face Transformers | 📊 Spaces Optimized
                </p>
            </div>
            """)
            
            # Model selection and system info
            with gr.Row():
                with gr.Column(scale=2):
                    model_choice = gr.Dropdown(
                        choices=self.get_model_options(),
                        value="speecht5",  # Use smaller model for Spaces
                        label="🤖 Select TTS Model",
                        info="Optimized models for Spaces (faster loading)"
                    )
                
                with gr.Column(scale=1):
                    system_status = gr.HTML(f"""
                    <div class="status-card">
                        <h4 style="margin: 0 0 10px 0;">📋 System Status</h4>
                        <p style="margin: 5px 0;"><strong>Platform:</strong> {system_info.get('platform', 'N/A')}</p>
                        <p style="margin: 5px 0;"><strong>Memory:</strong> {system_info.get('memory_available', 'N/A')}</p>
                        <p style="margin: 5px 0;"><strong>Storage:</strong> {system_info.get('disk_space', 'N/A')}</p>
                        <p style="margin: 5px 0;"><strong>Models:</strong> Spaces Optimized</p>
                    </div>
                    """)
            
            # Main tabs with Spaces optimizations
            with gr.Tabs():
                
                # Tab 1: Quick Single TTS
                with gr.TabItem("🎵 Quick Convert"):
                    gr.HTML("""
                    <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h3 style="margin: 0 0 10px 0;">⚡ Quick Text-to-Speech</h3>
                        <p style="margin: 0;">Enter text and generate speech instantly. Perfect for quick tests!</p>
                    </div>
                    """)
                    
                    with gr.Row():
                        with gr.Column():
                            text_input = gr.Textbox(
                                label="📝 Input Text",
                                placeholder="Enter your text here... (Max 1000 characters)",
                                lines=4,
                                max_lines=8,
                                max_length=1000
                            )
                            
                            with gr.Row():
                                emotion = gr.Dropdown(
                                    choices=["neutral", "happy", "sad"],
                                    value="neutral",
                                    label="😊 Emotion",
                                    info="Add basic emotion (spaces-optimized)"
                                )
                                
                                language = gr.Dropdown(
                                    choices=["en", "es", "fr", "de"],
                                    value="en",
                                    label="🌍 Language",
                                    info="Popular languages only"
                                )
                            
                            generate_btn = gr.Button("🎤 Generate Speech", variant="primary", size="lg")
                        
                        with gr.Column():
                            audio_output = gr.Audio(
                                label="🎧 Generated Audio",
                                type="filepath"
                            )
                            
                            status_output = gr.HTML("""
                            <div style="padding: 15px; background: #e8f5e8; border-radius: 8px; border-left: 4px solid #28a745;">
                                <p style="margin: 0; font-style: italic;">Ready to generate speech...</p>
                            </div>
                            """)
                    
                    generate_btn.click(
                        fn=self.tts_single,
                        inputs=[text_input, model_choice, emotion, language],
                        outputs=[audio_output, status_output]
                    )
                
                # Tab 2: Batch Processing (Spaces-optimized)
                with gr.TabItem("📦 Batch Process"):
                    gr.HTML("""
                    <div style="background: #fff3cd; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h3 style="margin: 0 0 10px 0;">🚀 Batch Processing</h3>
                        <p style="margin: 0;">Process multiple texts efficiently. Use semicolons or newlines as separators.</p>
                    </div>
                    """)
                    
                    with gr.Row():
                        with gr.Column():
                            batch_text = gr.Textbox(
                                label="📝 Batch Text Input",
                                placeholder="First text\nSecond text; Third text\nFourth text; Fifth text; Sixth text",
                                lines=6,
                                info="Separate texts with newlines or semicolons"
                            )
                            
                            batch_btn = gr.Button("🚀 Process Batch", variant="primary", size="lg")
                        
                        with gr.Column():
                            batch_output = gr.File(
                                label="📁 Generated Files",
                                file_count="multiple",
                                file_types=["audio"]
                            )
                            
                            batch_status = gr.HTML("""
                            <div style="padding: 15px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                                <p style="margin: 0; font-style: italic;">Enter text above and click Process Batch...</p>
                            </div>
                            """)
                    
                    batch_btn.click(
                        fn=self.tts_batch,
                        inputs=[batch_text, model_choice],
                        outputs=[batch_output, batch_status]
                    )
                
                # Tab 3: Audio Converter
                with gr.TabItem("🔄 Format Converter"):
                    gr.HTML("""
                    <div style="background: #d4edda; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h3 style="margin: 0 0 10px 0;">🎵 Audio Format Converter</h3>
                        <p style="margin: 0;">Convert audio files between different formats and qualities.</p>
                    </div>
                    """)
                    
                    with gr.Row():
                        with gr.Column():
                            convert_audio = gr.Audio(
                                label="🎵 Audio File",
                                type="filepath",
                                info="Upload audio file to convert"
                            )
                            
                            with gr.Row():
                                target_format = gr.Dropdown(
                                    choices=["mp3", "wav"],
                                    value="mp3",
                                    label="📁 Format",
                                    info="MP3 (small) or WAV (high quality)"
                                )
                                
                                bitrate = gr.Dropdown(
                                    choices=["128k", "192k"],
                                    value="192k",
                                    label="🎛️ Quality",
                                    info="Good balance for Spaces"
                                )
                            
                            convert_btn = gr.Button("🔄 Convert", variant="primary", size="lg")
                        
                        with gr.Column():
                            converted_audio = gr.Audio(
                                label="✅ Converted Audio",
                                type="filepath"
                            )
                            
                            convert_status = gr.HTML("""
                            <div style="padding: 15px; background: #d4edda; border-radius: 8px; border-left: 4px solid #28a745;">
                                <p style="margin: 0; font-style: italic;">Select audio file to convert...</p>
                            </div>
                            """)
                    
                    convert_btn.click(
                        fn=self.convert_audio_format,
                        inputs=[convert_audio, target_format, bitrate],
                        outputs=[converted_audio, convert_status]
                    )
                
                # Tab 4: System Info
                with gr.TabItem("⚙️ System Info"):
                    with gr.Row():
                        with gr.Column():
                            gr.HTML(f"""
                            <div style="padding: 20px; background: #e9ecef; border-radius: 8px; margin-bottom: 20px;">
                                <h3>🖥️ System Information</h3>
                                <p><strong>Platform:</strong> {system_info.get('platform', 'N/A')}</p>
                                <p><strong>CPU Cores:</strong> {system_info.get('cpu_count', 'N/A')}</p>
                                <p><strong>Memory:</strong> {system_info.get('memory_available', 'N/A')}</p>
                                <p><strong>Storage:</strong> {system_info.get('disk_space', 'N/A')}</p>
                                <p><strong>Current Model:</strong> {system_info.get('model_name', 'N/A')}</p>
                                <p><strong>Sample Rate:</strong> {system_info.get('sample_rate', 'N/A')} Hz</p>
                            </div>
                            """)
                            
                            cleanup_btn = gr.Button("🗑️ Clean Temp Files", variant="secondary")
                            cleanup_status = gr.HTML("")
                        
                        with gr.Column():
                            gr.HTML(f"""
                            <div style="padding: 20px; background: #d1ecf1; border-radius: 8px; margin-bottom: 20px;">
                                <h3>🌟 Spaces Features</h3>
                                <ul style="text-align: left;">
                                    <li><strong>Fast Loading:</strong> Optimized models for quick startup</li>
                                    <li><strong>Memory Efficient:</strong> Smart memory management</li>
                                    <li><strong>No Data Upload:</strong> All processing is local</li>
                                    <li><strong>Instant Results:</strong> Real-time generation</li>
                                    <li><strong>Free Hosting:</strong> Powered by Hugging Face</li>
                                </ul>
                            </div>
                            """)
            
            # Event handlers
            cleanup_btn.click(
                fn=self.cleanup_files,
                outputs=[cleanup_status]
            )
            
            model_choice.change(
                fn=lambda x: self._update_spaces_model_info(x),
                inputs=[model_choice],
                outputs=[system_status]
            )
        
        return interface
    
    def _update_spaces_model_info(self, new_model: str) -> str:
        """Update model information for Spaces display."""
        try:
            if new_model != self.current_model:
                self.current_model = new_model
                self._initialize_processors()
            
            model_info = self.get_model_info()
            
            return f"""
            <div class="status-card">
                <h4 style="margin: 0 0 10px 0;">📋 Model Loaded</h4>
                <p style="margin: 5px 0;"><strong>Current:</strong> {model_info.get('model_name', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Quality:</strong> {model_info.get('voice_quality', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Speed:</strong> {model_info.get('speed', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Memory:</strong> {model_info.get('memory_usage', 'N/A')}</p>
                <p style="margin: 5px 0;"><strong>Status:</strong> ✅ Ready</p>
            </div>
            """
        except Exception as e:
            return f"""
            <div style="padding: 15px; background: #f8d7da; border-radius: 8px; border-left: 4px solid #dc3545;">
                <h4 style="margin: 0 0 10px 0;">⚠️ Model Error</h4>
                <p style="margin: 5px 0;">Error loading model: {str(e)}</p>
            </div>
            """


def create_spaces_interface():
    """Create the Hugging Face Spaces optimized interface."""
    try:
        logger.info("Initializing Spaces TTS Interface...")
        interface = SpacesTTSInterface()
        logger.info("Interface created successfully!")
        return interface
    except Exception as e:
        logger.error(f"Failed to create interface: {str(e)}")
        raise


def main():
    """Main entry point for Hugging Face Spaces."""
    try:
        # Create and launch the interface
        app = create_spaces_interface()
        spaces_interface = app.build_spaces_interface()
        
        # Launch with Spaces-optimized settings
        spaces_interface.launch(
            share=True,  # Enable sharing for Spaces
            inbrowser=False,  # Disable auto-open browser
            server_name="0.0.0.0",
            server_port=7860,
            quiet=False,
            show_error=True,
            height=800,
            title="TTS Converter - Hugging Face Spaces"
        )
        
    except Exception as e:
        logger.error(f"Application error: {str(e)}")
        # Create fallback interface with error message
        with gr.Blocks(title="TTS Error") as error_interface:
            gr.HTML(f"""
            <div style="text-align: center; padding: 50px;">
                <h1>❌ Application Error</h1>
                <p>Unable to initialize TTS interface: {str(e)}</p>
                <p>Please check the logs and try again.</p>
            </div>
            """)
        error_interface.launch(server_name="0.0.0.0", server_port=7860)


if __name__ == "__main__":
    main()