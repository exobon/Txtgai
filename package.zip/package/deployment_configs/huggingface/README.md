# Text-to-Speech Converter

🤖 **Advanced Text-to-Speech application powered by Hugging Face Transformers**

Convert any text to natural-sounding speech using state-of-the-art AI models. This space provides a comprehensive TTS interface with multiple features including single conversion, batch processing, audio format conversion, and dataset analysis.

## 🚀 Features

### Core Functionality
- **Multiple TTS Models**: SpeechT5, MMS-TTS, Bark, and more
- **Emotion Control**: Add emotional expression to generated speech
- **Language Support**: Multi-language text-to-speech (English, Spanish, French, German, etc.)
- **Speaker Control**: Different voice characteristics
- **Batch Processing**: Convert multiple texts simultaneously
- **Audio Format Conversion**: Support for MP3, WAV, FLAC, OGG formats

### Advanced Features
- **Dataset Analysis**: Analyze Hugging Face speech datasets (LJ Speech, Common Voice, VCTK)
- **Audio Quality Control**: Normalize and enhance audio output
- **Real-time Generation**: Instant speech generation
- **Offline Processing**: All models run locally

## 🎛️ Interface Tabs

### 1. 🎵 Single Conversion
- Enter text and generate speech instantly
- Choose emotion (neutral, happy, sad, excited, whisper)
- Select target language
- Download generated audio files

### 2. 📦 Batch Processing
- Process multiple texts in one go
- Support for newlines or semicolons as separators
- Progress tracking for batch operations
- Download all generated files as a collection

### 3. 🔄 Audio Converter
- Convert between different audio formats
- Adjustable bitrate settings (128k, 192k, 256k, 320k)
- Support for MP3, WAV, FLAC, OGG formats
- Quality optimization options

### 4. 📊 Dataset Analysis
- Analyze popular speech datasets
- Statistics on audio duration, sample rates
- Text analysis and character counts
- Dataset quality insights

### 5. ⚙️ Settings & Info
- System information and model details
- Memory usage and performance metrics
- File cleanup utilities
- Application information

## 🔧 Technical Specifications

### Supported Models
- **SpeechT5**: High-quality, natural-sounding speech
- **MMS-TTS**: Multilingual, fast inference
- **Bark**: Advanced neural codec with emotions

### Audio Specifications
- **Output Formats**: WAV (default), MP3, FLAC, OGG
- **Sample Rates**: 16kHz - 48kHz (model-dependent)
- **Bitrates**: 128k, 192k, 256k, 320k (for compressed formats)
- **Channels**: Mono/Stereo support

### Performance
- **First Load**: 30-60 seconds (model download)
- **Generation Speed**: 2-10x real-time (depending on model)
- **Memory Usage**: 2-8GB (model-dependent)
- **GPU Support**: Automatic detection (CUDA if available)

## 📖 Usage Instructions

### Basic Usage
1. Wait for the application to load (models download automatically)
2. Select your preferred TTS model
3. Enter text in the "Input Text" field
4. Choose emotion and language settings
5. Click "Generate Speech"
6. Download or play the generated audio

### Batch Processing
1. Go to the "Batch Processing" tab
2. Enter multiple texts (one per line or separated by semicolons)
3. Select model and format options
4. Click "Process Batch"
5. Download the generated files collection

### Audio Conversion
1. Upload an audio file in the "Audio Converter" tab
2. Select target format and quality settings
3. Click "Convert Format"
4. Download the converted audio file

### Dataset Analysis
1. Navigate to the "Dataset Analysis" tab
2. Choose a dataset to analyze
3. Click "Analyze Dataset"
4. Review the detailed statistics

## 🔒 Privacy & Security

- **No Data Storage**: All processing happens in your browser
- **No Text Upload**: Your text never leaves your device
- **Local Processing**: All models run locally on Hugging Face infrastructure
- **Open Source**: Transparent, auditable code

## 🛠️ Technical Requirements

### For Users
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Stable internet connection (for model loading)
- 2GB+ available memory
- Audio playback capability

### For Developers
- Python 3.8+
- PyTorch 2.0+
- Transformers 4.35+
- Gradio 3.45+

## 📚 Model Credits

- **SpeechT5**: Microsoft Research
- **MMS-TTS**: Meta AI
- **Bark**: Suno AI

## 🤝 Contributing

This project is open source! Contributions are welcome:
- Bug reports and feature requests
- Code improvements and optimizations
- Documentation enhancements
- New TTS model integrations

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Hugging Face team for the amazing Transformers library
- The open source AI community
- Researchers behind the TTS models
- Contributors to audio processing libraries

---

**Built with ❤️ using Hugging Face Spaces and Gradio**

*Experience the future of text-to-speech technology!*