# TTS Application Deployment Guide

This guide covers deploying the Text-to-Speech application to multiple cloud platforms using the provided configurations.

## 📋 Deployment Overview

The TTS application supports deployment to:

- **Hugging Face Spaces** - Free, fast deployment with GPU support
- **Streamlit/Heroku** - Python-native deployment with easy scaling  
- **Docker** - Production-ready containerized deployment
- **Render.com** - Modern cloud platform with database support

## 🚀 Quick Start

### 1. Hugging Face Spaces (Recommended for free hosting)

**Deployment Steps:**
1. Create account at [huggingface.co](https://huggingface.co)
2. Create a new Space
3. Copy files from `deployment_configs/huggingface/` to your Space
4. Push to GitHub (connected to Space)
5. Application auto-deploys!

**Required Files:**
- `README.md` - Space description and documentation
- `app.py` - Main application (Spaces-optimized)
- `requirements.txt` - Python dependencies
- `Dockerfile` - Container configuration
- `spaces.yml` - Space configuration

**Features:**
- ✅ Free hosting
- ✅ GPU support
- ✅ Automatic deployments
- ✅ Built-in sharing
- ✅ Fast global CDN

### 2. Streamlit on Heroku

**Prerequisites:**
- Heroku account
- Heroku CLI installed

**Deployment Steps:**
```bash
# 1. Create Heroku app
heroku create your-app-name

# 2. Set environment variables
heroku config:set PYTHON_VERSION=3.10.12

# 3. Deploy
git subtree push --prefix deployment_configs/streamlit heroku main

# Or use the build script
chmod +x deployment_configs/render/build.sh
./deployment_configs/render/build.sh --platform heroku --version v1.0.0
```

**Required Files:**
- `streamlit_app.py` - Streamlit application
- `requirements-streamlit.txt` - Dependencies
- `Procfile` - Heroku process configuration

### 3. Docker Production Deployment

**Prerequisites:**
- Docker and Docker Compose installed

**Deployment Steps:**
```bash
# 1. Build image
docker build -f deployment_configs/docker/Dockerfile -t tts-converter:latest .

# 2. Run with docker-compose
docker-compose -f deployment_configs/docker/docker-compose.prod.yml up -d

# 3. Access application
open http://localhost:8080
```

**Features:**
- ✅ Production-ready configuration
- ✅ Nginx reverse proxy
- ✅ Redis caching
- ✅ PostgreSQL database
- ✅ Monitoring (Prometheus/Grafana)
- ✅ Health checks
- ✅ Auto-scaling support

### 4. Render.com Cloud Platform

**Prerequisites:**
- Render.com account
- GitHub repository

**Deployment Steps:**
1. Connect GitHub to Render.com
2. Create new Web Service
3. Use `deployment_configs/render/render.yaml`
4. Deploy!

**Automatic Features:**
- ✅ Auto-scaling (0 to multiple instances)
- ✅ Zero-downtime deployments
- ✅ PostgreSQL database
- ✅ Redis cache
- ✅ Background workers
- ✅ Health checks
- ✅ SSL certificates

## 📁 Configuration File Structure

```
deployment_configs/
├── huggingface/          # Hugging Face Spaces
│   ├── README.md
│   ├── app.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── spaces.yml
├── streamlit/            # Streamlit/Heroku
│   ├── streamlit_app.py
│   ├── requirements-streamlit.txt
│   └── Procfile
├── docker/               # Docker production
│   ├── Dockerfile
│   ├── docker-compose.prod.yml
│   ├── nginx.conf
│   ├── .dockerignore
│   └── start.sh
└── render/               # Render.com
    ├── render.yaml
    ├── .env.example
    └── build.sh
```

## 🔧 Environment Configuration

### Required Environment Variables

All platforms require these core variables:

```bash
# Application
APP_NAME=TTS Converter
ENVIRONMENT=production
LOG_LEVEL=INFO
MAX_TEXT_LENGTH=1000

# TTS Models
DEFAULT_MODEL=speecht5
TRANSFORMERS_CACHE=/tmp/transformers
HF_HOME=/tmp/huggingface
TORCH_HOME=/tmp/torch

# Database (optional)
DATABASE_URL=postgresql://user:pass@host:port/db
REDIS_URL=redis://localhost:6379
```

### Platform-Specific Configuration

#### Hugging Face Spaces
```yaml
# spaces.yml
hardware: "cpu"  # or "cpu-plus", "t4-small"
sdk: docker
port: 7860
timeout: 7200  # 2 hours
```

#### Heroku
```bash
# Procfile
web: streamlit run deployment_configs/streamlit/streamlit_app.py --server.port=$PORT
```

#### Render.com
```yaml
# render.yaml
services:
  - type: web
    plan: starter
    buildCommand: pip install -r requirements-streamlit.txt
    startCommand: gunicorn --bind 0.0.0.0:$PORT streamlit_app:app
```

## 📊 Performance Optimization

### Memory Optimization
- Use smaller models for Spaces (SpeechT5 vs Bark)
- Enable model caching
- Set appropriate max_text_length limits
- Use Redis for session storage

### Speed Optimization
- Pre-download models in Docker layers
- Use CDN for static assets
- Enable compression
- Optimize database queries

### Cost Optimization
- Use auto-scaling (Render.com)
- Scale to zero when idle
- Use free tiers (Render.com, Heroku)
- Optimize model sizes

## 🔒 Security Best Practices

### Application Security
- Set secure SECRET_KEY
- Use HTTPS (SSL certificates)
- Enable CORS properly
- Implement rate limiting
- Validate file uploads

### Infrastructure Security
- Run as non-root user
- Use environment variables for secrets
- Enable firewall rules
- Regular security updates
- Monitor access logs

## 📈 Monitoring & Logging

### Health Checks
All configurations include health check endpoints:
- `/health` - Basic health status
- `/metrics` - Performance metrics

### Logging
- Structured logging (JSON format)
- Centralized log aggregation
- Error tracking (Sentry integration)
- Performance monitoring

### Metrics
- Request/response times
- Memory usage
- CPU utilization
- Generation success rates

## 🧪 Testing Deployments

### Pre-deployment Testing
```bash
# Test locally
python deployment_configs/huggingface/app.py

# Test Docker build
docker build -f deployment_configs/docker/Dockerfile .
docker run -p 7860:7860 <image-id>

# Test build script
chmod +x deployment_configs/render/build.sh
./deployment_configs/render/build.sh --platform docker --verbose
```

### Post-deployment Verification
1. Check application loads
2. Test text-to-speech generation
3. Verify file uploads work
4. Check database connections
5. Monitor error logs

## 🚨 Troubleshooting

### Common Issues

#### Model Loading Fails
```
Solution: Increase timeout, use smaller models, check cache
```

#### Memory Issues
```
Solution: Reduce batch size, use smaller models, enable swap
```

#### Port Binding Errors
```
Solution: Check port environment variables, ensure 0.0.0.0 binding
```

#### File Permission Issues
```
Solution: Check Docker user permissions, file ownership
```

### Debug Commands
```bash
# Check application logs
docker logs <container-id>
heroku logs --tail
curl http://your-app.com/health

# Check system resources
docker stats
htop
free -h
```

## 📚 Additional Resources

### Documentation
- [Hugging Face Spaces Docs](https://huggingface.co/docs/spaces)
- [Streamlit Deployment](https://docs.streamlit.io/deploy)
- [Docker Best Practices](https://docs.docker.com/develop/best-practices/)
- [Render.com Guide](https://render.com/docs)

### Support
- Create issues in the GitHub repository
- Check platform-specific documentation
- Review application logs
- Test with minimal configurations

## 🎯 Deployment Checklist

### Pre-deployment
- [ ] Environment variables configured
- [ ] Models tested locally
- [ ] Dependencies verified
- [ ] Security settings reviewed
- [ ] Resource limits set

### Deployment
- [ ] Platform-specific configuration created
- [ ] Database migrations run (if applicable)
- [ ] Health checks configured
- [ ] Monitoring setup
- [ ] SSL certificates installed

### Post-deployment
- [ ] Application accessible
- [ ] Core features tested
- [ ] Performance monitoring active
- [ ] Error tracking enabled
- [ ] Backup strategy implemented

## 🔄 CI/CD Integration

### GitHub Actions Example
```yaml
name: Deploy to Production
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Build and Deploy
        run: |
          chmod +x deployment_configs/render/build.sh
          ./deployment_configs/render/build.sh --platform render --environment production
```

---

**Need Help?** Check the platform-specific documentation or create an issue in the repository.