#!/bin/bash

# TTS Application Startup Script
# Production-ready startup with health checks and monitoring

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to wait for a service to be ready
wait_for_service() {
    local url=$1
    local service_name=$2
    local max_attempts=30
    local attempt=1
    
    log "Waiting for $service_name to be ready..."
    
    while [ $attempt -le $max_attempts ]; do
        if curl -f -s "$url" > /dev/null 2>&1; then
            log "$service_name is ready!"
            return 0
        fi
        
        echo -n "."
        sleep 2
        ((attempt++))
    done
    
    error "$service_name failed to start within expected time"
    return 1
}

# Initialize environment
init_environment() {
    log "Initializing environment..."
    
    # Set default environment variables
    export PYTHONPATH="${PYTHONPATH}:/app/code"
    export TRANSFORMERS_CACHE="${TRANSFORMERS_CACHE:-/tmp/transformers}"
    export HF_HOME="${HF_HOME:-/tmp/huggingface}"
    export TORCH_HOME="${TORCH_HOME:-/tmp/torch}"
    export LOG_LEVEL="${LOG_LEVEL:-INFO}"
    export MAX_TEXT_LENGTH="${MAX_TEXT_LENGTH:-1000}"
    export BATCH_SIZE="${BATCH_SIZE:-10}"
    
    # Create necessary directories
    mkdir -p /app/outputs /app/logs /app/models_cache \
             /tmp/transformers /tmp/huggingface /tmp/torch \
             /var/log/nginx
    
    # Set proper permissions
    chmod -R 755 /app
    chmod -R 777 /app/outputs /app/logs /app/models_cache /tmp
    
    log "Environment initialized successfully"
}

# Check system requirements
check_requirements() {
    log "Checking system requirements..."
    
    # Check Python version
    if command_exists python3; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        log "Python version: $PYTHON_VERSION"
    else
        error "Python3 not found!"
        exit 1
    fi
    
    # Check available memory
    if command_exists free; then
        MEMORY=$(free -h | awk 'NR==2{printf "Total: %s, Available: %s", $2,$7}')
        log "Memory: $MEMORY"
    fi
    
    # Check disk space
    DISK=$(df -h /tmp | awk 'NR==2{printf "Total: %s, Available: %s", $2,$4}')
    log "Disk space: $DISK"
    
    # Check for required system packages
    REQUIRED_PACKAGES=("ffmpeg" "libasound2")
    for package in "${REQUIRED_PACKAGES[@]}"; do
        if dpkg -l | grep -q "^ii  $package"; then
            log "✓ $package is installed"
        else
            warn "⚠ $package might not be installed"
        fi
    done
    
    log "System requirements check completed"
}

# Start nginx
start_nginx() {
    log "Starting Nginx..."
    
    # Create nginx configuration if it doesn't exist
    if [ ! -f /etc/nginx/nginx.conf ]; then
        warn "Nginx config not found, creating default..."
        cat > /etc/nginx/nginx.conf << 'NGINX_CONF'
events {
    worker_connections 1024;
}
http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    server {
        listen 8080;
        location / {
            proxy_pass http://localhost:7860;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
        location /health {
            access_log off;
            return 200 "healthy\n";
        }
    }
}
NGINX_CONF
    fi
    
    # Test nginx configuration
    if ! nginx -t; then
        error "Nginx configuration test failed"
        return 1
    fi
    
    # Start nginx
    nginx || {
        error "Failed to start Nginx"
        return 1
    }
    
    log "Nginx started successfully"
}

# Start the TTS application
start_tts_app() {
    log "Starting TTS application..."
    
    # Set application environment
    export PYTHONPATH="/app/code:$PYTHONPATH"
    export TRANSFORMERS_CACHE="/tmp/transformers"
    export HF_HOME="/tmp/huggingface"
    export TORCH_HOME="/tmp/torch"
    export GRADIO_SERVER_NAME="0.0.0.0"
    export GRADIO_SERVER_PORT="7860"
    export GRADIO_SERVER_HEADLESS="true"
    
    # Start the application
    log "Launching Gradio interface..."
    
    # Use exec to replace the shell process
    exec python3 /app/deployment_configs/huggingface/app.py
}

# Health check function
health_check() {
    local endpoint=${1:-"http://localhost:8080/health"}
    
    if curl -f -s "$endpoint" > /dev/null; then
        log "Health check passed"
        return 0
    else
        warn "Health check failed"
        return 1
    fi
}

# Signal handlers for graceful shutdown
graceful_shutdown() {
    log "Received shutdown signal, cleaning up..."
    
    # Kill nginx
    if pgrep nginx > /dev/null; then
        log "Stopping Nginx..."
        nginx -s quit || killall nginx
    fi
    
    # Kill Python processes
    if pgrep -f "python.*app.py" > /dev/null; then
        log "Stopping TTS application..."
        pkill -f "python.*app.py"
    fi
    
    log "Shutdown completed"
    exit 0
}

# Main startup sequence
main() {
    log "🚀 Starting TTS Application Container"
    
    # Set up signal handlers
    trap graceful_shutdown SIGTERM SIGINT
    
    # Initialize environment
    init_environment
    
    # Check system requirements
    check_requirements
    
    # Start services
    start_nginx
    
    # Wait for nginx to be ready
    if wait_for_service "http://localhost:8080/health" "Nginx"; then
        log "All services are ready!"
    else
        error "Service startup failed"
        exit 1
    fi
    
    # Start the TTS application (this will replace the current process)
    start_tts_app
}

# Run main function
main "$@"