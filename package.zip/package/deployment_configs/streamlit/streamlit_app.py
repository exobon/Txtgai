"""
Streamlit Text-to-Speech Application
Converted from Gradio for Streamlit deployment
"""

import streamlit as st
import os
import sys
import json
import tempfile
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import pandas as pd
import torch

# Add the main code directory to Python path for imports
sys.path.append('/workspace/code')

# Import TTS modules
from tts_processor import TTSProcessor
from advanced_tts import AdvancedTTSProcessor, BatchTTSProcessor, AudioFormatConverter
from dataset_integration import DatasetLoader, DatasetAnalyzer
from configs.settings import (
    TTS_MODELS, DEFAULT_MODEL, DEFAULT_GRADIO_CONFIG
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="TTS Converter",
    page_icon="🎤",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': 'https://github.com/your-repo/tts-converter',
        'Report a bug': 'https://github.com/your-repo/tts-converter/issues',
        'About': 'Text-to-Speech Converter powered by AI'
    }
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .stApp > header {
        background-color: transparent;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
    }
    .audio-container {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .success-box {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    .error-box {
        background-color: #f8d7da;
        color: #721c24;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #dc3545;
        margin: 1rem 0;
    }
    .warning-box {
        background-color: #fff3cd;
        color: #856404;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #ffc107;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

class StreamlitTTSInterface:
    """Streamlit interface for TTS system."""
    
    def __init__(self):
        """Initialize the Streamlit TTS interface."""
        self.current_model = DEFAULT_MODEL
        self.output_dir = "streamlit_outputs"
        self.generated_files = []
        
        # Initialize session state
        if 'tts_processor' not in st.session_state:
            st.session_state.tts_processor = None
        if 'model_info' not in st.session_state:
            st.session_state.model_info = {}
        if 'generation_count' not in st.session_state:
            st.session_state.generation_count = 0
        
        # Create output directory
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize processors
        self._initialize_processors()
    
    def _initialize_processors(self):
        """Initialize TTS processors."""
        try:
            if st.session_state.tts_processor is None:
                with st.spinner("Initializing TTS processors..."):
                    st.session_state.tts_processor = TTSProcessor(self.current_model)
                    st.session_state.model_info = st.session_state.tts_processor.get_model_info()
                    st.success("✅ TTS processors initialized successfully!")
        except Exception as e:
            st.error(f"❌ Error initializing processors: {str(e)}")
    
    def get_model_options(self) -> List[str]:
        """Get available model options."""
        if st.session_state.tts_processor:
            return st.session_state.tts_processor.list_available_models()
        return list(TTS_MODELS.keys())
    
    def generate_speech(self, text: str, model_choice: str, emotion: str = "neutral", 
                       language: str = "en") -> Tuple[Optional[str], str]:
        """Generate speech from text."""
        try:
            if not text.strip():
                return None, "❌ Please enter some text to convert."
            
            # Switch model if needed
            if model_choice != self.current_model:
                self.current_model = model_choice
                self._initialize_processors()
            
            # Generate output filename
            text_preview = text[:20].replace(" ", "_").replace("\n", "_")
            output_path = os.path.join(self.output_dir, f"tts_{text_preview}_{st.session_state.generation_count}.wav")
            
            # Generate speech
            if st.session_state.tts_processor:
                audio_path = st.session_state.tts_processor.generate_speech(
                    text, output_path, normalize=True
                )
                
                # Track generated files
                self.generated_files.append(audio_path)
                st.session_state.generation_count += 1
                
                return audio_path, f"✅ Speech generated successfully!\n\nModel: {model_choice}\nEmotion: {emotion}\nLanguage: {language}"
            else:
                return None, "❌ TTS processor not available"
                
        except Exception as e:
            error_msg = f"❌ Error generating speech: {str(e)}"
            return None, error_msg
    
    def convert_audio_format(self, audio_file, target_format: str = "mp3", 
                           bitrate: str = "192k") -> Tuple[Optional[str], str]:
        """Convert audio format."""
        try:
            if audio_file is None:
                return None, "❌ Please provide an audio file to convert."
            
            converter = AudioFormatConverter()
            
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp_file:
                tmp_file.write(audio_file.getbuffer())
                input_path = tmp_file.name
            
            # Generate output filename
            base_name = os.path.splitext(os.path.basename(audio_file.name))[0]
            output_path = os.path.join(self.output_dir, f"{base_name}_converted.{target_format}")
            
            # Convert format
            success = converter.convert_format(input_path, output_path, target_format, bitrate)
            
            # Clean up temporary file
            os.unlink(input_path)
            
            if success:
                return output_path, f"✅ Audio converted successfully!\n\nFormat: {target_format.upper()}\nBitrate: {bitrate}"
            else:
                return None, "❌ Format conversion failed"
                
        except Exception as e:
            return None, f"❌ Error converting audio: {str(e)}"

def main():
    """Main Streamlit application."""
    
    # Initialize interface
    if 'tts_interface' not in st.session_state:
        st.session_state.tts_interface = StreamlitTTSInterface()
    
    interface = st.session_state.tts_interface
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1 style="margin: 0;">🎤 Text-to-Speech Converter</h1>
        <p style="margin: 10px 0 0 0; font-size: 1.2em;">Convert text to natural speech using AI models</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar for model selection and settings
    with st.sidebar:
        st.header("🤖 Model Settings")
        
        # Model selection
        model_choice = st.selectbox(
            "Select TTS Model",
            options=interface.get_model_options(),
            index=0,
            help="Choose the model for speech generation"
        )
        
        # Display model info
        if st.session_state.model_info:
            st.markdown("### 📋 Model Information")
            st.markdown(f"""
            <div class="metric-card">
                <p><strong>Model:</strong> {st.session_state.model_info.get('model_name', 'N/A')}</p>
                <p><strong>Quality:</strong> {st.session_state.model_info.get('voice_quality', 'N/A')}</p>
                <p><strong>Speed:</strong> {st.session_state.model_info.get('speed', 'N/A')}</p>
                <p><strong>Sample Rate:</strong> {st.session_state.model_info.get('sample_rate', 'N/A')} Hz</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Generation statistics
        st.markdown("### 📊 Generation Stats")
        st.metric("Total Generated", st.session_state.generation_count)
        
        # Cleanup button
        if st.button("🗑️ Clean Generated Files"):
            try:
                for file_path in interface.generated_files:
                    if os.path.exists(file_path):
                        os.remove(file_path)
                interface.generated_files.clear()
                st.success("Generated files cleaned up!")
            except Exception as e:
                st.error(f"Error during cleanup: {str(e)}")
    
    # Main content area
    tab1, tab2, tab3, tab4 = st.tabs(["🎵 Single Convert", "📦 Batch Process", "🔄 Format Converter", "ℹ️ About"])
    
    with tab1:
        st.header("Single Text-to-Speech Conversion")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Input Settings")
            
            # Text input
            text_input = st.text_area(
                "Enter your text:",
                placeholder="Type your text here...",
                height=150,
                help="Enter the text you want to convert to speech"
            )
            
            # Settings row
            col_a, col_b = st.columns(2)
            
            with col_a:
                emotion = st.selectbox(
                    "😊 Emotion",
                    options=["neutral", "happy", "sad", "excited"],
                    help="Add emotion to the voice"
                )
            
            with col_b:
                language = st.selectbox(
                    "🌍 Language",
                    options=["en", "es", "fr", "de", "it", "pt"],
                    help="Target language"
                )
            
            # Generate button
            generate_btn = st.button("🎤 Generate Speech", type="primary", use_container_width=True)
        
        with col2:
            st.subheader("Output")
            
            if generate_btn and text_input:
                with st.spinner("Generating speech..."):
                    audio_path, status_msg = interface.generate_speech(
                        text_input, model_choice, emotion, language
                    )
                    
                    if audio_path and os.path.exists(audio_path):
                        st.success("Speech generated successfully!")
                        st.audio(audio_path)
                        
                        # Download button
                        with open(audio_path, 'rb') as audio_file:
                            st.download_button(
                                label="📥 Download Audio",
                                data=audio_file.read(),
                                file_name=os.path.basename(audio_path),
                                mime="audio/wav"
                            )
                    else:
                        st.error(status_msg)
            else:
                st.info("Enter text and click 'Generate Speech' to start.")
    
    with tab2:
        st.header("Batch Text Processing")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Batch Input")
            
            batch_text = st.text_area(
                "Enter multiple texts:",
                placeholder="First text\\nSecond text\\nThird text",
                height=200,
                help="Enter multiple texts separated by newlines"
            )
            
            format_choice = st.selectbox(
                "Output Format",
                options=["wav", "mp3"],
                help="Choose the output audio format"
            )
            
            batch_btn = st.button("🚀 Process Batch", type="primary", use_container_width=True)
        
        with col2:
            st.subheader("Results")
            
            if batch_btn and batch_text:
                texts = [t.strip() for t in batch_text.split('\\n') if t.strip()]
                
                if texts:
                    st.info(f"Processing {len(texts)} texts...")
                    
                    progress_bar = st.progress(0)
                    results = []
                    
                    for i, text in enumerate(texts):
                        progress_bar.progress((i + 1) / len(texts))
                        
                        try:
                            audio_path, status_msg = interface.generate_speech(
                                text, model_choice
                            )
                            results.append({
                                "Text": text[:50] + "..." if len(text) > 50 else text,
                                "Status": "✅ Success" if audio_path else "❌ Failed",
                                "Audio File": os.path.basename(audio_path) if audio_path else "N/A"
                            })
                        except Exception as e:
                            results.append({
                                "Text": text[:50] + "..." if len(text) > 50 else text,
                                "Status": "❌ Error",
                                "Audio File": str(e)
                            })
                    
                    # Display results
                    if results:
                        df = pd.DataFrame(results)
                        st.dataframe(df, use_container_width=True)
                        
                        # Download all files button
                        if any(r["Status"] == "✅ Success" for r in results):
                            st.success(f"Generated {sum(1 for r in results if r['Status'] == '✅ Success')} files!")
                else:
                    st.warning("Please enter some text to process.")
            else:
                st.info("Enter text above and click 'Process Batch' to start.")
    
    with tab3:
        st.header("Audio Format Converter")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Conversion Settings")
            
            # File upload
            audio_file = st.file_uploader(
                "Choose an audio file",
                type=['wav', 'mp3', 'flac', 'ogg'],
                help="Upload an audio file to convert"
            )
            
            if audio_file:
                st.success(f"Uploaded: {audio_file.name}")
                
                # Conversion settings
                col_a, col_b = st.columns(2)
                
                with col_a:
                    target_format = st.selectbox(
                        "Target Format",
                        options=["mp3", "wav", "flac", "ogg"],
                        help="Convert to this format"
                    )
                
                with col_b:
                    bitrate = st.selectbox(
                        "Quality",
                        options=["128k", "192k", "256k"],
                        help="Audio quality (for compressed formats)"
                    )
                
                convert_btn = st.button("🔄 Convert Format", type="primary", use_container_width=True)
        
        with col2:
            st.subheader("Converted Output")
            
            if convert_btn and audio_file:
                with st.spinner("Converting format..."):
                    output_path, status_msg = interface.convert_audio_format(
                        audio_file, target_format, bitrate
                    )
                    
                    if output_path and os.path.exists(output_path):
                        st.success("Format conversion successful!")
                        st.audio(output_path)
                        
                        # Download button
                        with open(output_path, 'rb') as converted_file:
                            st.download_button(
                                label="📥 Download Converted File",
                                data=converted_file.read(),
                                file_name=os.path.basename(output_path),
                                mime=f"audio/{target_format}"
                            )
                    else:
                        st.error(status_msg)
            else:
                st.info("Upload an audio file to convert.")
    
    with tab4:
        st.header("About This Application")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown("""
            ### 🎯 Features
            
            - **Multiple TTS Models**: SpeechT5, MMS-TTS, Bark, and more
            - **Emotion Control**: Add emotional expression to generated speech  
            - **Batch Processing**: Convert multiple texts simultaneously
            - **Format Conversion**: Support for MP3, WAV, FLAC, OGG formats
            - **Real-time Generation**: Instant speech generation
            - **Download Options**: Save generated audio files
            
            ### 🔧 Technical Details
            
            - **Framework**: Streamlit for web interface
            - **AI Models**: Hugging Face Transformers
            - **Audio Processing**: LibROSA, SoundFile, PyDub
            - **Supported Languages**: English, Spanish, French, German, Italian, Portuguese
            - **Output Formats**: WAV (uncompressed), MP3, FLAC, OGG
            
            ### 📋 Usage Tips
            
            1. **Single Conversion**: Best for quick speech generation
            2. **Batch Processing**: Use for processing multiple texts
            3. **Format Converter**: Change audio file formats and quality
            4. **Model Selection**: Choose based on quality vs speed needs
            5. **Emotion Control**: Add personality to generated speech
            
            ### 🔒 Privacy & Security
            
            - No text data is stored or transmitted
            - All processing happens locally
            - Generated files are temporary
            - No user data collection
            
            ### 🆘 Troubleshooting
            
            - **Slow Generation**: Try smaller text chunks
            - **Memory Issues**: Restart the application
            - **Model Loading**: Wait for initialization to complete
            - **Audio Playback**: Check browser audio permissions
            """)
        
        with col2:
            st.markdown("### 📊 System Status")
            
            if st.session_state.model_info:
                st.markdown(f"""
                <div class="metric-card">
                    <p><strong>Current Model:</strong> {st.session_state.model_info.get('model_name', 'N/A')}</p>
                    <p><strong>Device:</strong> {st.session_state.model_info.get('device', 'N/A')}</p>
                    <p><strong>Sample Rate:</strong> {st.session_state.model_info.get('sample_rate', 'N/A')} Hz</p>
                    <p><strong>Generated Files:</strong> {st.session_state.generation_count}</p>
                </div>
                """, unsafe_allow_html=True)
            
            st.markdown("### 🚀 Performance Tips")
            
            st.info("""
            - Keep text under 1000 characters for best results
            - Use MP3 for smaller file sizes
            - WAV provides the highest quality
            - Batch processing is optimized for multiple texts
            """)


if __name__ == "__main__":
    main()