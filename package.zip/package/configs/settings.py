"""
Configuration settings for TTS models and processing parameters.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional
import torch

@dataclass
class TTSModelConfig:
    """Configuration for individual TTS models."""
    model_name: str
    model_path: str
    supported_languages: List[str]
    voice_quality: str
    speed: str
    memory_usage: str
    description: str
    recommended_usage: str

# TTS Model configurations based on research
TTS_MODELS = {
    "speecht5": TTSModelConfig(
        model_name="microsoft/speecht5_tts",
        model_path="microsoft/speecht5_tts",
        supported_languages=["en"],
        voice_quality="high",
        speed="medium",
        memory_usage="medium",
        description="Unified-modal encoder-decoder with controllable speaker embeddings",
        recommended_usage="Best for high-quality English TTS with speaker control"
    ),
    "mms_tts": TTSModelConfig(
        model_name="facebook/mms-tts",
        model_path="facebook/mms-tts-tacotron2",
        supported_languages=["en", "es", "fr", "de", "it", "pt", "ru", "pl", "tr", "zh", "ja", "ko", "hi", "ar", "fa", "ur", "id", "vi", "th", "nl"],
        voice_quality="medium",
        speed="fast",
        memory_usage="low",
        description="VITS-based model supporting 1,100+ languages",
        recommended_usage="Best for multilingual applications and low-resource environments"
    ),
    "bark": TTSModelConfig(
        model_name="suno/bark",
        model_path="suno/bark",
        supported_languages=["en", "de", "es", "fr", "hi", "it", "ja", "ko", "pl", "pt", "ru", "tr", "zh"],
        voice_quality="very_high",
        speed="slow",
        memory_usage="high",
        description="Transformer-based multilingual TTS with creative audio capabilities",
        recommended_usage="Best for creative content, sound effects, and highest quality audio"
    )
}

@dataclass
class AudioConfig:
    """Audio processing configuration."""
    sample_rate: int = 16000
    audio_format: str = "wav"
    bit_depth: int = 16
    channels: int = 1  # Mono audio
    max_duration: int = 30  # Maximum duration in seconds
    output_directory: str = "outputs"

@dataclass
class GradioConfig:
    """Gradio interface configuration."""
    title: str = "Text-to-Speech Converter"
    description: str = "Convert text to natural-sounding speech using Hugging Face models"
    theme: str = "default"
    share: bool = False
    inbrowser: bool = True

@dataclass 
class DatasetConfig:
    """Dataset configuration for training/evaluation."""
    lj_speech_config = {
        "name": "lj_speech",
        "path": "lj_speech",
        "description": "Single-speaker English dataset (13,100 clips, 24 hours)",
        "use_case": "English TTS training"
    }
    
    common_voice_config = {
        "name": "common_voice",
        "path": "mozilla-foundation/common_voice_16_1",
        "description": "Multilingual crowdsourced dataset (22+ languages)",
        "use_case": "Multilingual TTS training"
    }
    
    vctk_config = {
        "name": "vctk",
        "path": "vctk",
        "description": "Multi-speaker TTS dataset (109 speakers, various accents)",
        "use_case": "Multi-speaker TTS training"
    }

# Default configurations
DEFAULT_MODEL = "speecht5"
DEFAULT_AUDIO_CONFIG = AudioConfig()
DEFAULT_GRADIO_CONFIG = GradioConfig()
DEFAULT_DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Processing parameters
MAX_TEXT_LENGTH = 5000  # Maximum characters in input text
BATCH_SIZE = 1  # Default batch size for TTS generation
CACHE_DIR = "models_cache"  # Directory for caching downloaded models